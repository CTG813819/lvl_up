"""
Code router
"""

from fastapi import APIRouter

router = APIRouter()


@router.get("/")
async def get_code():
    """Get code information"""
    return {"message": "Code router - to be implemented"} 