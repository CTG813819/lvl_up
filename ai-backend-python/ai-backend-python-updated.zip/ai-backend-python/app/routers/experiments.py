"""
Experiments router
"""

from fastapi import APIRouter

router = APIRouter()


@router.get("/")
async def get_experiments():
    """Get experiments information"""
    return {"message": "Experiments router - to be implemented"} 