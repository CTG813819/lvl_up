"""
Analytics router
"""

from fastapi import APIRouter

router = APIRouter()


@router.get("/")
async def get_analytics():
    """Get analytics information"""
    return {"message": "Analytics router - to be implemented"} 