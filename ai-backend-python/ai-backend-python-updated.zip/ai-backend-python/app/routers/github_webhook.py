"""
GitHub webhook router
"""

from fastapi import APIRouter

router = APIRouter()


@router.post("/webhook")
async def github_webhook():
    """Handle GitHub webhook"""
    return {"message": "GitHub webhook router - to be implemented"} 