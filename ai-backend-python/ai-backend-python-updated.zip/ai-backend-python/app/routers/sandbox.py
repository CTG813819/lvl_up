"""
Sandbox router
"""

from fastapi import APIRouter

router = APIRouter()


@router.get("/")
async def get_sandbox():
    """Get sandbox information"""
    return {"message": "Sandbox router - to be implemented"} 