"""
Learning router for AI learning endpoints
"""

from typing import Dict, Any
from fastapi import APIRouter, HTTPException, Query
import structlog

from ..services.ai_learning_service import AILearningService
from ..services.ml_service import MLService

logger = structlog.get_logger()
router = APIRouter()

ai_learning_service = AILearningService()
ml_service = MLService()


@router.get("/stats/{ai_type}")
async def get_learning_stats(ai_type: str):
    """Get learning statistics for an AI type"""
    try:
        stats = await ai_learning_service.get_learning_stats(ai_type)
        return stats
    except Exception as e:
        logger.error("Error getting learning stats", error=str(e), ai_type=ai_type)
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/insights/{ai_type}")
async def get_learning_insights(ai_type: str):
    """Get learning insights and recommendations"""
    try:
        insights = await ai_learning_service.get_learning_insights(ai_type)
        return insights
    except Exception as e:
        logger.error("Error getting learning insights", error=str(e), ai_type=ai_type)
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/train")
async def train_models():
    """Train ML models"""
    try:
        await ml_service.train_models()
        return {"message": "Models trained successfully"}
    except Exception as e:
        logger.error("Error training models", error=str(e))
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/ml-insights")
async def get_ml_insights():
    """Get ML insights"""
    try:
        insights = await ml_service.get_ml_insights()
        return insights
    except Exception as e:
        logger.error("Error getting ML insights", error=str(e))
        raise HTTPException(status_code=500, detail=str(e)) 