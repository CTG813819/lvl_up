"""
AI Learning Service with scikit-learn integration
"""

import asyncio
from typing import Dict, List, Optional, Any
from datetime import datetime, timedelta
import structlog

from ..core.database import get_session
from ..core.config import settings
from .ml_service import MLService

logger = structlog.get_logger()


class AILearningService:
    """AI Learning service with ML integration"""
    
    _instance = None
    _initialized = False
    _learning_states = {}
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(AILearningService, cls).__new__(cls)
        return cls._instance
    
    def __init__(self):
        if not self._initialized:
            self.ml_service = MLService()
            self._initialized = True
    
    @classmethod
    async def initialize(cls):
        """Initialize the AI Learning service"""
        instance = cls()
        logger.info("AI Learning Service initialized")
    
    async def learn_from_proposal(self, proposal_id: str, status: str, feedback_reason: str = None):
        """Learn from a proposal using ML analysis"""
        try:
            from sqlalchemy import select
            from ..models.sql_models import Proposal, Learning
            import uuid
            
            session = get_session()
            try:
                # Get proposal
                stmt = select(Proposal).where(Proposal.id == uuid.UUID(proposal_id))
                result = await session.execute(stmt)
                proposal_data = result.scalar_one_or_none()
                
                if not proposal_data:
                    logger.warning("Proposal not found for learning", proposal_id=proposal_id)
                    return
                
                # Update proposal with feedback
                proposal_data.status = status
                proposal_data.user_feedback = status if status in ["approved", "rejected"] else None
                proposal_data.user_feedback_reason = feedback_reason
                proposal_data.updated_at = datetime.utcnow()
                
                await session.commit()
                
                # Analyze proposal quality using ML
                ml_analysis = await self.ml_service.analyze_proposal_quality(proposal_data)
                
                # Store learning data
                learning_entry = Learning(
                    ai_type=proposal_data.ai_type,
                    learning_type="proposal_feedback",
                    pattern=status,
                    context=feedback_reason,
                    feedback=str(ml_analysis),
                    confidence=ml_analysis.get('quality_score', 0.5),
                    created_at=datetime.utcnow()
                )
                
                session.add(learning_entry)
                await session.commit()
            
            logger.info("Learning from proposal completed", 
                       proposal_id=proposal_id, 
                       status=status,
                       quality_score=ml_analysis.get('quality_score', 0))
            
        except Exception as e:
            logger.error("Error learning from proposal", error=str(e), proposal_id=proposal_id)
        finally:
            await session.close()
    
    async def get_learning_stats(self, ai_type: str) -> Dict[str, Any]:
        """Get learning statistics"""
        try:
            from sqlalchemy import select, desc
            from ..models.sql_models import Learning, Proposal
            
            session = get_session()
            try:
                # Get recent learning entries
                stmt = select(Learning).where(
                    Learning.ai_type == ai_type
                ).order_by(desc(Learning.created_at)).limit(100)
                
                result = await session.execute(stmt)
                recent_learning = result.scalars().all()
                
                # Get recent proposals for approval rate
                stmt = select(Proposal).where(
                    Proposal.ai_type == ai_type
                ).order_by(desc(Proposal.created_at)).limit(100)
                
                result = await session.execute(stmt)
                recent_proposals = result.scalars().all()
                
                stats = {
                    'total_learning_entries': len(recent_learning),
                    'recent_approval_rate': 0,
                    'average_quality_score': 0,
                    'learning_state': self._learning_states.get(ai_type, {'is_learning': False})
                }
                
                if recent_proposals:
                    # Calculate approval rate
                    approved = sum(1 for entry in recent_proposals if entry.user_feedback == 'approved')
                    stats['recent_approval_rate'] = approved / len(recent_proposals)
                
                if recent_learning:
                    # Calculate average quality score from learning entries
                    quality_scores = [entry.confidence for entry in recent_learning if entry.confidence]
                    if quality_scores:
                        stats['average_quality_score'] = sum(quality_scores) / len(quality_scores)
                
                return stats
                
            finally:
                await session.close()
            
        except Exception as e:
            logger.error("Error getting learning stats", error=str(e))
            return {}
    
    async def get_learning_insights(self, ai_type: str) -> Dict[str, Any]:
        """Get learning insights and recommendations"""
        try:
            # Get ML insights
            ml_insights = await self.ml_service.get_ml_insights()
            
            # Get learning stats
            stats = await self.get_learning_stats(ai_type)
            
            insights = {
                'ml_insights': ml_insights,
                'stats': stats,
                'recommendations': []
            }
            
            # Generate recommendations
            if stats.get('recent_approval_rate', 0) < 0.5:
                insights['recommendations'].append("Approval rate is low - consider improving proposal quality")
            
            if stats.get('average_quality_score', 0) < 0.6:
                insights['recommendations'].append("Average quality score is low - retrain ML models")
            
            return insights
            
        except Exception as e:
            logger.error("Error getting learning insights", error=str(e))
            return {} 