"""
Conquest router
"""

from fastapi import APIRouter

router = APIRouter()


@router.get("/")
async def get_conquest():
    """Get conquest information"""
    return {"message": "Conquest router - to be implemented"} 