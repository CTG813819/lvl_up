"""
Approval router
"""

from fastapi import APIRouter

router = APIRouter()


@router.get("/")
async def get_approvals():
    """Get approvals information"""
    return {"message": "Approval router - to be implemented"} 