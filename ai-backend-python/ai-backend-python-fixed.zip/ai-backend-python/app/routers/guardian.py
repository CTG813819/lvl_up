"""
Guardian router
"""

from fastapi import APIRouter

router = APIRouter()


@router.get("/")
async def get_guardian():
    """Get guardian information"""
    return {"message": "Guardian router - to be implemented"} 