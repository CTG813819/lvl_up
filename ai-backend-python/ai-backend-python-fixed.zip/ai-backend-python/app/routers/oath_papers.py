"""
Oath papers router
"""

from fastapi import APIRouter

router = APIRouter()


@router.get("/")
async def get_oath_papers():
    """Get oath papers information"""
    return {"message": "Oath papers router - to be implemented"} 