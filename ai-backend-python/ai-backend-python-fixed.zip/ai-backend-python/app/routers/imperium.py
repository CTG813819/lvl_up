"""
Imperium router
"""

from fastapi import APIRouter

router = APIRouter()


@router.get("/")
async def get_imperium():
    """Get imperium information"""
    return {"message": "Imperium router - to be implemented"} 