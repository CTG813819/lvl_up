import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:provider/provider.dart';
import '../models/ai_notification.dart';
import '../providers/notification_provider.dart';
import '../providers/system_status_provider.dart';
import 'package:uuid/uuid.dart';
import '../main.dart'; // To get the navigatorKey
import 'dart:async';
import 'package:shared_preferences/shared_preferences.dart';

class NotificationService {
  static final NotificationService _instance = NotificationService._internal();
  static NotificationService get instance => _instance;

  static bool suppressNotifications =
      true; // Suppress notifications until app is ready

  final FlutterLocalNotificationsPlugin _notifications =
      FlutterLocalNotificationsPlugin();
  final Uuid _uuid = Uuid();

  bool _isInitialized = false;
  Completer<void>? _initCompleter;

  NotificationService._internal();

  Future<void> initialize() async {
    if (_isInitialized) {
      print('NotificationService: Already initialized');
      return;
    }

    if (_initCompleter != null) {
      print('NotificationService: Initialization already in progress');
      await _initCompleter!.future;
      return;
    }

    _initCompleter = Completer<void>();

    try {
      print('NotificationService: Starting initialization...');

      // Initialize settings based on platform
      const AndroidInitializationSettings androidSettings =
          AndroidInitializationSettings('@drawable/notification_icon');

      // For Windows, we need to provide Windows-specific settings

      const InitializationSettings initSettings = InitializationSettings(
        android: androidSettings,
      );

      await _notifications.initialize(initSettings);

      _isInitialized = true;
      print('NotificationService: Initialization successful');
      _initCompleter?.complete();
    } catch (e) {
      print('NotificationService: Initialization failed: $e');
      _initCompleter?.completeError(e);
      // Don't rethrow - let the app continue without notifications
    }
  }

  Future<void> showNotification({
    required String aiSource,
    required String message,
    String? iconChar,
  }) async {
    if (suppressNotifications) {
      print('NotificationService: Suppressing notification (app not ready)');
      return;
    }

    if (!_isInitialized) {
      print('NotificationService: Not initialized, skipping notification');
      return;
    }

    try {
      const AndroidNotificationDetails androidDetails =
          AndroidNotificationDetails(
            'ai_notifications',
            'AI Notifications',
            channelDescription: 'Notifications from AI systems',
            importance: Importance.high,
            priority: Priority.high,
            showWhen: true,
          );

      const WindowsNotificationDetails windowsDetails =
          WindowsNotificationDetails();

      const NotificationDetails details = NotificationDetails(
        android: androidDetails,
        windows: windowsDetails,
      );

      await _notifications.show(
        DateTime.now().millisecondsSinceEpoch.remainder(100000),
        '$iconChar $aiSource',
        message,
        details,
      );

      print('NotificationService: Notification shown: $aiSource - $message');
    } catch (e) {
      print('NotificationService: Error showing notification: $e');
    }
  }

  Future<void> showProposalNotification({
    required String aiSource,
    required String filePath,
    required String proposalType,
  }) async {
    String message = '';
    String iconChar = '';

    switch (proposalType) {
      case 'created':
        message = 'New proposal for $filePath';
        iconChar = '💡';
        break;
      case 'approved':
        message = 'Proposal for $filePath approved';
        iconChar = '✅';
        break;
      case 'rejected':
        message = 'Proposal for $filePath rejected';
        iconChar = '❌';
        break;
      case 'applied':
        message = 'Proposal applied to $filePath';
        iconChar = '🚀';
        break;
      default:
        message = 'Proposal update for $filePath';
        iconChar = '📝';
    }

    await showNotification(
      aiSource: aiSource,
      message: message,
      iconChar: iconChar,
    );
  }

  Future<void> showSystemStatusNotification({
    required String title,
    required String message,
    required SystemHealth status,
  }) async {
    final context = navigatorKey.currentContext;
    if (context == null) return;

    final notificationProvider = Provider.of<NotificationProvider>(
      context,
      listen: false,
    );

    // Add to in-app notification center
    notificationProvider.addNotification(
      title,
      message,
      'System',
      DateTime.now(),
    );

    // Show system notification
    final androidDetails = AndroidNotificationDetails(
      'system_channel_id',
      'System Notifications',
      channelDescription: 'System status and health notifications',
      importance: Importance.high,
      priority: Priority.high,
      icon: 'notification_icon',
      color: _getStatusColor(status),
    );
    final platformDetails = NotificationDetails(android: androidDetails);

    await _notifications.show(
      DateTime.now().millisecondsSinceEpoch % 100000,
      title,
      message,
      platformDetails,
    );
  }

  Future<void> showBackendActivityNotification({
    required String activity,
    required String details,
    bool isError = false,
  }) async {
    final title = isError ? 'Backend Error' : 'Backend Activity';
    final message = '$activity: $details';

    await showSystemStatusNotification(
      title: title,
      message: message,
      status: isError ? SystemHealth.critical : SystemHealth.healthy,
    );
  }

  // New methods for AI-specific notifications
  Future<void> showAIProposalNotification({
    required String aiType,
    required String action,
    required String filePath,
    String? details,
  }) async {
    String title = '';
    String message = '';
    String iconChar = '';

    switch (action) {
      case 'created':
        title = 'New AI Proposal';
        message = '$aiType created a proposal for $filePath';
        iconChar = '💡';
        break;
      case 'approved':
        title = 'Proposal Approved';
        message = 'Proposal for $filePath was approved';
        iconChar = '✅';
        break;
      case 'rejected':
        title = 'Proposal Rejected';
        message = 'Proposal for $filePath was rejected';
        iconChar = '❌';
        break;
      case 'applied':
        title = 'Proposal Applied';
        message = 'Proposal for $filePath was applied';
        iconChar = '🚀';
        break;
      default:
        title = 'AI Activity';
        message = '$aiType: $action on $filePath';
        iconChar = '🤖';
    }

    if (details != null) {
      message += '\n$details';
    }

    await showNotification(
      aiSource: aiType,
      message: message,
      iconChar: iconChar,
    );
  }

  Future<void> showConquestNotification({
    required String action,
    required String appName,
    String? details,
    bool isError = false,
  }) async {
    String title = '';
    String message = '';
    String iconChar = '';

    switch (action) {
      case 'app_created':
        title = 'New App Created';
        message = 'Conquest AI created: $appName';
        iconChar = '📱';
        break;
      case 'apk_built':
        title = 'APK Ready';
        message = 'APK for $appName is ready for download';
        iconChar = '📦';
        break;
      case 'repo_created':
        title = 'Repository Created';
        message = 'GitHub repo created for $appName';
        iconChar = '📤';
        break;
      case 'build_started':
        title = 'Build Started';
        message = 'Building APK for $appName...';
        iconChar = '🔨';
        break;
      case 'build_failed':
        title = 'Build Failed';
        message = 'APK build failed for $appName';
        iconChar = '💥';
        break;
      case 'app_improved':
        title = 'App Improved';
        message = 'Conquest AI improved: $appName';
        iconChar = '🚀';
        break;
      default:
        title = 'Conquest Activity';
        message = 'Conquest AI: $action on $appName';
        iconChar = '⚔️';
    }

    if (details != null) {
      message += '\n$details';
    }

    await showNotification(
      aiSource: 'Conquest AI',
      message: message,
      iconChar: iconChar,
    );
  }

  Future<void> showAILearningNotification({
    required String aiType,
    required String learningType,
    String? details,
  }) async {
    String title = 'AI Learning';
    String message = '$aiType learned: $learningType';
    String iconChar = '🧠';

    if (details != null) {
      message += '\n$details';
    }

    await showNotification(
      aiSource: aiType,
      message: message,
      iconChar: iconChar,
    );
  }

  Future<void> showOathPapersNotification({
    required String action,
    String? paperTitle,
    String? details,
  }) async {
    String title = '';
    String message = '';
    String iconChar = '📜';

    switch (action) {
      case 'uploaded':
        title = 'Oath Paper Uploaded';
        message = 'New oath paper uploaded: ${paperTitle ?? 'Untitled'}';
        break;
      case 'processed':
        title = 'Oath Paper Processed';
        message = 'AIs learned from: ${paperTitle ?? 'Oath Paper'}';
        break;
      case 'insights_generated':
        title = 'AI Insights Generated';
        message = 'New insights from oath papers';
        break;
      default:
        title = 'Oath Papers Activity';
        message = 'Oath Papers: $action';
    }

    if (details != null) {
      message += '\n$details';
    }

    await showNotification(
      aiSource: 'Oath Papers',
      message: message,
      iconChar: iconChar,
    );
  }

  Future<void> showGitHubNotification({
    required String action,
    String? repoName,
    String? details,
  }) async {
    String title = '';
    String message = '';
    String iconChar = '🐙';

    switch (action) {
      case 'repo_created':
        title = 'Repository Created';
        message = 'New GitHub repo: ${repoName ?? 'Unknown'}';
        break;
      case 'code_pushed':
        title = 'Code Pushed';
        message = 'Code pushed to: ${repoName ?? 'Repository'}';
        break;
      case 'issue_created':
        title = 'Issue Created';
        message = 'New issue in: ${repoName ?? 'Repository'}';
        break;
      case 'pull_request':
        title = 'Pull Request';
        message = 'PR created in: ${repoName ?? 'Repository'}';
        break;
      default:
        title = 'GitHub Activity';
        message = 'GitHub: $action';
    }

    if (details != null) {
      message += '\n$details';
    }

    await showNotification(
      aiSource: 'GitHub',
      message: message,
      iconChar: iconChar,
    );
  }

  Color _getStatusColor(SystemHealth status) {
    switch (status) {
      case SystemHealth.healthy:
        return Colors.green;
      case SystemHealth.warning:
        return Colors.orange;
      case SystemHealth.critical:
        return Colors.red;
      case SystemHealth.offline:
        return Colors.grey;
      case SystemHealth.unknown:
        return Colors.grey;
    }
  }

  AINotification _createAINotification(
    String aiSource,
    String message,
    String iconChar,
  ) {
    IconData iconData;
    Color iconColor;

    switch (aiSource) {
      case 'The Imperium':
        iconData = Icons.auto_awesome;
        iconColor = Colors.amber;
        break;
      case 'Mechanicum':
        iconData = Icons.shield;
        iconColor = Colors.blue;
        break;
      case 'AI Sandbox':
        iconData = Icons.science;
        iconColor = Colors.green;
        break;
      default:
        iconData = Icons.info;
        iconColor = Colors.grey;
    }

    return AINotification(
      id: _uuid.v4(),
      title: aiSource,
      body: message,
      aiSource: aiSource,
      icon: iconData,
      iconColor: iconColor,
      timestamp: DateTime.now(),
    );
  }

  String? _getAndroidIconName(String aiSource) {
    // Use the notification_icon for all AI sources
    // This icon exists in android/app/src/main/res/drawable/notification_icon.xml
    return 'notification_icon';
  }
}
