import 'dart:async';
import 'dart:developer' as developer;

/// App Logger Service
/// Captures all console logs and makes them available to the terminal
class AppLogger {
  static final AppLogger instance = AppLogger._internal();
  factory AppLogger() => instance;
  AppLogger._internal();

  final StreamController<LogEntry> _logController = StreamController<LogEntry>.broadcast();
  final List<LogEntry> _logHistory = [];
  bool _isInitialized = false;

  Stream<LogEntry> get logStream => _logController.stream;
  List<LogEntry> get logHistory => List.unmodifiable(_logHistory);

  /// Initialize the logger
  void initialize() {
    if (_isInitialized) return;
    
    _isInitialized = true;
    log('AppLogger initialized', 'AppLogger', LogLevel.info);
  }

  /// Parse a log message to extract source and level
  LogEntry _parseLogEntry(String message) {
    // Try to extract source from common patterns
    String source = 'App';
    LogLevel level = LogLevel.info;
    
    // Check for common log patterns
    if (message.contains('[PROPOSAL_PROVIDER]')) {
      source = 'PROPOSAL_PROVIDER';
      if (message.contains('❌') || message.contains('ERROR')) {
        level = LogLevel.error;
      } else if (message.contains('⚠️') || message.contains('WARNING')) {
        level = LogLevel.warning;
      } else if (message.contains('✅') || message.contains('SUCCESS')) {
        level = LogLevel.success;
      }
    } else if (message.contains('[AI_LEARNING_PROVIDER]')) {
      source = 'AI_LEARNING_PROVIDER';
      if (message.contains('❌') || message.contains('ERROR')) {
        level = LogLevel.error;
      } else if (message.contains('⚠️') || message.contains('WARNING')) {
        level = LogLevel.warning;
      } else if (message.contains('✅') || message.contains('SUCCESS')) {
        level = LogLevel.success;
      }
    } else if (message.contains('[SYSTEM_STATUS_PROVIDER]')) {
      source = 'SYSTEM_STATUS_PROVIDER';
      if (message.contains('❌') || message.contains('ERROR')) {
        level = LogLevel.error;
      } else if (message.contains('⚠️') || message.contains('WARNING')) {
        level = LogLevel.warning;
      } else if (message.contains('✅') || message.contains('SUCCESS')) {
        level = LogLevel.success;
      }
    } else if (message.contains('🧪 AI Sandbox:')) {
      source = 'AI_SANDBOX';
      if (message.contains('WARNING:')) {
        level = LogLevel.warning;
      }
    } else if (message.contains('🧠 AI:')) {
      source = 'AI_BRAIN';
    } else if (message.contains('HomePage:')) {
      source = 'HomePage';
    } else if (message.contains('D/HWUI')) {
      source = 'Android';
      level = LogLevel.warning;
    } else if (message.contains('I/flutter')) {
      source = 'Flutter';
    }

    return LogEntry(
      message: message,
      source: source,
      level: level,
      timestamp: DateTime.now(),
    );
  }

  /// Add a log entry
  void _addLogEntry(LogEntry entry) {
    _logHistory.add(entry);
    
    // Keep only last 500 entries to prevent memory issues
    if (_logHistory.length > 500) {
      _logHistory.removeAt(0);
    }
    
    // Send to stream
    _logController.add(entry);
  }

  /// Manual log method - use this instead of print for captured logging
  void log(String message, String source, LogLevel level) {
    final entry = LogEntry(
      message: message,
      source: source,
      level: level,
      timestamp: DateTime.now(),
    );
    _addLogEntry(entry);
    
    // Also print to console for debugging
    print('[$source] ${level.name.toUpperCase()}: $message');
  }

  /// Log info message
  void info(String message, [String source = 'App']) {
    log(message, source, LogLevel.info);
  }

  /// Log warning message
  void warning(String message, [String source = 'App']) {
    log(message, source, LogLevel.warning);
  }

  /// Log error message
  void error(String message, [String source = 'App']) {
    log(message, source, LogLevel.error);
  }

  /// Log success message
  void success(String message, [String source = 'App']) {
    log(message, source, LogLevel.success);
  }

  /// Log debug message
  void debug(String message, [String source = 'App']) {
    log(message, source, LogLevel.debug);
  }

  /// Clear log history
  void clearHistory() {
    _logHistory.clear();
  }

  /// Get recent logs
  List<LogEntry> getRecentLogs(int count) {
    if (_logHistory.length <= count) {
      return _logHistory;
    }
    return _logHistory.sublist(_logHistory.length - count);
  }

  /// Dispose
  void dispose() {
    _logController.close();
  }
}

/// Log Entry
class LogEntry {
  final String message;
  final String source;
  final LogLevel level;
  final DateTime timestamp;

  LogEntry({
    required this.message,
    required this.source,
    required this.level,
    required this.timestamp,
  });

  @override
  String toString() {
    return '[$source] ${level.name.toUpperCase()}: $message';
  }
}

/// Log Level
enum LogLevel {
  debug,
  info,
  warning,
  error,
  success,
} 