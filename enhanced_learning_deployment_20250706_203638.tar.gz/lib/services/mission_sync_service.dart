import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import '../mission_data.dart';

class MissionSyncService {
  static const String _baseUrl =
      'http://ec2-34-202-215-209.compute-1.amazonaws.com:4000';
  static const String _missionsKey = 'missions';

  /// Sync missions from local storage to backend
  static Future<Map<String, dynamic>> syncMissionsToBackend() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final missionsJson = prefs.getStringList(_missionsKey) ?? [];

      if (missionsJson.isEmpty) {
        return {
          'success': false,
          'message': 'No missions found in local storage',
          'synced_count': 0,
          'updated_count': 0,
        };
      }

      // Parse missions from JSON
      final List<Map<String, dynamic>> missionsData = [];

      for (final missionJson in missionsJson) {
        try {
          final missionMap = json.decode(missionJson) as Map<String, dynamic>;

          // Convert MissionData to backend format
          final backendMission = _convertMissionToBackendFormat(missionMap);
          missionsData.add(backendMission);
        } catch (e) {
          print('Error parsing mission JSON: $e');
          continue;
        }
      }

      if (missionsData.isEmpty) {
        return {
          'success': false,
          'message': 'No valid missions to sync',
          'synced_count': 0,
          'updated_count': 0,
        };
      }

      // Send to backend
      final response = await http.post(
        Uri.parse('$_baseUrl/api/missions/sync'),
        headers: {'Content-Type': 'application/json'},
        body: json.encode(missionsData),
      );

      if (response.statusCode == 200) {
        final responseData = json.decode(response.body) as Map<String, dynamic>;
        return {
          'success': true,
          'message': 'Missions synced successfully',
          'synced_count': responseData['data']['synced_count'] ?? 0,
          'updated_count': responseData['data']['updated_count'] ?? 0,
          'total_processed': responseData['data']['total_processed'] ?? 0,
        };
      } else {
        return {
          'success': false,
          'message': 'Failed to sync missions: ${response.statusCode}',
          'synced_count': 0,
          'updated_count': 0,
        };
      }
    } catch (e) {
      return {
        'success': false,
        'message': 'Error syncing missions: $e',
        'synced_count': 0,
        'updated_count': 0,
      };
    }
  }

  /// Convert frontend mission format to backend format
  static Map<String, dynamic> _convertMissionToBackendFormat(
    Map<String, dynamic> missionMap,
  ) {
    return {
      'id': missionMap['id'],
      'mission_id': missionMap['missionId'],
      'title': missionMap['title'],
      'description': missionMap['description'],
      'mission_type': missionMap['missionType'],
      'is_completed': missionMap['isCompleted'] ?? false,
      'has_failed': missionMap['hasFailed'] ?? false,
      'mastery_id': missionMap['masteryId'],
      'value': missionMap['value']?.toDouble(),
      'is_counter_based': missionMap['isCounterBased'] ?? false,
      'current_count': missionMap['currentCount'] ?? 0,
      'target_count': missionMap['targetCount'] ?? 0,
      'mastery_value': missionMap['masteryValue']?.toDouble() ?? 0.0,
      'linked_mastery_id': missionMap['linkedMasteryId'],
      'notification_id': missionMap['notificationId'] ?? 0,
      'scheduled_notification_id': missionMap['scheduledNotificationId'],
      'image_url': missionMap['imageUrl'],
      'subtasks_data': missionMap['subtasksData'],
      'subtask_mastery_values': missionMap['subtaskMasteryValues'],
      'bolt_color': missionMap['boltColor'],
      'timelapse_color': missionMap['timelapseColor'],
      'subtasks': _convertSubtasksToBackendFormat(missionMap['subtasks']),
    };
  }

  /// Convert subtasks to backend format
  static List<Map<String, dynamic>> _convertSubtasksToBackendFormat(
    dynamic subtasks,
  ) {
    if (subtasks == null || subtasks is! List) {
      return [];
    }

    return subtasks.map<Map<String, dynamic>>((subtask) {
      return {
        'id': subtask['id'],
        'name': subtask['name'],
        'required_completions': subtask['requiredCompletions'] ?? 0,
        'current_completions': subtask['currentCompletions'] ?? 0,
        'linked_mastery_id': subtask['linkedMasteryId'],
        'mastery_value': subtask['masteryValue']?.toDouble() ?? 0.0,
        'is_counter_based': subtask['isCounterBased'] ?? false,
        'current_count': subtask['currentCount'] ?? 0,
        'bolt_color': subtask['boltColor'],
      };
    }).toList();
  }

  /// Get mission statistics from backend
  static Future<Map<String, dynamic>> getMissionStatistics() async {
    try {
      final response = await http.get(
        Uri.parse('$_baseUrl/api/missions/statistics'),
        headers: {'Content-Type': 'application/json'},
      );

      if (response.statusCode == 200) {
        final responseData = json.decode(response.body) as Map<String, dynamic>;
        return {'success': true, 'data': responseData['data']};
      } else {
        return {
          'success': false,
          'message': 'Failed to get mission statistics: ${response.statusCode}',
        };
      }
    } catch (e) {
      return {
        'success': false,
        'message': 'Error getting mission statistics: $e',
      };
    }
  }

  /// Run mission health check on backend
  static Future<Map<String, dynamic>> runMissionHealthCheck() async {
    try {
      final response = await http.post(
        Uri.parse('$_baseUrl/api/missions/health-check'),
        headers: {'Content-Type': 'application/json'},
      );

      if (response.statusCode == 200) {
        final responseData = json.decode(response.body) as Map<String, dynamic>;
        return {'success': true, 'data': responseData['data']};
      } else {
        return {
          'success': false,
          'message':
              'Failed to run mission health check: ${response.statusCode}',
        };
      }
    } catch (e) {
      return {
        'success': false,
        'message': 'Error running mission health check: $e',
      };
    }
  }

  /// Get missions from backend
  static Future<Map<String, dynamic>> getMissionsFromBackend({
    int limit = 100,
    int offset = 0,
    bool? completed,
  }) async {
    try {
      final queryParams = <String, String>{
        'limit': limit.toString(),
        'offset': offset.toString(),
      };

      if (completed != null) {
        queryParams['completed'] = completed.toString();
      }

      final uri = Uri.parse(
        '$_baseUrl/api/missions',
      ).replace(queryParameters: queryParams);

      final response = await http.get(
        uri,
        headers: {'Content-Type': 'application/json'},
      );

      if (response.statusCode == 200) {
        final responseData = json.decode(response.body) as Map<String, dynamic>;
        return {'success': true, 'data': responseData['data']};
      } else {
        return {
          'success': false,
          'message': 'Failed to get missions: ${response.statusCode}',
        };
      }
    } catch (e) {
      return {'success': false, 'message': 'Error getting missions: $e'};
    }
  }
}
