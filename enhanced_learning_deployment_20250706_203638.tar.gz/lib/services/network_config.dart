import 'dart:io';
import 'package:flutter/foundation.dart';

class NetworkConfig {
  // AWS EC2 Backend URL
  static const String baseUrl = 'http://34.202.215.209:4000';
  
  // API Endpoints
  static const String apiUrl = '$baseUrl/api';
  
  // Socket.IO URL for real-time updates
  static const String socketUrl = 'http://34.202.215.209:4000';
  
  // Timeout settings
  static const Duration connectionTimeout = Duration(seconds: 30);
  static const Duration receiveTimeout = Duration(seconds: 30);
  
  // Retry settings
  static const int maxRetries = 3;
  static const Duration retryDelay = Duration(seconds: 2);
  
  /// Get the appropriate backend URL based on platform and environment
  static String get backendUrl => baseUrl;
  
  /// Get all possible backend URLs for testing
  static List<String> get allBackendUrls => [
    baseUrl, // AWS production
    'http://10.0.2.2:4000', // Android emulator
    'http://192.168.1.118:4000', // Local network
    'http://34.202.215.209:4000', // AWS (for production)
  ];
  
  /// Test connectivity to all backend URLs
  static Future<Map<String, bool>> testConnectivity() async {
    final results = <String, bool>{};
    
    for (final url in allBackendUrls) {
      try {
        final client = HttpClient();
        final request = await client.getUrl(Uri.parse('$url/api/health'));
        final response = await request.close();
        results[url] = response.statusCode == 200;
      } catch (e) {
        results[url] = false;
      }
    }
    
    return results;
  }
  
  /// Get the best available backend URL
  static Future<String> getBestBackendUrl() async {
    final connectivityResults = await testConnectivity();
    
    // Return the first working URL
    for (final entry in connectivityResults.entries) {
      if (entry.value) {
        return entry.key;
      }
    }
    
    // Fallback to default
    return backendUrl;
  }
} 