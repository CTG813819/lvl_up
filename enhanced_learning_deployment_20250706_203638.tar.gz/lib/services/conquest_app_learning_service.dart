import 'dart:convert';
import 'dart:developer';
import 'package:http/http.dart' as http;
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'network_config.dart';

/// Conquest AI App Learning Service
/// Automatically collects and sends learning data from Conquest AI generated apps
class ConquestAppLearningService {
  static String get _baseUrl => NetworkConfig.backendUrl; // Default backend URL
  static String get _conquestBackendUrl => NetworkConfig.backendUrl; // Conquest AI backend
  
  static ConquestAppLearningService? _instance;
  static ConquestAppLearningService get instance => _instance ??= ConquestAppLearningService._();
  
  ConquestAppLearningService._();
  
  String? _appId;
  String? _appName;
  String? _userId;
  String? _sessionId;
  String? _platform;
  String? _appVersion;
  String? _deviceInfo;
  
  /// Initialize the learning service
  Future<void> initialize({
    required String appId,
    required String appName,
    String? userId,
  }) async {
    _appId = appId;
    _appName = appName;
    _userId = userId;
    _sessionId = _generateSessionId();
    
    // Get device and app information
    await _initializeDeviceInfo();
    
    log('[CONQUEST_LEARNING] ✅ Learning service initialized for app: $appName');
  }
  
  /// Initialize device and app information
  Future<void> _initializeDeviceInfo() async {
    try {
      // Get app version
      final packageInfo = await PackageInfo.fromPlatform();
      _appVersion = packageInfo.version;
      
      // Get device info
      final deviceInfo = DeviceInfoPlugin();
      if (kIsWeb) {
        final webInfo = await deviceInfo.webBrowserInfo;
        _platform = 'web';
        _deviceInfo = '${webInfo.browserName.name} ${webInfo.appVersion}';
      } else if (defaultTargetPlatform == TargetPlatform.android) {
        final androidInfo = await deviceInfo.androidInfo;
        _platform = 'android';
        _deviceInfo = '${androidInfo.brand} ${androidInfo.model}';
      } else if (defaultTargetPlatform == TargetPlatform.iOS) {
        final iosInfo = await deviceInfo.iosInfo;
        _platform = 'ios';
        _deviceInfo = '${iosInfo.name} ${iosInfo.systemVersion}';
      } else {
        _platform = 'unknown';
        _deviceInfo = 'unknown';
      }
    } catch (e) {
      log('[CONQUEST_LEARNING] ⚠️ Error getting device info: $e');
      _platform = 'unknown';
      _deviceInfo = 'unknown';
    }
  }
  
  /// Generate a unique session ID
  String _generateSessionId() {
    return '${DateTime.now().millisecondsSinceEpoch}_${_appId}_${_userId ?? 'anonymous'}';
  }
  
  /// Send user feedback to Conquest AI
  Future<bool> sendFeedback({
    required String type,
    required double rating,
    String? comment,
    String? category,
    String? severity,
    List<String>? features,
    List<String>? issues,
    List<String>? suggestions,
  }) async {
    try {
      final feedback = {
        'appId': _appId,
        'userId': _userId ?? 'anonymous',
        'type': type,
        'rating': rating,
        'comment': comment ?? '',
        'category': category ?? 'general',
        'severity': severity ?? 'low',
        'appVersion': _appVersion ?? '1.0.0',
        'platform': _platform ?? 'unknown',
        'sessionId': _sessionId,
        'features': features ?? [],
        'issues': issues ?? [],
        'suggestions': suggestions ?? [],
      };
      
      // Send to local backend
      final localResponse = await http.post(
        Uri.parse('$_baseUrl/api/feedback'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode(feedback),
      );
      
      if (localResponse.statusCode == 200) {
        log('[CONQUEST_LEARNING] ✅ Feedback sent to local backend');
      } else {
        log('[CONQUEST_LEARNING] ⚠️ Failed to send feedback to local backend: ${localResponse.statusCode}');
      }
      
      // Send to Conquest AI backend
      final conquestResponse = await http.post(
        Uri.parse('$_conquestBackendUrl/api/conquest/app-feedback'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode(feedback),
      );
      
      if (conquestResponse.statusCode == 200) {
        log('[CONQUEST_LEARNING] ✅ Feedback sent to Conquest AI');
        return true;
      } else {
        log('[CONQUEST_LEARNING] ⚠️ Failed to send feedback to Conquest AI: ${conquestResponse.statusCode}');
        return false;
      }
    } catch (e) {
      log('[CONQUEST_LEARNING] ❌ Error sending feedback: $e');
      return false;
    }
  }
  
  /// Send usage data to Conquest AI
  Future<bool> sendUsage({
    required List<String> screenViews,
    required Map<String, int> featureUsage,
    required int timeSpent,
    required List<Map<String, dynamic>> interactions,
    Map<String, dynamic>? performance,
    List<Map<String, dynamic>>? errors,
    List<Map<String, dynamic>>? crashes,
  }) async {
    try {
      final usage = {
        'appId': _appId,
        'sessionId': _sessionId,
        'userId': _userId ?? 'anonymous',
        'screenViews': screenViews,
        'featureUsage': featureUsage,
        'timeSpent': timeSpent,
        'interactions': interactions,
        'performance': performance ?? {},
        'errors': errors ?? [],
        'crashes': crashes ?? [],
      };
      
      // Send to local backend
      final localResponse = await http.post(
        Uri.parse('$_baseUrl/api/usage'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode(usage),
      );
      
      if (localResponse.statusCode == 200) {
        log('[CONQUEST_LEARNING] ✅ Usage data sent to local backend');
      } else {
        log('[CONQUEST_LEARNING] ⚠️ Failed to send usage data to local backend: ${localResponse.statusCode}');
      }
      
      // Send to Conquest AI backend
      final conquestResponse = await http.post(
        Uri.parse('$_conquestBackendUrl/api/conquest/app-usage'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode(usage),
      );
      
      if (conquestResponse.statusCode == 200) {
        log('[CONQUEST_LEARNING] ✅ Usage data sent to Conquest AI');
        return true;
      } else {
        log('[CONQUEST_LEARNING] ⚠️ Failed to send usage data to Conquest AI: ${conquestResponse.statusCode}');
        return false;
      }
    } catch (e) {
      log('[CONQUEST_LEARNING] ❌ Error sending usage data: $e');
      return false;
    }
  }
  
  /// Send error report to Conquest AI
  Future<bool> sendError({
    required String type,
    required String message,
    String? stackTrace,
    String? severity,
    Map<String, dynamic>? context,
    String? userAction,
    String? screen,
  }) async {
    try {
      final error = {
        'appId': _appId,
        'type': type,
        'message': message,
        'stackTrace': stackTrace ?? '',
        'severity': severity ?? 'medium',
        'userId': _userId ?? 'anonymous',
        'sessionId': _sessionId,
        'appVersion': _appVersion ?? '1.0.0',
        'platform': _platform ?? 'unknown',
        'context': context ?? {},
        'userAction': userAction ?? '',
        'screen': screen ?? '',
      };
      
      // Send to local backend
      final localResponse = await http.post(
        Uri.parse('$_baseUrl/api/error'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode(error),
      );
      
      if (localResponse.statusCode == 200) {
        log('[CONQUEST_LEARNING] ✅ Error report sent to local backend');
      } else {
        log('[CONQUEST_LEARNING] ⚠️ Failed to send error report to local backend: ${localResponse.statusCode}');
      }
      
      // Send to Conquest AI backend
      final conquestResponse = await http.post(
        Uri.parse('$_conquestBackendUrl/api/conquest/app-error'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode(error),
      );
      
      if (conquestResponse.statusCode == 200) {
        log('[CONQUEST_LEARNING] ✅ Error report sent to Conquest AI');
        return true;
      } else {
        log('[CONQUEST_LEARNING] ⚠️ Failed to send error report to Conquest AI: ${conquestResponse.statusCode}');
        return false;
      }
    } catch (e) {
      log('[CONQUEST_LEARNING] ❌ Error sending error report: $e');
      return false;
    }
  }
  
  /// Send performance metrics to Conquest AI
  Future<bool> sendPerformance({
    required int loadTime,
    required int renderTime,
    required double memoryUsage,
    required double cpuUsage,
    required int networkLatency,
    required double frameRate,
    required double batteryUsage,
  }) async {
    try {
      final metrics = {
        'appId': _appId,
        'loadTime': loadTime,
        'renderTime': renderTime,
        'memoryUsage': memoryUsage,
        'cpuUsage': cpuUsage,
        'networkLatency': networkLatency,
        'frameRate': frameRate,
        'batteryUsage': batteryUsage,
        'platform': _platform ?? 'unknown',
        'appVersion': _appVersion ?? '1.0.0',
      };
      
      // Send to local backend
      final localResponse = await http.post(
        Uri.parse('$_baseUrl/api/performance'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode(metrics),
      );
      
      if (localResponse.statusCode == 200) {
        log('[CONQUEST_LEARNING] ✅ Performance metrics sent to local backend');
      } else {
        log('[CONQUEST_LEARNING] ⚠️ Failed to send performance metrics to local backend: ${localResponse.statusCode}');
      }
      
      // Send to Conquest AI backend
      final conquestResponse = await http.post(
        Uri.parse('$_conquestBackendUrl/api/conquest/app-performance'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode(metrics),
      );
      
      if (conquestResponse.statusCode == 200) {
        log('[CONQUEST_LEARNING] ✅ Performance metrics sent to Conquest AI');
        return true;
      } else {
        log('[CONQUEST_LEARNING] ⚠️ Failed to send performance metrics to Conquest AI: ${conquestResponse.statusCode}');
        return false;
      }
    } catch (e) {
      log('[CONQUEST_LEARNING] ❌ Error sending performance metrics: $e');
      return false;
    }
  }
  
  /// Get analytics data from local backend
  Future<Map<String, dynamic>?> getAnalytics() async {
    try {
      final response = await http.get(Uri.parse('$_baseUrl/api/analytics'));
      
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        log('[CONQUEST_LEARNING] ✅ Analytics data retrieved');
        return data['data'] as Map<String, dynamic>;
      } else {
        log('[CONQUEST_LEARNING] ⚠️ Failed to get analytics: ${response.statusCode}');
        return null;
      }
    } catch (e) {
      log('[CONQUEST_LEARNING] ❌ Error getting analytics: $e');
      return null;
    }
  }
  
  /// Track screen view
  void trackScreenView(String screenName) {
    // This would be called when user navigates to a screen
    log('[CONQUEST_LEARNING] 📱 Screen viewed: $screenName');
  }
  
  /// Track feature usage
  void trackFeatureUsage(String featureName) {
    // This would be called when user uses a feature
    log('[CONQUEST_LEARNING] 🔧 Feature used: $featureName');
  }
  
  /// Track user interaction
  void trackInteraction(String action, {Map<String, dynamic>? parameters}) {
    // This would be called when user performs an action
    log('[CONQUEST_LEARNING] 👆 Interaction: $action');
  }
  
  /// Set user ID
  void setUserId(String userId) {
    _userId = userId;
    log('[CONQUEST_LEARNING] 👤 User ID set: $userId');
  }
  
  /// Get current session ID
  String? get sessionId => _sessionId;
  
  /// Get current user ID
  String? get userId => _userId;
  
  /// Get app ID
  String? get appId => _appId;
  
  /// Get app name
  String? get appName => _appName;
}

/// Extension to easily track errors in Flutter apps
extension ConquestErrorTracking on Object {
  /// Track an error with Conquest AI
  Future<bool> trackError({
    String? type,
    String? userAction,
    String? screen,
    Map<String, dynamic>? context,
  }) async {
    final error = this;
    final errorType = type ?? error.runtimeType.toString();
    final errorMessage = error.toString();
    
    return await ConquestAppLearningService.instance.sendError(
      type: errorType,
      message: errorMessage,
      severity: 'medium',
      context: context,
      userAction: userAction,
      screen: screen,
    );
  }
}

/// Mixin to easily add learning capabilities to widgets
mixin ConquestLearningMixin {
  /// Track screen view when widget is built
  void trackScreenView(String screenName) {
    ConquestAppLearningService.instance.trackScreenView(screenName);
  }
  
  /// Track feature usage
  void trackFeatureUsage(String featureName) {
    ConquestAppLearningService.instance.trackFeatureUsage(featureName);
  }
  
  /// Track user interaction
  void trackInteraction(String action, {Map<String, dynamic>? parameters}) {
    ConquestAppLearningService.instance.trackInteraction(action, parameters: parameters);
  }
} 