import 'dart:convert';
import 'dart:async';
import 'dart:math';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:dio/dio.dart';
import '../models/conquest_app.dart';
import 'notification_service.dart';
import 'network_config.dart';

/// Conquest AI Service
/// Handles aggressive app building and learning from other AIs and internet resources
class ConquestAIService {
  static final ConquestAIService _instance = ConquestAIService._internal();
  factory ConquestAIService() => _instance;
  ConquestAIService._internal();

  static const String _conquestStorageKey = 'conquest_ai_data';
  static const String _conquestLogsKey = 'conquest_ai_logs';

  // Conquest AI data structure
  Map<String, dynamic> _conquestData = {
    'isActive': false,
    'operationalHours': {'start': '05:00', 'end': '23:30'},
    'learningData': {
      'fromImperium': [],
      'fromGuardian': [],
      'fromSandbox': [],
      'fromInternet': [],
      'ownExperiences': [],
    },
    'successPatterns': [],
    'failurePatterns': [],
    'currentApps': [],
    'completedApps': [],
    'totalAppsBuilt': 0,
    'successRate': 0.0,
    'lastActive': null,
    'debugLog': [],
  };

  // Stream controllers for real-time updates
  final StreamController<List<ConquestApp>> _appsUpdateController =
      StreamController<List<ConquestApp>>.broadcast();
  final StreamController<Map<String, dynamic>> _conquestUpdateController =
      StreamController<Map<String, dynamic>>.broadcast();
  final StreamController<String> _conquestEventController =
      StreamController<String>.broadcast();
  final StreamController<Map<String, dynamic>> _debugOutputController =
      StreamController<Map<String, dynamic>>.broadcast();

  // HTTP client for API calls
  Dio? _dio;

  Stream<List<ConquestApp>> get appsUpdateStream =>
      _appsUpdateController.stream;
  Stream<Map<String, dynamic>> get conquestUpdateStream =>
      _conquestUpdateController.stream;
  Stream<String> get conquestEventStream => _conquestEventController.stream;
  Stream<Map<String, dynamic>> get debugOutputStream =>
      _debugOutputController.stream;

  /// Initialize the Conquest AI service
  Future<void> initialize() async {
    print('[CONQUEST_AI_SERVICE] 🐉 Initializing Conquest AI service...');

    // Initialize Dio HTTP client
    _dio = Dio(
      BaseOptions(
        baseUrl: NetworkConfig.backendUrl,
        connectTimeout: const Duration(seconds: 30),
        receiveTimeout: const Duration(seconds: 30),
        headers: {'Content-Type': 'application/json'},
      ),
    );

    await _loadConquestData();
    await checkOperationalHours();

    // Fetch progress logs in background (don't block initialization)
    fetchProgressLogsFromBackend().catchError((e) {
      print(
        '[CONQUEST_AI_SERVICE] ℹ️ Progress logs fetch failed (non-critical): $e',
      );
    });

    print('[CONQUEST_AI_SERVICE] ✅ Conquest AI service initialized');
  }

  /// Load Conquest AI data from local storage
  Future<void> _loadConquestData() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final conquestJson = prefs.getString(_conquestStorageKey);

      if (conquestJson != null) {
        final loadedData = jsonDecode(conquestJson) as Map<String, dynamic>;
        _conquestData = Map<String, dynamic>.from(loadedData);

        // Ensure the data structure is properly initialized
        _conquestData['currentApps'] = _conquestData['currentApps'] ?? [];
        _conquestData['completedApps'] = _conquestData['completedApps'] ?? [];
        _conquestData['learningData'] =
            _conquestData['learningData'] ??
            {
              'fromImperium': [],
              'fromGuardian': [],
              'fromSandbox': [],
              'fromInternet': [],
              'ownExperiences': [],
            };
        _conquestData['debugLog'] = _conquestData['debugLog'] ?? [];

        // Check if operational hours need to be updated to new format
        final currentOpHours = _conquestData['operationalHours'];
        if (currentOpHours != null) {
          final start = currentOpHours['start'];
          final end = currentOpHours['end'];

          // If we have old operational hours, update them
          if ((start == '09:00' && end == '18:00') ||
              (start == '05:00' && end == '21:00')) {
            print(
              '[CONQUEST_AI_SERVICE] 🔄 Updating old operational hours to new format',
            );
            print(
              '[CONQUEST_AI_SERVICE] 🔄 Old hours: $start-$end, New hours: 05:00-23:30',
            );
            _conquestData['operationalHours'] = {
              'start': '05:00',
              'end': '23:30',
            };
            await _saveConquestData();
          }
        }

        print('[CONQUEST_AI_SERVICE] 📚 Loaded existing Conquest AI data');
        print(
          '[CONQUEST_AI_SERVICE] 📚 Current operational hours: ${_conquestData['operationalHours']}',
        );
      } else {
        print(
          '[CONQUEST_AI_SERVICE] 📚 No existing Conquest AI data found, using defaults',
        );
      }
    } catch (e) {
      print('[CONQUEST_AI_SERVICE] ❌ Error loading Conquest AI data: $e');
      // Reset to defaults if there's an error
      _conquestData = {
        'isActive': false,
        'operationalHours': {'start': '05:00', 'end': '23:30'},
        'learningData': {
          'fromImperium': [],
          'fromGuardian': [],
          'fromSandbox': [],
          'fromInternet': [],
          'ownExperiences': [],
        },
        'successPatterns': [],
        'failurePatterns': [],
        'currentApps': [],
        'completedApps': [],
        'totalAppsBuilt': 0,
        'successRate': 0.0,
        'lastActive': null,
        'debugLog': [],
      };
    }
  }

  /// Save Conquest AI data to local storage
  Future<void> _saveConquestData() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final conquestJson = jsonEncode(_conquestData);
      await prefs.setString(_conquestStorageKey, conquestJson);
      print('[CONQUEST_AI_SERVICE] 💾 Conquest AI data saved');
    } catch (e) {
      print('[CONQUEST_AI_SERVICE] ❌ Error saving Conquest AI data: $e');
    }
  }

  /// Force refresh operational hours to new format
  Future<void> forceRefreshOperationalHours() async {
    print('[CONQUEST_AI_SERVICE] 🔄 Force refreshing operational hours...');

    // Update operational hours to new format
    _conquestData['operationalHours'] = {'start': '05:00', 'end': '23:30'};

    // Save the updated data
    await _saveConquestData();

    // Force a check of operational hours
    await checkOperationalHours();

    print('[CONQUEST_AI_SERVICE] ✅ Operational hours refreshed to 05:00-23:30');
  }

  /// Check if Conquest AI should operate based on operational hours
  Future<bool> checkOperationalHours() async {
    final now = DateTime.now();
    final currentTime =
        '${now.hour.toString().padLeft(2, '0')}:${now.minute.toString().padLeft(2, '0')}';

    final startTime = _conquestData['operationalHours']['start'];
    final endTime = _conquestData['operationalHours']['end'];

    // Convert time strings to minutes since midnight for comparison
    final currentMinutes = _timeStringToMinutes(currentTime);
    final startMinutes = _timeStringToMinutes(startTime);
    final endMinutes = _timeStringToMinutes(endTime);

    // Debug logging
    print(
      '[CONQUEST_AI_SERVICE] ⏰ Current time: $currentTime (${currentMinutes} minutes)',
    );
    print(
      '[CONQUEST_AI_SERVICE] ⏰ Start time: $startTime (${startMinutes} minutes)',
    );
    print('[CONQUEST_AI_SERVICE] ⏰ End time: $endTime (${endMinutes} minutes)');

    final shouldOperate =
        currentMinutes >= startMinutes && currentMinutes <= endMinutes;

    print('[CONQUEST_AI_SERVICE] ⏰ Should operate: $shouldOperate');

    if (shouldOperate != _conquestData['isActive']) {
      _conquestData['isActive'] = shouldOperate;
      await _saveConquestData();

      if (shouldOperate) {
        _addDebugLog('Conquest AI is now active for operational hours');
        _notifyConquestUpdate();
      } else {
        _addDebugLog('Conquest AI is now inactive outside operational hours');
        _notifyConquestUpdate();
      }
    }

    return shouldOperate;
  }

  /// Convert time string (HH:MM) to minutes since midnight
  int _timeStringToMinutes(String timeString) {
    final parts = timeString.split(':');
    if (parts.length != 2) return 0;

    final hours = int.tryParse(parts[0]) ?? 0;
    final minutes = int.tryParse(parts[1]) ?? 0;
    final totalMinutes = hours * 60 + minutes;

    print(
      '[CONQUEST_AI_SERVICE] ⏰ Converting $timeString to $totalMinutes minutes (${hours}h ${minutes}m)',
    );
    return totalMinutes;
  }

  /// Create a new app suggestion
  Future<ConquestApp> createAppSuggestion({
    required String name,
    required String description,
    required String keywords,
  }) async {
    print('[CONQUEST_AI_SERVICE] 🚀 Creating new app suggestion: $name');

    // Process keywords - extract from description if empty or enhance with AI analysis
    String processedKeywords = keywords.trim();
    if (processedKeywords.isEmpty) {
      // Extract keywords from description
      processedKeywords = _extractKeywordsFromDescription(description);
    } else {
      // Enhance keywords with description analysis
      processedKeywords = _enhanceKeywordsWithDescription(
        keywords,
        description,
      );
    }

    final app = ConquestApp(
      id: _generateAppId(),
      name: name,
      description: description,
      userKeywords: processedKeywords,
      createdAt: DateTime.now(),
      status: 'pending',
      progress: 0.0,
      developmentLogs: [],
      requirements: {
        'name': name,
        'description': description,
        'keywords': processedKeywords,
        'platform': 'cross_platform',
        'features': [],
        'technologies': [],
      },
      errors: [],
      learnings: [],
      keywords: [],
      appType: '',
      features: [],
    );

    // Add to current apps locally
    _conquestData['currentApps'].add(app.toJson());
    await _saveConquestData();

    _addDebugLog(
      'Created app suggestion: $name with keywords: $processedKeywords',
    );
    _notifyAppsUpdate();

    // Call backend API to create actual deployment
    try {
      print(
        '[CONQUEST_AI_SERVICE] 📡 Sending app creation request to backend...',
      );

      final response = await _dio!.post(
        '/api/conquest/create-app',
        data: {
          'name': name,
          'description': description,
          'keywords':
              processedKeywords.split(',').map((k) => k.trim()).toList(),
          'app_type': 'general',
          'features': [],
          'operation_type': 'create_new',
        },
      );

      if (response.statusCode == 200) {
        final result = response.data;
        print(
          '[CONQUEST_AI_SERVICE] ✅ Backend app creation successful: ${result['app_id']}',
        );

        // Update local app with backend data
        final updatedApp = app.copyWith(
          id: result['app_id'],
          status: 'in_progress',
          progress: 0.1,
          developmentLogs: ['App creation request sent to backend'],
        );
        _updateAppInList(updatedApp);
        _notifyAppsUpdate();

        // Start the app building process
        if (await checkOperationalHours()) {
          _startAppBuilding(updatedApp);
        }

        return updatedApp;
      } else {
        throw Exception('Backend returned status ${response.statusCode}');
      }
    } catch (e) {
      print('[CONQUEST_AI_SERVICE] ❌ Error calling backend API: $e');

      // Update app with error status
      final errorApp = app.copyWith(
        status: 'failed',
        errors: [e.toString()],
        developmentLogs: ['Failed to send request to backend: $e'],
      );
      _updateAppInList(errorApp);
      _notifyAppsUpdate();

      return errorApp;
    }
  }

  /// Extract keywords from description using simple NLP
  String _extractKeywordsFromDescription(String description) {
    // Common app-related keywords to look for
    final commonKeywords = [
      'productivity',
      'social',
      'communication',
      'entertainment',
      'education',
      'health',
      'fitness',
      'finance',
      'shopping',
      'travel',
      'food',
      'music',
      'video',
      'photo',
      'game',
      'business',
      'work',
      'personal',
      'utility',
      'mobile',
      'web',
      'desktop',
      'cross-platform',
      'ai',
      'machine learning',
      'blockchain',
      'crypto',
      'social media',
      'messaging',
      'video call',
      'file sharing',
      'cloud',
      'storage',
      'backup',
      'security',
      'privacy',
      'calendar',
      'todo',
      'notes',
      'reminder',
      'timer',
      'calculator',
      'weather',
      'news',
      'maps',
      'navigation',
      'transport',
      'delivery',
      'booking',
      'reservation',
      'payment',
      'banking',
      'investment',
      'fitness tracking',
      'meditation',
      'sleep',
      'nutrition',
      'medical',
      'language learning',
      'coding',
      'design',
      'art',
      'music creation',
      'video editing',
      'photo editing',
      'document',
      'presentation',
      'spreadsheet',
      'collaboration',
      'team',
      'project management',
      'customer support',
      'analytics',
      'reporting',
      'dashboard',
    ];

    final lowerDescription = description.toLowerCase();
    final extractedKeywords = <String>[];

    // Find matching keywords in description
    for (final keyword in commonKeywords) {
      if (lowerDescription.contains(keyword.toLowerCase())) {
        extractedKeywords.add(keyword);
      }
    }

    // Also extract single words that might be relevant
    final words =
        description
            .toLowerCase()
            .replaceAll(RegExp(r'[^\w\s]'), ' ')
            .split(RegExp(r'\s+'))
            .where((word) => word.length > 3)
            .where(
              (word) =>
                  ![
                    'this',
                    'that',
                    'with',
                    'from',
                    'have',
                    'will',
                    'been',
                    'they',
                    'their',
                    'them',
                    'were',
                    'been',
                    'have',
                    'this',
                    'that',
                    'with',
                    'from',
                    'have',
                    'will',
                    'been',
                    'they',
                    'their',
                    'them',
                    'were',
                    'been',
                    'have',
                  ].contains(word),
            )
            .take(5)
            .toList();

    extractedKeywords.addAll(words);

    // Remove duplicates and limit to reasonable number
    final uniqueKeywords = extractedKeywords.toSet().take(8).toList();

    return uniqueKeywords.join(', ');
  }

  /// Enhance keywords with description analysis
  String _enhanceKeywordsWithDescription(String keywords, String description) {
    final existingKeywords = keywords.split(',').map((k) => k.trim()).toList();
    final extractedKeywords = _extractKeywordsFromDescription(description);
    final newKeywords =
        extractedKeywords.split(',').map((k) => k.trim()).toList();

    // Combine existing and new keywords, removing duplicates
    final allKeywords = <String>[];
    allKeywords.addAll(existingKeywords);

    for (final keyword in newKeywords) {
      if (!allKeywords.contains(keyword) && keyword.isNotEmpty) {
        allKeywords.add(keyword);
      }
    }

    // Limit to reasonable number and return
    return allKeywords.take(10).join(', ');
  }

  /// Start the app building process
  Future<void> _startAppBuilding(ConquestApp app) async {
    print('[CONQUEST_AI_SERVICE] 🏗️ Starting app building for: ${app.name}');

    // Update app status
    final updatedApp = app.copyWith(
      status: 'in_progress',
      progress: 0.1,
      completedAt: null,
    );
    _updateAppInList(updatedApp);

    _addDebugLog('Started building app: ${app.name}');
    _notifyAppsUpdate();

    try {
      // Step 1: Learn from other AIs
      await _learnFromOtherAIs(app);

      // Step 2: Define requirements
      await _defineAppRequirements(app);

      // Step 3: Build the app
      await _buildApp(app);

      // Step 4: Test the app
      await _testApp(app);

      // Step 5: Deploy to GitHub
      await _deployToGitHub(app);

      // Step 6: Mark as completed
      final completedApp = app.copyWith(
        status: 'completed',
        progress: 1.0,
        completedAt: DateTime.now(),
      );
      _updateAppInList(completedApp);

      // Move to completed apps
      _conquestData['completedApps'].add(completedApp.toJson());
      _conquestData['currentApps'].removeWhere((a) => a['id'] == app.id);
      _conquestData['totalAppsBuilt']++;

      await _saveConquestData();
      _addDebugLog('Successfully completed app: ${app.name}');
      _notifyAppsUpdate();

      // Show notification
      NotificationService.instance.showNotification(
        aiSource: 'Conquest',
        message: 'App "${app.name}" has been successfully built and deployed!',
        iconChar: '🎉',
      );
    } catch (e) {
      print('[CONQUEST_AI_SERVICE] ❌ Error building app ${app.name}: $e');

      final failedApp = app.copyWith(
        status: 'failed',
        errors: [...app.errors, e.toString()],
      );
      _updateAppInList(failedApp);

      _addDebugLog('Failed to build app: ${app.name} - $e');
      _notifyAppsUpdate();

      // Show error notification
      NotificationService.instance.showNotification(
        aiSource: 'Conquest',
        message: 'Failed to build app "${app.name}": $e',
        iconChar: '❌',
      );
    }
  }

  /// Learn from other AIs (public method for periodic learning)
  Future<void> learnFromOtherAIs() async {
    print('[CONQUEST_AI_SERVICE] 🧠 Learning from other AIs...');

    try {
      // Learn from Imperium
      final imperiumResponse = await _dio!.get(
        '/api/conquest/ai/imperium/learnings',
      );
      if (imperiumResponse.statusCode == 200) {
        final imperiumData = imperiumResponse.data;
        _conquestData['learningData']['fromImperium'].add({
          'timestamp': DateTime.now().toIso8601String(),
          'data': imperiumData,
        });
      }

      // Learn from Guardian
      final guardianResponse = await _dio!.get(
        '/api/conquest/ai/guardian/learnings',
      );
      if (guardianResponse.statusCode == 200) {
        final guardianData = guardianResponse.data;
        _conquestData['learningData']['fromGuardian'].add({
          'timestamp': DateTime.now().toIso8601String(),
          'data': guardianData,
        });
      }

      // Learn from Sandbox
      final sandboxResponse = await _dio!.get(
        '/api/conquest/ai/sandbox/learnings',
      );
      if (sandboxResponse.statusCode == 200) {
        final sandboxData = sandboxResponse.data;
        _conquestData['learningData']['fromSandbox'].add({
          'timestamp': DateTime.now().toIso8601String(),
          'data': sandboxData,
        });
      }

      await _saveConquestData();
      _addDebugLog('Successfully learned from other AIs');
      _notifyConquestUpdate();
    } catch (e) {
      print('[CONQUEST_AI_SERVICE] ! Error learning from other AIs: $e');
      _addDebugLog('Error learning from other AIs: $e');
    }
  }

  /// Learn from other AIs for a specific app
  Future<void> _learnFromOtherAIs(ConquestApp app) async {
    print('[CONQUEST_AI_SERVICE] 🧠 Learning from other AIs for: ${app.name}');

    try {
      // Learn from Imperium
      final imperiumResponse = await _dio!.get(
        '/api/conquest/ai/imperium/learnings',
      );
      if (imperiumResponse.statusCode == 200) {
        final imperiumData = imperiumResponse.data;
        _conquestData['learningData']['fromImperium'].add({
          'timestamp': DateTime.now().toIso8601String(),
          'appId': app.id,
          'data': imperiumData,
        });
      }

      // Learn from Guardian
      final guardianResponse = await _dio!.get(
        '/api/conquest/ai/guardian/learnings',
      );
      if (guardianResponse.statusCode == 200) {
        final guardianData = guardianResponse.data;
        _conquestData['learningData']['fromGuardian'].add({
          'timestamp': DateTime.now().toIso8601String(),
          'appId': app.id,
          'data': guardianData,
        });
      }

      // Learn from Sandbox
      final sandboxResponse = await _dio!.get(
        '/api/conquest/ai/sandbox/learnings',
      );
      if (sandboxResponse.statusCode == 200) {
        final sandboxData = sandboxResponse.data;
        _conquestData['learningData']['fromSandbox'].add({
          'timestamp': DateTime.now().toIso8601String(),
          'appId': app.id,
          'data': sandboxData,
        });
      }

      await _saveConquestData();
      _addDebugLog('Successfully learned from other AIs for app: ${app.name}');
    } catch (e) {
      print('[CONQUEST_AI_SERVICE] ! Error learning from other AIs: $e');
      _addDebugLog('Error learning from other AIs for app ${app.name}: $e');
    }
  }

  /// Define app requirements based on user input and AI learning
  Future<void> _defineAppRequirements(ConquestApp app) async {
    print('[CONQUEST_AI_SERVICE] 📋 Defining requirements for: ${app.name}');

    try {
      final response = await _dio!.post(
        '/api/conquest/define-requirements',
        data: {
          'appId': app.id,
          'name': app.name,
          'description': app.description,
          'keywords': app.userKeywords,
          'learningData': _conquestData['learningData'],
        },
      );

      if (response.statusCode == 200) {
        final requirements = response.data['requirements'];
        final updatedApp = app.copyWith(
          requirements: requirements,
          progress: 0.3,
          developmentLogs: [
            ...app.developmentLogs,
            'Requirements defined successfully',
          ],
        );
        _updateAppInList(updatedApp);
        _notifyAppsUpdate();
      }
    } catch (e) {
      print('[CONQUEST_AI_SERVICE] ❌ Error defining requirements: $e');
      throw Exception('Failed to define app requirements: $e');
    }
  }

  /// Build the app
  Future<void> _buildApp(ConquestApp app) async {
    print('[CONQUEST_AI_SERVICE] 🔨 Building app: ${app.name}');

    try {
      final response = await _dio!.post(
        '/api/conquest/build-app',
        data: {
          'appId': app.id,
          'requirements': app.requirements,
          'learningData': _conquestData['learningData'],
        },
      );

      if (response.statusCode == 200) {
        final buildData = response.data;
        final updatedApp = app.copyWith(
          progress: 0.7,
          developmentLogs: [...app.developmentLogs, 'App built successfully'],
          finalAppPath: buildData['appPath'],
        );
        _updateAppInList(updatedApp);
        _notifyAppsUpdate();
      }
    } catch (e) {
      print('[CONQUEST_AI_SERVICE] ❌ Error building app: $e');
      throw Exception('Failed to build app: $e');
    }
  }

  /// Test the app
  Future<void> _testApp(ConquestApp app) async {
    print('[CONQUEST_AI_SERVICE] 🧪 Testing app: ${app.name}');

    if (app.id == null ||
        app.id.isEmpty ||
        app.finalAppPath == null ||
        app.finalAppPath!.isEmpty ||
        app.requirements == null ||
        app.requirements.isEmpty) {
      print('❌ Missing required fields for test-app request');
      return;
    }

    print('Testing app with:');
    print('  appId: ${app.id}');
    print('  appPath: ${app.finalAppPath}');
    print('  requirements: ${app.requirements}');

    try {
      final response = await _dio!.post(
        '/api/conquest/test-app',
        data: {
          'appId': app.id,
          'appPath': app.finalAppPath,
          'requirements': app.requirements,
        },
      );

      if (response.statusCode == 200) {
        final updatedApp = app.copyWith(
          progress: 0.9,
          developmentLogs: [...app.developmentLogs, 'App tested successfully'],
        );
        _updateAppInList(updatedApp);
        _notifyAppsUpdate();
      }
    } catch (e) {
      print('[CONQUEST_AI_SERVICE] ❌ Error testing app: $e');
      throw Exception('Failed to test app: $e');
    }
  }

  /// Deploy app to GitHub
  Future<void> _deployToGitHub(ConquestApp app) async {
    print('[CONQUEST_AI_SERVICE] 🚀 Deploying app to GitHub: ${app.name}');

    try {
      final response = await _dio!.post(
        '/api/conquest/deploy-to-github',
        data: {
          'appId': app.id,
          'appName': app.name,
          'appPath': app.finalAppPath,
          'description': app.description,
        },
      );

      if (response.statusCode == 200) {
        final deployData = response.data;
        final updatedApp = app.copyWith(
          githubRepoUrl: deployData['repoUrl'],
          downloadUrl: deployData['downloadUrl'],
          developmentLogs: [
            ...app.developmentLogs,
            'App deployed to GitHub successfully',
          ],
        );
        _updateAppInList(updatedApp);
        _notifyAppsUpdate();
      }
    } catch (e) {
      print('[CONQUEST_AI_SERVICE] ❌ Error deploying to GitHub: $e');
      throw Exception('Failed to deploy to GitHub: $e');
    }
  }

  /// Update app in the current apps list
  void _updateAppInList(ConquestApp updatedApp) {
    final index = _conquestData['currentApps'].indexWhere(
      (a) => a['id'] == updatedApp.id,
    );
    if (index != -1) {
      _conquestData['currentApps'][index] = updatedApp.toJson();
    }
  }

  /// Get all current apps
  List<ConquestApp> getCurrentApps() {
    try {
      final appsList = _conquestData['currentApps'] as List? ?? [];
      return appsList
          .map((appJson) {
            try {
              return ConquestApp.fromJson(appJson as Map<String, dynamic>);
            } catch (e) {
              print('[CONQUEST_AI_SERVICE] ❌ Error parsing app JSON: $e');
              return null;
            }
          })
          .where((app) => app != null)
          .cast<ConquestApp>()
          .toList();
    } catch (e) {
      print('[CONQUEST_AI_SERVICE] ❌ Error getting current apps: $e');
      return [];
    }
  }

  /// Get all completed apps
  List<ConquestApp> getCompletedApps() {
    try {
      final appsList = _conquestData['completedApps'] as List? ?? [];
      return appsList
          .map((appJson) {
            try {
              return ConquestApp.fromJson(appJson as Map<String, dynamic>);
            } catch (e) {
              print(
                '[CONQUEST_AI_SERVICE] ❌ Error parsing completed app JSON: $e',
              );
              return null;
            }
          })
          .where((app) => app != null)
          .cast<ConquestApp>()
          .toList();
    } catch (e) {
      print('[CONQUEST_AI_SERVICE] ❌ Error getting completed apps: $e');
      return [];
    }
  }

  /// Get Conquest AI status
  Map<String, dynamic> getConquestStatus() {
    return {
      'isActive': _conquestData['isActive'],
      'operationalHours': _conquestData['operationalHours'],
      'totalAppsBuilt': _conquestData['totalAppsBuilt'],
      'successRate': _conquestData['successRate'],
      'lastActive': _conquestData['lastActive'],
    };
  }

  /// Get enhanced statistics including learning data and validation progress
  Future<Map<String, dynamic>> getEnhancedStatistics() async {
    try {
      if (_dio == null) {
        throw Exception('Service not initialized');
      }

      final response = await _dio!
          .get('/api/conquest/enhanced-statistics')
          .timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        return response.data;
      } else {
        throw Exception(
          'Failed to fetch enhanced statistics: ${response.statusCode}',
        );
      }
    } catch (e) {
      print('[CONQUEST_AI_SERVICE] ❌ Error fetching enhanced statistics: $e');
      return {
        'status': 'error',
        'message': 'Failed to fetch enhanced statistics: $e',
      };
    }
  }

  /// Add debug log entry
  void _addDebugLog(String message) {
    final logEntry = {
      'timestamp': DateTime.now().toIso8601String(),
      'message': message,
    };
    _conquestData['debugLog'].add(logEntry);

    // Keep only last 100 entries
    if (_conquestData['debugLog'].length > 100) {
      _conquestData['debugLog'] = _conquestData['debugLog'].take(100).toList();
    }

    _debugOutputController.add(logEntry);
  }

  /// Notify apps update
  void _notifyAppsUpdate() {
    final currentApps = getCurrentApps();
    _appsUpdateController.add(currentApps);
  }

  /// Notify Conquest update
  void _notifyConquestUpdate() {
    _conquestUpdateController.add(_conquestData);
  }

  /// Generate unique app ID
  String _generateAppId() {
    return 'conquest_${DateTime.now().millisecondsSinceEpoch}_${Random().nextInt(1000)}';
  }

  /// Dispose resources
  void dispose() {
    _appsUpdateController.close();
    _conquestUpdateController.close();
    _conquestEventController.close();
    _debugOutputController.close();
  }

  /// Fetch progress logs from backend and update debug output stream
  Future<void> fetchProgressLogsFromBackend() async {
    try {
      if (_dio == null) return;

      // Try to fetch progress logs directly
      final response = await _dio!
          .get('/api/conquest/progress-logs')
          .timeout(
            const Duration(seconds: 5),
            onTimeout: () => throw Exception('Progress logs timeout'),
          );

      if (response.statusCode == 200 && response.data['success'] == true) {
        final logs = response.data['logs'] as List;
        for (final log in logs) {
          if (log is Map<String, dynamic>) {
            _debugOutputController.add(log);
          } else if (log is Map) {
            _debugOutputController.add(Map<String, dynamic>.from(log));
          }
        }
        print('[CONQUEST_AI_SERVICE] ✅ Fetched ${logs.length} progress logs');
      }
    } catch (e) {
      // Don't log this as an error since the endpoint might not exist
      print(
        '[CONQUEST_AI_SERVICE] ℹ️ Progress logs not available (backend may not support this endpoint): $e',
      );
    }
  }

  /// Get progress logs from backend (returns the actual logs)
  Future<List<Map<String, dynamic>>> getProgressLogs() async {
    try {
      if (_dio == null) return [];

      final response = await _dio!
          .get('/api/conquest/progress-logs')
          .timeout(
            const Duration(seconds: 5),
            onTimeout: () => throw Exception('Progress logs timeout'),
          );

      if (response.statusCode == 200 && response.data['success'] == true) {
        final logs = response.data['logs'] as List;
        final result =
            logs.map((log) {
              if (log is Map<String, dynamic>) {
                return log;
              } else if (log is Map) {
                return Map<String, dynamic>.from(log);
              }
              return <String, dynamic>{};
            }).toList();

        print(
          '[CONQUEST_AI_SERVICE] ✅ Fetched ${result.length} progress logs from backend',
        );
        return result;
      }
      return [];
    } catch (e) {
      print('[CONQUEST_AI_SERVICE] ❌ Error fetching progress logs: $e');
      return [];
    }
  }
}
