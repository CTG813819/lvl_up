import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:web_socket_channel/status.dart' as status;
import '../models/ai_notification.dart';
import 'notification_service.dart';

class WebSocketService {
  static final WebSocketService _instance = WebSocketService._internal();
  static WebSocketService get instance => _instance;

  WebSocketChannel? _channel;
  StreamController<AINotification>? _notificationController;
  StreamController<Map<String, dynamic>>? _aiAgentController;
  StreamController<Map<String, dynamic>>? _learningController;

  bool _isConnected = false;
  bool _isConnecting = false;
  Timer? _reconnectTimer;
  int _reconnectAttempts = 0;
  static const int _maxReconnectAttempts = 5;

  WebSocketService._internal();

  // Getters
  bool get isConnected => _isConnected;
  Stream<AINotification> get notificationStream =>
      _notificationController?.stream ?? Stream.empty();
  Stream<Map<String, dynamic>> get aiAgentStream =>
      _aiAgentController?.stream ?? Stream.empty();
  Stream<Map<String, dynamic>> get learningStream =>
      _learningController?.stream ?? Stream.empty();

  Future<void> initialize() async {
    print('[WEBSOCKET_SERVICE] 🔌 Initializing WebSocket service...');

    _notificationController = StreamController<AINotification>.broadcast();
    _aiAgentController = StreamController<Map<String, dynamic>>.broadcast();
    _learningController = StreamController<Map<String, dynamic>>.broadcast();

    await connect();
  }

  Future<void> connect() async {
    if (_isConnecting || _isConnected) return;

    _isConnecting = true;
    print('[WEBSOCKET_SERVICE] 🔌 Connecting to WebSocket...');

    try {
      _channel = WebSocketChannel.connect(
        Uri.parse('ws://34.202.215.209:4000/api/notifications/ws'),
      );

      _channel!.stream.listen(
        (data) => _handleMessage(data),
        onError: (error) => _handleError(error),
        onDone: () => _handleDisconnect(),
      );

      _isConnected = true;
      _isConnecting = false;
      _reconnectAttempts = 0;
      print('[WEBSOCKET_SERVICE] ✅ WebSocket connected successfully');

      // Send initial connection message
      _sendMessage({
        'type': 'connection',
        'client': 'flutter_app',
        'timestamp': DateTime.now().toIso8601String(),
      });
    } catch (e) {
      _isConnecting = false;
      print('[WEBSOCKET_SERVICE] ❌ WebSocket connection failed: $e');
      _scheduleReconnect();
    }
  }

  void _handleMessage(dynamic data) {
    try {
      final message = jsonDecode(data.toString());
      final type = message['type'];

      print('[WEBSOCKET_SERVICE] 📨 Received message: $type');

      switch (type) {
        case 'notification':
          _handleNotification(message);
          break;
        case 'ai_agent_update':
          _handleAIAgentUpdate(message);
          break;
        case 'learning_update':
          _handleLearningUpdate(message);
          break;
        case 'conquest_update':
          _handleConquestUpdate(message);
          break;
        case 'oath_paper_update':
          _handleOathPaperUpdate(message);
          break;
        case 'system_status':
          _handleSystemStatus(message);
          break;
        default:
          print('[WEBSOCKET_SERVICE] ⚠️ Unknown message type: $type');
      }
    } catch (e) {
      print('[WEBSOCKET_SERVICE] ❌ Error parsing message: $e');
    }
  }

  void _handleNotification(Map<String, dynamic> message) {
    try {
      final notification = AINotification(
        id: message['id'] ?? DateTime.now().millisecondsSinceEpoch.toString(),
        title: message['title'] ?? 'AI Notification',
        body: message['message'] ?? '',
        aiSource: message['ai_source'] ?? 'System',
        icon: _getNotificationIconData(message['notification_type'] ?? 'info'),
        iconColor: _getNotificationColor(
          message['notification_type'] ?? 'info',
        ),
        timestamp: DateTime.parse(
          message['timestamp'] ?? DateTime.now().toIso8601String(),
        ),
      );

      _notificationController?.add(notification);

      // Show system notification
      NotificationService.instance.showNotification(
        aiSource: notification.aiSource,
        message: notification.body,
        iconChar: _getNotificationIcon(message['notification_type'] ?? 'info'),
      );
    } catch (e) {
      print('[WEBSOCKET_SERVICE] ❌ Error handling notification: $e');
    }
  }

  void _handleAIAgentUpdate(Map<String, dynamic> message) {
    _aiAgentController?.add(message);
    print(
      '[WEBSOCKET_SERVICE] 🤖 AI Agent update: ${message['agent']} - ${message['status']}',
    );
  }

  void _handleLearningUpdate(Map<String, dynamic> message) {
    _learningController?.add(message);
    print(
      '[WEBSOCKET_SERVICE] 🧠 Learning update: ${message['ai_type']} - ${message['progress']}%',
    );
  }

  void _handleConquestUpdate(Map<String, dynamic> message) {
    _aiAgentController?.add(message);
    print(
      '[WEBSOCKET_SERVICE] 🐉 Conquest update: ${message['app_name']} - ${message['status']}',
    );
  }

  void _handleOathPaperUpdate(Map<String, dynamic> message) {
    _learningController?.add(message);
    print(
      '[WEBSOCKET_SERVICE] 📜 Oath Paper update: ${message['subject']} - ${message['status']}',
    );
  }

  void _handleSystemStatus(Map<String, dynamic> message) {
    _aiAgentController?.add(message);
    print('[WEBSOCKET_SERVICE] 🔧 System status: ${message['status']}');
  }

  String _getNotificationIcon(String type) {
    switch (type) {
      case 'success':
        return '✅';
      case 'error':
        return '❌';
      case 'warning':
        return '⚠️';
      case 'info':
        return 'ℹ️';
      case 'ai_learning':
        return '🧠';
      case 'conquest':
        return '🐉';
      case 'imperium':
        return '👑';
      case 'guardian':
        return '🛡️';
      case 'sandbox':
        return '🧪';
      default:
        return '📢';
    }
  }

  IconData _getNotificationIconData(String type) {
    switch (type) {
      case 'success':
        return Icons.check_circle;
      case 'error':
        return Icons.error;
      case 'warning':
        return Icons.warning;
      case 'ai_learning':
        return Icons.psychology;
      case 'conquest':
        return Icons.auto_awesome;
      case 'imperium':
        return Icons.star;
      case 'guardian':
        return Icons.security;
      case 'sandbox':
        return Icons.science;
      case 'info':
      default:
        return Icons.info;
    }
  }

  Color _getNotificationColor(String type) {
    switch (type) {
      case 'success':
        return Colors.green;
      case 'error':
        return Colors.red;
      case 'warning':
        return Colors.orange;
      case 'ai_learning':
        return Colors.purple;
      case 'conquest':
        return Colors.amber;
      case 'imperium':
        return Colors.purple;
      case 'guardian':
        return Colors.blue;
      case 'sandbox':
        return Colors.orange;
      case 'info':
      default:
        return Colors.blue;
    }
  }

  void _handleError(dynamic error) {
    print('[WEBSOCKET_SERVICE] ❌ WebSocket error: $error');
    _isConnected = false;
    _scheduleReconnect();
  }

  void _handleDisconnect() {
    print('[WEBSOCKET_SERVICE] 🔌 WebSocket disconnected');
    _isConnected = false;
    _scheduleReconnect();
  }

  void _scheduleReconnect() {
    if (_reconnectAttempts >= _maxReconnectAttempts) {
      print('[WEBSOCKET_SERVICE] 🛑 Max reconnection attempts reached');
      return;
    }

    _reconnectTimer?.cancel();
    _reconnectAttempts++;
    final delay = Duration(
      seconds: _reconnectAttempts * 2,
    ); // Exponential backoff

    print(
      '[WEBSOCKET_SERVICE] 🔄 Scheduling reconnection in ${delay.inSeconds} seconds (attempt $_reconnectAttempts)',
    );

    _reconnectTimer = Timer(delay, () {
      if (!_isConnected) {
        connect();
      }
    });
  }

  void _sendMessage(Map<String, dynamic> message) {
    if (!_isConnected || _channel == null) {
      print('[WEBSOCKET_SERVICE] ⚠️ Cannot send message - not connected');
      return;
    }

    try {
      _channel!.sink.add(jsonEncode(message));
      print('[WEBSOCKET_SERVICE] 📤 Sent message: ${message['type']}');
    } catch (e) {
      print('[WEBSOCKET_SERVICE] ❌ Error sending message: $e');
    }
  }

  // Public methods for sending specific messages
  void subscribeToAIAgent(String agentType) {
    _sendMessage({
      'type': 'subscribe',
      'channel': 'ai_agent',
      'agent_type': agentType,
      'timestamp': DateTime.now().toIso8601String(),
    });
  }

  void subscribeToLearning(String aiType) {
    _sendMessage({
      'type': 'subscribe',
      'channel': 'learning',
      'ai_type': aiType,
      'timestamp': DateTime.now().toIso8601String(),
    });
  }

  void subscribeToConquest() {
    _sendMessage({
      'type': 'subscribe',
      'channel': 'conquest',
      'timestamp': DateTime.now().toIso8601String(),
    });
  }

  void subscribeToOathPapers() {
    _sendMessage({
      'type': 'subscribe',
      'channel': 'oath_papers',
      'timestamp': DateTime.now().toIso8601String(),
    });
  }

  void requestSystemStatus() {
    _sendMessage({
      'type': 'request_status',
      'timestamp': DateTime.now().toIso8601String(),
    });
  }

  void dispose() {
    _reconnectTimer?.cancel();
    _channel?.sink.close(status.goingAway);
    _notificationController?.close();
    _aiAgentController?.close();
    _learningController?.close();
    print('[WEBSOCKET_SERVICE] 🧹 WebSocket service disposed');
  }
}
