import 'dart:convert';
import 'dart:async';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/ai_proposal.dart';

/// Proposal Deduplication Service
/// Compares proposals and only presents the better one to prevent backlog
class ProposalDeduplicationService {
  static final ProposalDeduplicationService _instance = ProposalDeduplicationService._internal();
  factory ProposalDeduplicationService() => _instance;
  ProposalDeduplicationService._internal();

  static const String _deduplicationStorageKey = 'proposal_deduplication_data';
  
  // Cache of recent proposals for comparison
  final Map<String, List<AIProposal>> _recentProposals = {};
  final Map<String, DateTime> _lastComparisonTime = {};
  
  // Deduplication settings
  static const Duration _comparisonWindow = Duration(minutes: 30);
  static const int _maxRecentProposals = 10;
  static const double _similarityThreshold = 0.8; // 80% similarity threshold
  
  // Stream controller for deduplication events
  final StreamController<Map<String, dynamic>> _deduplicationEventController =
      StreamController<Map<String, dynamic>>.broadcast();
  
  Stream<Map<String, dynamic>> get deduplicationEventStream => _deduplicationEventController.stream;

  /// Initialize the deduplication service
  Future<void> initialize() async {
    print('[PROPOSAL_DEDUPLICATION_SERVICE] 🔄 Initializing proposal deduplication service...');
    await _loadDeduplicationData();
    print('[PROPOSAL_DEDUPLICATION_SERVICE] ✅ Proposal deduplication service initialized');
  }

  /// Load deduplication data from local storage
  Future<void> _loadDeduplicationData() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final dataJson = prefs.getString(_deduplicationStorageKey);
      
      if (dataJson != null) {
        final data = jsonDecode(dataJson) as Map<String, dynamic>;
        
        // Load recent proposals
        final recentProposalsData = data['recentProposals'] as Map<String, dynamic>? ?? {};
        for (String key in recentProposalsData.keys) {
          final proposalsList = recentProposalsData[key] as List? ?? [];
          _recentProposals[key] = proposalsList
              .map((p) => AIProposal.fromJson(p as Map<String, dynamic>))
              .toList();
        }
        
        // Load last comparison times
        final lastComparisonData = data['lastComparisonTime'] as Map<String, dynamic>? ?? {};
        for (String key in lastComparisonData.keys) {
          _lastComparisonTime[key] = DateTime.parse(lastComparisonData[key] as String);
        }
        
        print('[PROPOSAL_DEDUPLICATION_SERVICE] 📚 Loaded deduplication data');
      }
    } catch (e) {
      print('[PROPOSAL_DEDUPLICATION_SERVICE] ❌ Error loading deduplication data: $e');
    }
  }

  /// Save deduplication data to local storage
  Future<void> _saveDeduplicationData() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      
      // Convert recent proposals to JSON
      final recentProposalsData = <String, dynamic>{};
      for (String key in _recentProposals.keys) {
        recentProposalsData[key] = _recentProposals[key]!
            .map((p) => p.toJson())
            .toList();
      }
      
      // Convert last comparison times to JSON
      final lastComparisonData = <String, dynamic>{};
      for (String key in _lastComparisonTime.keys) {
        lastComparisonData[key] = _lastComparisonTime[key]!.toIso8601String();
      }
      
      final data = {
        'recentProposals': recentProposalsData,
        'lastComparisonTime': lastComparisonData,
        'lastUpdated': DateTime.now().toIso8601String(),
      };
      
      await prefs.setString(_deduplicationStorageKey, jsonEncode(data));
    } catch (e) {
      print('[PROPOSAL_DEDUPLICATION_SERVICE] ❌ Error saving deduplication data: $e');
    }
  }

  /// Check if a proposal is a duplicate and should be filtered out
  Future<DeduplicationResult> checkProposal(AIProposal newProposal) async {
    print('[PROPOSAL_DEDUPLICATION_SERVICE] 🔍 Checking proposal: ${newProposal.id}');
    
    final fileKey = _generateFileKey(newProposal.filePath);
    final now = DateTime.now();
    
    // Clean old proposals outside the comparison window
    _cleanOldProposals(fileKey, now);
    
    // Get recent proposals for this file
    final recentProposals = _recentProposals[fileKey] ?? [];
    
    if (recentProposals.isEmpty) {
      // No recent proposals, this is unique
      _addProposalToCache(fileKey, newProposal, now);
      return DeduplicationResult(
        isDuplicate: false,
        reason: 'No recent proposals for comparison',
        betterProposal: null,
      );
    }
    
    // Compare with recent proposals
    for (AIProposal existingProposal in recentProposals) {
      final similarity = _calculateSimilarity(newProposal, existingProposal);
      
      if (similarity >= _similarityThreshold) {
        // High similarity detected - determine which is better
        final comparison = _compareProposals(newProposal, existingProposal);
        
        if (comparison.isNewProposalBetter) {
          // New proposal is better, replace the old one
          _replaceProposalInCache(fileKey, existingProposal, newProposal, now);
          
          _deduplicationEventController.add({
            'type': 'replacement',
            'newProposal': newProposal.id,
            'oldProposal': existingProposal.id,
            'reason': comparison.reason,
            'timestamp': now.toIso8601String(),
          });
          
          return DeduplicationResult(
            isDuplicate: false,
            reason: 'Replaced inferior proposal: ${comparison.reason}',
            betterProposal: newProposal,
          );
        } else {
          // Existing proposal is better, filter out the new one
          _deduplicationEventController.add({
            'type': 'filtered',
            'newProposal': newProposal.id,
            'betterProposal': existingProposal.id,
            'reason': comparison.reason,
            'timestamp': now.toIso8601String(),
          });
          
          return DeduplicationResult(
            isDuplicate: true,
            reason: 'Inferior to existing proposal: ${comparison.reason}',
            betterProposal: existingProposal,
          );
        }
      }
    }
    
    // No similar proposals found, this is unique
    _addProposalToCache(fileKey, newProposal, now);
    return DeduplicationResult(
      isDuplicate: false,
      reason: 'No similar proposals found',
      betterProposal: null,
    );
  }

  /// Generate a unique key for a file
  String _generateFileKey(String filePath) {
    return filePath.replaceAll(RegExp(r'[^\w\-_.]'), '_');
  }

  /// Clean old proposals outside the comparison window
  void _cleanOldProposals(String fileKey, DateTime now) {
    final recentProposals = _recentProposals[fileKey];
    if (recentProposals == null) return;
    
    final cutoffTime = now.subtract(_comparisonWindow);
    recentProposals.removeWhere((proposal) {
      return proposal.timestamp.isBefore(cutoffTime);
    });
    
    // Also limit the number of recent proposals
    if (recentProposals.length > _maxRecentProposals) {
      recentProposals.removeRange(0, recentProposals.length - _maxRecentProposals);
    }
  }

  /// Add proposal to cache
  void _addProposalToCache(String fileKey, AIProposal proposal, DateTime now) {
    if (!_recentProposals.containsKey(fileKey)) {
      _recentProposals[fileKey] = [];
    }
    
    _recentProposals[fileKey]!.add(proposal);
    _lastComparisonTime[fileKey] = now;
    
    _saveDeduplicationData();
  }

  /// Replace proposal in cache
  void _replaceProposalInCache(String fileKey, AIProposal oldProposal, AIProposal newProposal, DateTime now) {
    final recentProposals = _recentProposals[fileKey];
    if (recentProposals == null) return;
    
    final index = recentProposals.indexWhere((p) => p.id == oldProposal.id);
    if (index != -1) {
      recentProposals[index] = newProposal;
      _lastComparisonTime[fileKey] = now;
      _saveDeduplicationData();
    }
  }

  /// Calculate similarity between two proposals
  double _calculateSimilarity(AIProposal proposal1, AIProposal proposal2) {
    // Compare file paths
    if (proposal1.filePath != proposal2.filePath) {
      return 0.0;
    }
    
    // Compare AI types
    if (proposal1.aiType != proposal2.aiType) {
      return 0.3; // Lower similarity for different AI types
    }
    
    // Compare code changes
    final codeSimilarity = _calculateCodeSimilarity(proposal1, proposal2);
    
    // Compare improvement types
    final improvementSimilarity = proposal1.improvementType == proposal2.improvementType ? 1.0 : 0.5;
    
    // Weighted average
    return (codeSimilarity * 0.6) + (improvementSimilarity * 0.4);
  }

  /// Calculate code similarity between two proposals
  double _calculateCodeSimilarity(AIProposal proposal1, AIProposal proposal2) {
    // Simple string similarity for now
    // In a more sophisticated implementation, this could use AST comparison or semantic analysis
    
    final oldCode1 = proposal1.oldCode;
    final newCode1 = proposal1.newCode;
    final oldCode2 = proposal2.oldCode;
    final newCode2 = proposal2.newCode;
    
    // Compare old code similarity
    final oldCodeSimilarity = _calculateStringSimilarity(oldCode1, oldCode2);
    
    // Compare new code similarity
    final newCodeSimilarity = _calculateStringSimilarity(newCode1, newCode2);
    
    // Weighted average (new code is more important)
    return (oldCodeSimilarity * 0.3) + (newCodeSimilarity * 0.7);
  }

  /// Calculate string similarity using Levenshtein distance
  double _calculateStringSimilarity(String str1, String str2) {
    if (str1.isEmpty && str2.isEmpty) return 1.0;
    if (str1.isEmpty || str2.isEmpty) return 0.0;
    
    final distance = _levenshteinDistance(str1, str2);
    final maxLength = str1.length > str2.length ? str1.length : str2.length;
    
    return 1.0 - (distance / maxLength);
  }

  /// Calculate Levenshtein distance between two strings
  int _levenshteinDistance(String str1, String str2) {
    final matrix = List.generate(
      str1.length + 1,
      (i) => List.generate(str2.length + 1, (j) => 0),
    );
    
    for (int i = 0; i <= str1.length; i++) {
      matrix[i][0] = i;
    }
    
    for (int j = 0; j <= str2.length; j++) {
      matrix[0][j] = j;
    }
    
    for (int i = 1; i <= str1.length; i++) {
      for (int j = 1; j <= str2.length; j++) {
        final cost = str1[i - 1] == str2[j - 1] ? 0 : 1;
        matrix[i][j] = [
          matrix[i - 1][j] + 1, // deletion
          matrix[i][j - 1] + 1, // insertion
          matrix[i - 1][j - 1] + cost, // substitution
        ].reduce((a, b) => a < b ? a : b);
      }
    }
    
    return matrix[str1.length][str2.length];
  }

  /// Compare two proposals and determine which is better
  ProposalComparison _compareProposals(AIProposal newProposal, AIProposal existingProposal) {
    int newScore = 0;
    int existingScore = 0;
    List<String> reasons = [];
    
    // Compare code quality (length of changes)
    final newCodeLength = newProposal.newCode.length;
    final existingCodeLength = existingProposal.newCode.length;
    
    if (newCodeLength < existingCodeLength) {
      newScore += 2;
      reasons.add('More concise code');
    } else if (existingCodeLength < newCodeLength) {
      existingScore += 2;
      reasons.add('More concise code');
    }
    
    // Compare improvement types (prioritize certain types)
    final newImprovementScore = _getImprovementTypeScore(newProposal.improvementType);
    final existingImprovementScore = _getImprovementTypeScore(existingProposal.improvementType);
    
    if (newImprovementScore > existingImprovementScore) {
      newScore += 3;
      reasons.add('Better improvement type');
    } else if (existingImprovementScore > newImprovementScore) {
      existingScore += 3;
      reasons.add('Better improvement type');
    }
    
    // Compare AI types (some AIs might be more reliable)
    final newAIScore = _getAITypeScore(newProposal.aiType);
    final existingAIScore = _getAITypeScore(existingProposal.aiType);
    
    if (newAIScore > existingAIScore) {
      newScore += 1;
      reasons.add('More reliable AI source');
    } else if (existingAIScore > newAIScore) {
      existingScore += 1;
      reasons.add('More reliable AI source');
    }
    
    // Compare timestamps (newer might be better)
    final newTime = newProposal.timestamp;
    final existingTime = existingProposal.timestamp;
    
    if (newTime.isAfter(existingTime)) {
      newScore += 1;
      reasons.add('More recent proposal');
    } else if (existingTime.isAfter(newTime)) {
      existingScore += 1;
      reasons.add('More recent proposal');
    }
    
    final isNewProposalBetter = newScore > existingScore;
    final reason = reasons.isNotEmpty ? reasons.join(', ') : 'Equal quality';
    
    return ProposalComparison(
      isNewProposalBetter: isNewProposalBetter,
      newScore: newScore,
      existingScore: existingScore,
      reason: reason,
    );
  }

  /// Get improvement type score (higher is better)
  int _getImprovementTypeScore(String improvementType) {
    switch (improvementType.toLowerCase()) {
      case 'security':
        return 5;
      case 'performance':
        return 4;
      case 'bugfix':
        return 3;
      case 'refactor':
        return 2;
      case 'general':
      default:
        return 1;
    }
  }

  /// Get AI type score (higher is more reliable)
  int _getAITypeScore(String aiType) {
    switch (aiType.toLowerCase()) {
      case 'imperium':
        return 3;
      case 'guardian':
        return 2;
      case 'sandbox':
        return 1;
      default:
        return 1;
    }
  }

  /// Get deduplication statistics
  Map<String, dynamic> getDeduplicationStats() {
    int totalProposals = 0;
    int uniqueProposals = 0;
    int filteredProposals = 0;
    int replacedProposals = 0;
    
    for (String fileKey in _recentProposals.keys) {
      totalProposals += _recentProposals[fileKey]!.length;
    }
    
    // This is a simplified calculation - in a real implementation,
    // you'd track these statistics over time
    uniqueProposals = totalProposals;
    
    return {
      'totalProposals': totalProposals,
      'uniqueProposals': uniqueProposals,
      'filteredProposals': filteredProposals,
      'replacedProposals': replacedProposals,
      'filesTracked': _recentProposals.length,
      'lastUpdated': DateTime.now().toIso8601String(),
    };
  }

  /// Clear all cached data
  Future<void> clearCache() async {
    _recentProposals.clear();
    _lastComparisonTime.clear();
    await _saveDeduplicationData();
    
    _deduplicationEventController.add({
      'type': 'cache_cleared',
      'timestamp': DateTime.now().toIso8601String(),
    });
    
    print('[PROPOSAL_DEDUPLICATION_SERVICE] 🗑️ Cache cleared');
  }

  void dispose() {
    _deduplicationEventController.close();
  }
}

/// Result of deduplication check
class DeduplicationResult {
  final bool isDuplicate;
  final String reason;
  final AIProposal? betterProposal;

  DeduplicationResult({
    required this.isDuplicate,
    required this.reason,
    this.betterProposal,
  });
}

/// Result of proposal comparison
class ProposalComparison {
  final bool isNewProposalBetter;
  final int newScore;
  final int existingScore;
  final String reason;

  ProposalComparison({
    required this.isNewProposalBetter,
    required this.newScore,
    required this.existingScore,
    required this.reason,
  });
} 