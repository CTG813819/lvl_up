import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/system_status_provider.dart';

/// System Status Indicator Widget
/// Displays real-time system health status in the app bar
class SystemStatusIndicator extends StatelessWidget {
  final bool showText;
  final double size;
  final VoidCallback? onTap;

  const SystemStatusIndicator({
    Key? key,
    this.showText = true,
    this.size = 24.0,
    this.onTap,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Consumer<SystemStatusProvider>(
      builder: (context, statusProvider, child) {
        return GestureDetector(
          onTap: onTap ?? () => _showStatusDetails(context, statusProvider),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            decoration: BoxDecoration(
              color: statusProvider.statusColor.withOpacity(0.1),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: statusProvider.statusColor.withOpacity(0.3),
                width: 1,
              ),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                // Status icon with pulse animation for critical status
                AnimatedBuilder(
                  animation: statusProvider,
                  builder: (context, child) {
                    return Container(
                      width: size,
                      height: size,
                      child: Stack(
                        children: [
                          Icon(
                            statusProvider.statusIcon,
                            size: size,
                            color: statusProvider.statusColor,
                          ),
                          if (statusProvider.systemHealth == SystemHealth.critical)
                            _buildPulseAnimation(statusProvider.statusColor),
                        ],
                      ),
                    );
                  },
                ),
                if (showText) ...[
                  const SizedBox(width: 8),
                  Flexible(
                    child: ConstrainedBox(
                      constraints: const BoxConstraints(maxWidth: 120),
                      child: Text(
                        statusProvider.statusMessage,
                        style: TextStyle(
                          color: statusProvider.statusColor,
                          fontSize: 11,
                          fontWeight: FontWeight.w500,
                        ),
                        overflow: TextOverflow.ellipsis,
                        maxLines: 1,
                      ),
                    ),
                  ),
                ],
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildPulseAnimation(Color color) {
    return TweenAnimationBuilder<double>(
      tween: Tween(begin: 0.0, end: 1.0),
      duration: const Duration(seconds: 2),
      builder: (context, value, child) {
        return Container(
          width: size,
          height: size,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            border: Border.all(
              color: color.withOpacity(0.3 * (1 - value)),
              width: 2,
            ),
          ),
        );
      },
    );
  }

  void _showStatusDetails(BuildContext context, SystemStatusProvider statusProvider) {
    showDialog(
      context: context,
      builder: (context) => SystemStatusDialog(statusProvider: statusProvider),
    );
  }
}

/// System Status Dialog
/// Shows detailed system status information
class SystemStatusDialog extends StatelessWidget {
  final SystemStatusProvider statusProvider;

  const SystemStatusDialog({
    Key? key,
    required this.statusProvider,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Container(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Header
            Row(
              children: [
                Icon(
                  statusProvider.statusIcon,
                  color: statusProvider.statusColor,
                  size: 32,
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'System Status',
                        style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Text(
                        statusProvider.statusMessage,
                        style: TextStyle(
                          color: statusProvider.statusColor,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ],
                  ),
                ),
                IconButton(
                  onPressed: () => Navigator.of(context).pop(),
                  icon: const Icon(Icons.close),
                ),
              ],
            ),
            const SizedBox(height: 20),
            
            // Status details
            _buildStatusSection(
              context,
              'Backend',
              statusProvider.backendStatus.toString().split('.').last,
              statusProvider.isBackendConnected ? Colors.green : Colors.red,
              statusProvider.statusDetails['backend']?['error'] ?? 'Connected',
            ),
            const SizedBox(height: 12),
            
            _buildStatusSection(
              context,
              'AI Learning',
              statusProvider.aiLearningStatus.toString().split('.').last,
              statusProvider.isAILearningActive ? Colors.green : Colors.orange,
              statusProvider.statusDetails['aiLearning']?['error'] ?? 'Active',
            ),
            const SizedBox(height: 12),
            
            _buildStatusSection(
              context,
              'Notifications',
              statusProvider.notificationStatus.toString().split('.').last,
              statusProvider.notificationStatus == NotificationStatus.enabled 
                ? Colors.green : Colors.red,
              statusProvider.statusDetails['notifications']?['error'] ?? 'Enabled',
            ),
            
            if (statusProvider.hasErrors) ...[
              const SizedBox(height: 16),
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.red.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: Colors.red.withOpacity(0.3)),
                ),
                child: Row(
                  children: [
                    Icon(Icons.error, color: Colors.red, size: 20),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        '${statusProvider.errorLog.length} error(s) detected',
                        style: TextStyle(color: Colors.red, fontWeight: FontWeight.w500),
                      ),
                    ),
                  ],
                ),
              ),
            ],
            
            const SizedBox(height: 20),
            
            // Action buttons
            Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () {
                      Navigator.of(context).pop();
                      statusProvider.performHealthCheck();
                    },
                    icon: const Icon(Icons.refresh),
                    label: const FittedBox(child: Text('Refresh')),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: () {
                      Navigator.of(context).pop();
                      _showResetConfirmation(context);
                    },
                    icon: const Icon(Icons.restart_alt),
                    label: const Text('Reset System'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.orange,
                      foregroundColor: Colors.white,
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStatusSection(
    BuildContext context,
    String title,
    String status,
    Color color,
    String details,
  ) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: color.withOpacity(0.3)),
      ),
      child: Row(
        children: [
          Container(
            width: 8,
            height: 8,
            decoration: BoxDecoration(
              color: color,
              shape: BoxShape.circle,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(fontWeight: FontWeight.w600),
                ),
                Text(
                  status,
                  style: TextStyle(
                    color: color,
                    fontSize: 12,
                    fontWeight: FontWeight.w500,
                  ),
                ),
                if (details.isNotEmpty)
                  Text(
                    details,
                    style: TextStyle(
                      color: Colors.grey[600],
                      fontSize: 11,
                    ),
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  void _showResetConfirmation(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Reset System'),
        content: const Text(
          'This will reset the system status and perform fresh health checks. '
          'Are you sure you want to continue?',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.of(context).pop();
              statusProvider.resetSystem();
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.orange,
              foregroundColor: Colors.white,
            ),
            child: const Text('Reset'),
          ),
        ],
      ),
    );
  }
} 