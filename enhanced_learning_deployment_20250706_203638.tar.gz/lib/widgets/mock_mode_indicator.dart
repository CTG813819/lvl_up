import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/proposal_provider.dart';
import '../providers/ai_learning_provider.dart';

/// Global Mock Mode Indicator Widget
/// Shows when the app is in mock mode and provides retry functionality
class MockModeIndicator extends StatelessWidget {
  final bool showRetryButton;
  final bool showDetails;
  final VoidCallback? onRetry;

  const MockModeIndicator({
    Key? key,
    this.showRetryButton = true,
    this.showDetails = true,
    this.onRetry,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Consumer2<ProposalProvider, AILearningProvider>(
      builder: (context, proposalProvider, aiLearningProvider, child) {
        final proposalStatus = proposalProvider.getConnectionStatus();
        final aiLearningStatus = aiLearningProvider.getConnectionStatus();
        
        final isProposalMock = proposalStatus['mode'] == 'Mock';
        final isAILearningMock = aiLearningStatus['mode'] == 'Mock';
        
        // Only show if either provider is in mock mode
        if (!isProposalMock && !isAILearningMock) {
          return const SizedBox.shrink();
        }

        return Container(
          width: double.infinity,
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          decoration: BoxDecoration(
            color: Colors.orange.withOpacity(0.1),
            border: Border(
              bottom: BorderSide(color: Colors.orange.withOpacity(0.3)),
            ),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Icon(
                    Icons.warning_amber_rounded,
                    color: Colors.orange[700],
                    size: 20,
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          '🎭 Mock Mode Active',
                          style: TextStyle(
                            color: Colors.orange[700],
                            fontWeight: FontWeight.bold,
                            fontSize: 14,
                          ),
                        ),
                        if (showDetails) ...[
                          const SizedBox(height: 4),
                          Text(
                            _getMockModeDescription(isProposalMock, isAILearningMock),
                            style: TextStyle(
                              color: Colors.orange[600],
                              fontSize: 12,
                            ),
                          ),
                        ],
                      ],
                    ),
                  ),
                  if (showRetryButton) ...[
                    TextButton(
                      onPressed: onRetry ?? () => _retryConnections(context),
                      child: Text(
                        'Retry',
                        style: TextStyle(
                          color: Colors.orange[700],
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ],
                ],
              ),
              if (showDetails) ...[
                const SizedBox(height: 8),
                Row(
                  children: [
                    _buildStatusChip('Proposals', isProposalMock),
                    const SizedBox(width: 8),
                    _buildStatusChip('AI Learning', isAILearningMock),
                  ],
                ),
              ],
            ],
          ),
        );
      },
    );
  }

  String _getMockModeDescription(bool isProposalMock, bool isAILearningMock) {
    if (isProposalMock && isAILearningMock) {
      return 'Both systems using local data - Backend unavailable or outside operational hours';
    } else if (isProposalMock) {
      return 'Proposals using local data - Backend unavailable or outside operational hours';
    } else {
      return 'AI Learning using local data - Backend unavailable or outside operational hours';
    }
  }

  Widget _buildStatusChip(String label, bool isMock) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: isMock ? Colors.orange.withOpacity(0.2) : Colors.green.withOpacity(0.2),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: isMock ? Colors.orange.withOpacity(0.5) : Colors.green.withOpacity(0.5),
        ),
      ),
      child: Text(
        '$label: ${isMock ? "Mock" : "Real"}',
        style: TextStyle(
          fontSize: 10,
          fontWeight: FontWeight.w500,
          color: isMock ? Colors.orange[700] : Colors.green[700],
        ),
      ),
    );
  }

  void _retryConnections(BuildContext context) async {
    final proposalProvider = Provider.of<ProposalProvider>(context, listen: false);
    final aiLearningProvider = Provider.of<AILearningProvider>(context, listen: false);
    
    // Show loading indicator
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('🔄 Retrying connections...'),
        duration: Duration(seconds: 2),
      ),
    );
    
    // Retry both providers
    await Future.wait([
      proposalProvider.retryConnection(),
      aiLearningProvider.retryConnection(),
    ]);
    
    if (context.mounted) {
      final newProposalStatus = proposalProvider.getConnectionStatus();
      final newAILearningStatus = aiLearningProvider.getConnectionStatus();
      
      final isProposalReal = newProposalStatus['mode'] == 'Real';
      final isAILearningReal = newAILearningStatus['mode'] == 'Real';
      
      if (isProposalReal && isAILearningReal) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('✅ Both systems connected to backend'),
            backgroundColor: Colors.green,
            duration: Duration(seconds: 3),
          ),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              '⚠️ Some systems still in mock mode - Outside operational hours or backend unavailable',
            ),
            backgroundColor: Colors.orange,
            duration: Duration(seconds: 3),
          ),
        );
      }
    }
  }
}

/// Compact Mock Mode Indicator for App Bar
class CompactMockModeIndicator extends StatelessWidget {
  final VoidCallback? onTap;

  const CompactMockModeIndicator({
    Key? key,
    this.onTap,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Consumer2<ProposalProvider, AILearningProvider>(
      builder: (context, proposalProvider, aiLearningProvider, child) {
        final proposalStatus = proposalProvider.getConnectionStatus();
        final aiLearningStatus = aiLearningProvider.getConnectionStatus();
        
        final isProposalMock = proposalStatus['mode'] == 'Mock';
        final isAILearningMock = aiLearningStatus['mode'] == 'Mock';
        
        // Only show if either provider is in mock mode
        if (!isProposalMock && !isAILearningMock) {
          return const SizedBox.shrink();
        }

        return GestureDetector(
          onTap: onTap,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            decoration: BoxDecoration(
              color: Colors.orange.withOpacity(0.2),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: Colors.orange.withOpacity(0.5)),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(
                  Icons.warning_amber_rounded,
                  color: Colors.orange[700],
                  size: 16,
                ),
                const SizedBox(width: 4),
                Text(
                  'Mock',
                  style: TextStyle(
                    color: Colors.orange[700],
                    fontSize: 12,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
} 