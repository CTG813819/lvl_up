import 'package:flutter/material.dart';
import '../guardian_service.dart';

class MissionSyncWidget extends StatefulWidget {
  const MissionSyncWidget({Key? key}) : super(key: key);

  @override
  State<MissionSyncWidget> createState() => _MissionSyncWidgetState();
}

class _MissionSyncWidgetState extends State<MissionSyncWidget> {
  bool _isLoading = false;
  Map<String, dynamic>? _lastSyncResult;
  Map<String, dynamic>? _missionStats;
  Map<String, dynamic>? _healthCheckResult;

  @override
  void initState() {
    super.initState();
    _loadMissionStats();
  }

  Future<void> _loadMissionStats() async {
    setState(() => _isLoading = true);
    try {
      final stats = await GuardianService.getMissionStatistics();
      if (stats != null && stats['success'] == true) {
        setState(() => _missionStats = stats['data']);
      }
    } catch (e) {
      print('Error loading mission stats: $e');
    } finally {
      setState(() => _isLoading = false);
    }
  }

  Future<void> _syncMissions() async {
    setState(() => _isLoading = true);
    try {
      final result = await GuardianService.syncMissionsToBackend();
      setState(() => _lastSyncResult = result);

      if (result != null && result['success'] == true) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              'Missions synced: ${result['synced_count']} new, ${result['updated_count']} updated',
            ),
            backgroundColor: Colors.green,
          ),
        );
        _loadMissionStats(); // Refresh stats
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              'Sync failed: ${result?['message'] ?? 'Unknown error'}',
            ),
            backgroundColor: Colors.red,
          ),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Error syncing missions: $e'),
          backgroundColor: Colors.red,
        ),
      );
    } finally {
      setState(() => _isLoading = false);
    }
  }

  Future<void> _runHealthCheck() async {
    setState(() => _isLoading = true);
    try {
      final result = await GuardianService.runMissionHealthCheck();
      setState(() => _healthCheckResult = result);

      if (result != null && result['success'] == true) {
        final data = result['data'];
        final issuesFound = data['issues_found'] ?? 0;

        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Health check complete: $issuesFound issues found'),
            backgroundColor: issuesFound > 0 ? Colors.orange : Colors.green,
          ),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              'Health check failed: ${result?['message'] ?? 'Unknown error'}',
            ),
            backgroundColor: Colors.red,
          ),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Error running health check: $e'),
          backgroundColor: Colors.red,
        ),
      );
    } finally {
      setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 4,
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(Icons.rocket_launch, color: Colors.blue),
                const SizedBox(width: 8),
                Text(
                  'Mission Sync & Health',
                  style: Theme.of(
                    context,
                  ).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold),
                ),
                const Spacer(),
                if (_isLoading)
                  const SizedBox(
                    width: 20,
                    height: 20,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  ),
              ],
            ),
            const SizedBox(height: 16),

            // Mission Statistics
            if (_missionStats != null) ...[
              _buildStatRow(
                'Total Missions',
                '${_missionStats!['total_missions'] ?? 0}',
              ),
              _buildStatRow(
                'Completed',
                '${_missionStats!['completed_missions'] ?? 0}',
              ),
              _buildStatRow(
                'Failed',
                '${_missionStats!['failed_missions'] ?? 0}',
              ),
              _buildStatRow(
                'Counter-based',
                '${_missionStats!['counter_missions'] ?? 0}',
              ),
              _buildStatRow(
                'Total Subtasks',
                '${_missionStats!['total_subtasks'] ?? 0}',
              ),
              _buildStatRow(
                'Completion Rate',
                '${(_missionStats!['completion_rate'] ?? 0).toStringAsFixed(1)}%',
              ),
              const SizedBox(height: 16),
            ],

            // Health Check Results
            if (_healthCheckResult != null &&
                _healthCheckResult!['success'] == true) ...[
              _buildHealthCheckSection(_healthCheckResult!['data']),
              const SizedBox(height: 16),
            ],

            // Action Buttons
            Row(
              children: [
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: _isLoading ? null : _syncMissions,
                    icon: Icon(Icons.sync),
                    label: Text('Sync Missions'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.blue,
                      foregroundColor: Colors.white,
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: _isLoading ? null : _runHealthCheck,
                    icon: Icon(Icons.health_and_safety),
                    label: Text('Health Check'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.green,
                      foregroundColor: Colors.white,
                    ),
                  ),
                ),
              ],
            ),

            // Last Sync Result
            if (_lastSyncResult != null) ...[
              const SizedBox(height: 16),
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color:
                      _lastSyncResult!['success'] == true
                          ? Colors.green.withOpacity(0.1)
                          : Colors.red.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(
                    color:
                        _lastSyncResult!['success'] == true
                            ? Colors.green
                            : Colors.red,
                  ),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Last Sync Result',
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        color:
                            _lastSyncResult!['success'] == true
                                ? Colors.green
                                : Colors.red,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(_lastSyncResult!['message'] ?? 'No message'),
                    if (_lastSyncResult!['synced_count'] != null ||
                        _lastSyncResult!['updated_count'] != null) ...[
                      const SizedBox(height: 4),
                      Text(
                        'Synced: ${_lastSyncResult!['synced_count'] ?? 0}, Updated: ${_lastSyncResult!['updated_count'] ?? 0}',
                        style: TextStyle(fontSize: 12),
                      ),
                    ],
                  ],
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildStatRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 2),
      child: Row(
        children: [
          Text(
            '$label:',
            style: TextStyle(
              fontWeight: FontWeight.w500,
              color: Colors.grey[600],
            ),
          ),
          const SizedBox(width: 8),
          Text(
            value,
            style: TextStyle(
              fontWeight: FontWeight.bold,
              color: Colors.black87,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHealthCheckSection(Map<String, dynamic> data) {
    final issuesFound = data['issues_found'] ?? 0;
    final criticalIssues = data['critical_issues'] ?? 0;
    final highPriorityIssues = data['high_priority_issues'] ?? 0;
    final healthStatus = data['health_status'] ?? 'unknown';

    Color statusColor;
    IconData statusIcon;

    switch (healthStatus) {
      case 'healthy':
        statusColor = Colors.green;
        statusIcon = Icons.check_circle;
        break;
      case 'warning':
        statusColor = Colors.orange;
        statusIcon = Icons.warning;
        break;
      case 'error':
        statusColor = Colors.red;
        statusIcon = Icons.error;
        break;
      default:
        statusColor = Colors.grey;
        statusIcon = Icons.help;
    }

    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: statusColor.withOpacity(0.1),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: statusColor),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(statusIcon, color: statusColor, size: 20),
              const SizedBox(width: 8),
              Text(
                'Mission Health: ${healthStatus.toUpperCase()}',
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  color: statusColor,
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          _buildStatRow('Total Issues', '$issuesFound'),
          _buildStatRow('Critical Issues', '$criticalIssues'),
          _buildStatRow('High Priority Issues', '$highPriorityIssues'),
          _buildStatRow('Total Missions', '${data['total_missions'] ?? 0}'),
          _buildStatRow('Total Subtasks', '${data['total_subtasks'] ?? 0}'),
        ],
      ),
    );
  }
}
