import 'package:flutter/material.dart';
import 'dart:convert';
import '../guardian_service.dart';

class GuardianSuggestionsWidget extends StatefulWidget {
  const GuardianSuggestionsWidget({Key? key}) : super(key: key);

  @override
  State<GuardianSuggestionsWidget> createState() =>
      _GuardianSuggestionsWidgetState();
}

class _GuardianSuggestionsWidgetState extends State<GuardianSuggestionsWidget> {
  List<Map<String, dynamic>> _suggestions = [];
  bool _isLoading = true;
  String? _error;
  Map<String, dynamic>? _statistics;
  String _selectedStatus = 'pending';
  String? _selectedSeverity;
  String? _selectedIssueType;
  int _currentPage = 0;
  final int _pageSize = 10;
  bool _hasMore = true;

  @override
  void initState() {
    super.initState();
    _loadSuggestions();
    _loadStatistics();
  }

  Future<void> _loadSuggestions({bool refresh = false}) async {
    if (refresh) {
      setState(() {
        _currentPage = 0;
        _hasMore = true;
      });
    }

    if (!_hasMore && !refresh) return;

    setState(() {
      _isLoading = true;
      _error = null;
    });

    try {
      final result = await GuardianService.getSuggestions(
        status: _selectedStatus,
        severity: _selectedSeverity,
        issueType: _selectedIssueType,
        limit: _pageSize,
        offset: _currentPage * _pageSize,
      );

      if (result != null && result['status'] == 'success') {
        final newSuggestions = List<Map<String, dynamic>>.from(
          result['data']['suggestions'],
        );

        setState(() {
          if (refresh) {
            _suggestions = newSuggestions;
          } else {
            _suggestions.addAll(newSuggestions);
          }
          _isLoading = false;
          _hasMore = newSuggestions.length == _pageSize;
          if (!refresh) _currentPage++;
        });
      } else {
        setState(() {
          _error = 'Failed to load suggestions';
          _isLoading = false;
        });
      }
    } catch (e) {
      setState(() {
        _error = 'Error: $e';
        _isLoading = false;
      });
    }
  }

  Future<void> _loadStatistics() async {
    try {
      final result = await GuardianService.getSuggestionStatistics();
      if (result != null && result['status'] == 'success') {
        setState(() {
          _statistics = result['data'];
        });
      }
    } catch (e) {
      // Ignore statistics errors
    }
  }

  Future<void> _approveSuggestion(
    String suggestionId, {
    String? feedback,
  }) async {
    try {
      final result = await GuardianService.approveSuggestion(
        suggestionId,
        userFeedback: feedback,
      );

      if (result != null && result['status'] == 'success') {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Suggestion approved successfully'),
            backgroundColor: Colors.green,
          ),
        );
        _loadSuggestions(refresh: true);
        _loadStatistics();
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Failed to approve suggestion'),
            backgroundColor: Colors.red,
          ),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error: $e'), backgroundColor: Colors.red),
      );
    }
  }

  Future<void> _rejectSuggestion(
    String suggestionId, {
    String? feedback,
  }) async {
    try {
      final result = await GuardianService.rejectSuggestion(
        suggestionId,
        userFeedback: feedback,
      );

      if (result != null && result['status'] == 'success') {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Suggestion rejected'),
            backgroundColor: Colors.orange,
          ),
        );
        _loadSuggestions(refresh: true);
        _loadStatistics();
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Failed to reject suggestion'),
            backgroundColor: Colors.red,
          ),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error: $e'), backgroundColor: Colors.red),
      );
    }
  }

  void _showFeedbackDialog(String suggestionId, bool isApprove) {
    final TextEditingController feedbackController = TextEditingController();

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text(isApprove ? 'Approve Suggestion' : 'Reject Suggestion'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text('Would you like to provide feedback?'),
              const SizedBox(height: 16),
              TextField(
                controller: feedbackController,
                decoration: InputDecoration(
                  labelText: 'Feedback (optional)',
                  border: OutlineInputBorder(),
                ),
                maxLines: 3,
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.of(context).pop();
                if (isApprove) {
                  _approveSuggestion(
                    suggestionId,
                    feedback:
                        feedbackController.text.isEmpty
                            ? null
                            : feedbackController.text,
                  );
                } else {
                  _rejectSuggestion(
                    suggestionId,
                    feedback:
                        feedbackController.text.isEmpty
                            ? null
                            : feedbackController.text,
                  );
                }
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: isApprove ? Colors.green : Colors.red,
                foregroundColor: Colors.white,
              ),
              child: Text(isApprove ? 'Approve' : 'Reject'),
            ),
          ],
        );
      },
    );
  }

  Color _getSeverityColor(String severity) {
    switch (severity.toLowerCase()) {
      case 'critical':
        return Colors.red;
      case 'high':
        return Colors.orange;
      case 'medium':
        return Colors.yellow[700]!;
      case 'low':
        return Colors.blue;
      default:
        return Colors.grey;
    }
  }

  Icon _getSeverityIcon(String severity) {
    switch (severity.toLowerCase()) {
      case 'critical':
        return Icon(Icons.error, color: Colors.white);
      case 'high':
        return Icon(Icons.warning, color: Colors.white);
      case 'medium':
        return Icon(Icons.info, color: Colors.white);
      case 'low':
        return Icon(Icons.check_circle, color: Colors.white);
      default:
        return Icon(Icons.help, color: Colors.white);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 8,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
      color: Colors.white.withOpacity(0.95),
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(
                  Icons.health_and_safety,
                  color: Colors.blue[700],
                  size: 28,
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(
                    'Guardian AI Suggestions',
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 20,
                      color: Colors.blue[700],
                    ),
                  ),
                ),
                IconButton(
                  icon: Icon(Icons.refresh),
                  onPressed: () => _loadSuggestions(refresh: true),
                ),
              ],
            ),
            const SizedBox(height: 16),

            // Statistics
            if (_statistics != null) ...[
              Container(
                padding: EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.blue[50],
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Row(
                  children: [
                    Expanded(
                      child: _buildStatItem(
                        'Total',
                        _statistics!['total_suggestions']?.toString() ?? '0',
                      ),
                    ),
                    Expanded(
                      child: _buildStatItem(
                        'Pending',
                        _statistics!['by_status']?['pending']?.toString() ??
                            '0',
                      ),
                    ),
                    Expanded(
                      child: _buildStatItem(
                        'Approved',
                        _statistics!['by_status']?['approved']?.toString() ??
                            '0',
                      ),
                    ),
                    Expanded(
                      child: _buildStatItem(
                        'Rejected',
                        _statistics!['by_status']?['rejected']?.toString() ??
                            '0',
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 16),
            ],

            // Filters
            Row(
              children: [
                Expanded(
                  child: DropdownButtonFormField<String>(
                    value: _selectedStatus,
                    decoration: InputDecoration(
                      labelText: 'Status',
                      border: OutlineInputBorder(),
                    ),
                    items:
                        ['pending', 'approved', 'rejected'].map((status) {
                          return DropdownMenuItem(
                            value: status,
                            child: Text(status.toUpperCase()),
                          );
                        }).toList(),
                    onChanged: (value) {
                      setState(() {
                        _selectedStatus = value!;
                      });
                      _loadSuggestions(refresh: true);
                    },
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: DropdownButtonFormField<String?>(
                    value: _selectedSeverity,
                    decoration: InputDecoration(
                      labelText: 'Severity',
                      border: OutlineInputBorder(),
                    ),
                    items: [
                      DropdownMenuItem(value: null, child: Text('All')),
                      ...['critical', 'high', 'medium', 'low'].map((severity) {
                        return DropdownMenuItem(
                          value: severity,
                          child: Text(severity.toUpperCase()),
                        );
                      }),
                    ],
                    onChanged: (value) {
                      setState(() {
                        _selectedSeverity = value;
                      });
                      _loadSuggestions(refresh: true);
                    },
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),

            // Suggestions List
            if (_isLoading && _suggestions.isEmpty)
              Center(child: CircularProgressIndicator())
            else if (_error != null)
              Center(
                child: Column(
                  children: [
                    Icon(Icons.error, color: Colors.red, size: 48),
                    const SizedBox(height: 8),
                    Text(_error!, style: TextStyle(color: Colors.red)),
                    const SizedBox(height: 8),
                    ElevatedButton(
                      onPressed: () => _loadSuggestions(refresh: true),
                      child: Text('Retry'),
                    ),
                  ],
                ),
              )
            else if (_suggestions.isEmpty)
              Center(
                child: Column(
                  children: [
                    Icon(Icons.check_circle, color: Colors.green, size: 48),
                    const SizedBox(height: 8),
                    Text(
                      'No suggestions found',
                      style: TextStyle(color: Colors.green),
                    ),
                  ],
                ),
              )
            else
              Column(
                children: [
                  ..._suggestions.map(
                    (suggestion) => _buildSuggestionCard(suggestion),
                  ),
                  if (_hasMore)
                    Center(
                      child: Padding(
                        padding: const EdgeInsets.all(16),
                        child: ElevatedButton(
                          onPressed:
                              _isLoading ? null : () => _loadSuggestions(),
                          child:
                              _isLoading
                                  ? SizedBox(
                                    width: 20,
                                    height: 20,
                                    child: CircularProgressIndicator(
                                      strokeWidth: 2,
                                    ),
                                  )
                                  : Text('Load More'),
                        ),
                      ),
                    ),
                ],
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildStatItem(String label, String value) {
    return Column(
      children: [
        Text(
          value,
          style: TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 18,
            color: Colors.blue[700],
          ),
        ),
        Text(label, style: TextStyle(fontSize: 12, color: Colors.grey[600])),
      ],
    );
  }

  Widget _buildSuggestionCard(Map<String, dynamic> suggestion) {
    return Card(
      margin: EdgeInsets.only(bottom: 12),
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: _getSeverityColor(
                      suggestion['severity'] ?? 'medium',
                    ),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: _getSeverityIcon(suggestion['severity'] ?? 'medium'),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        suggestion['issue_description'] ?? 'No description',
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 16,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        '${suggestion['affected_item_type']?.toUpperCase()} - ${suggestion['affected_item_name'] ?? suggestion['affected_item_id']}',
                        style: TextStyle(color: Colors.grey[600], fontSize: 14),
                      ),
                    ],
                  ),
                ),
                Container(
                  padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: _getSeverityColor(
                      suggestion['severity'] ?? 'medium',
                    ).withOpacity(0.2),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(
                    (suggestion['severity'] ?? 'medium').toUpperCase(),
                    style: TextStyle(
                      color: _getSeverityColor(
                        suggestion['severity'] ?? 'medium',
                      ),
                      fontWeight: FontWeight.bold,
                      fontSize: 12,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),

            if (suggestion['current_value'] != null) ...[
              Text(
                'Current Value:',
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  color: Colors.grey[700],
                ),
              ),
              Container(
                width: double.infinity,
                padding: EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: Colors.grey[100],
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(
                  suggestion['current_value'],
                  style: TextStyle(fontFamily: 'monospace'),
                ),
              ),
              const SizedBox(height: 8),
            ],

            Text(
              'Proposed Fix:',
              style: TextStyle(
                fontWeight: FontWeight.bold,
                color: Colors.grey[700],
              ),
            ),
            Container(
              width: double.infinity,
              padding: EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: Colors.blue[50],
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text(
                suggestion['proposed_fix'] ?? 'No fix proposed',
                style: TextStyle(fontFamily: 'monospace'),
              ),
            ),
            const SizedBox(height: 12),

            Row(
              children: [
                Expanded(
                  child: ElevatedButton.icon(
                    icon: Icon(Icons.check, color: Colors.white),
                    label: Text('Approve'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.green,
                      foregroundColor: Colors.white,
                    ),
                    onPressed:
                        () => _showFeedbackDialog(suggestion['id'], true),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: ElevatedButton.icon(
                    icon: Icon(Icons.close, color: Colors.white),
                    label: Text('Reject'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.red,
                      foregroundColor: Colors.white,
                    ),
                    onPressed:
                        () => _showFeedbackDialog(suggestion['id'], false),
                  ),
                ),
              ],
            ),

            const SizedBox(height: 8),
            Text(
              'Created: ${suggestion['created_at'] ?? 'Unknown'}',
              style: TextStyle(color: Colors.grey[500], fontSize: 12),
            ),
          ],
        ),
      ),
    );
  }
}
