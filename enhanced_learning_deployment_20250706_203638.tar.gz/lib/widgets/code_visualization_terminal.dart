import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/ai_learning_provider.dart';
import '../providers/proposal_provider.dart';
import '../providers/system_status_provider.dart';
import '../services/app_logger.dart';
import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart' as http;

/// Code Visualization Terminal Widget
/// Displays real-time backend and frontend code execution logs
class CodeVisualizationTerminal extends StatefulWidget {
  final bool isVisible;
  final VoidCallback? onClose;

  const CodeVisualizationTerminal({
    Key? key,
    required this.isVisible,
    this.onClose,
  }) : super(key: key);

  @override
  State<CodeVisualizationTerminal> createState() =>
      _CodeVisualizationTerminalState();
}

class _CodeVisualizationTerminalState extends State<CodeVisualizationTerminal> {
  final ScrollController _scrollController = ScrollController();
  final List<TerminalLogEntry> _logEntries = [];
  final TextEditingController _commandController = TextEditingController();
  Timer? _logUpdateTimer;
  bool _isConnected = false;
  String _connectionStatus = 'Disconnected';
  Color _connectionColor = Colors.red;
  StreamSubscription? _systemStatusSubscription;
  StreamSubscription? _appLoggerSubscription;

  // Terminal colors
  static const Color backgroundColor = Color(0xFF1E1E1E);
  static const Color textColor = Color(0xFFE0E0E0);
  static const Color errorColor = Color(0xFFFF6B6B);
  static const Color successColor = Color(0xFF51CF66);
  static const Color warningColor = Color(0xFFFFD43B);
  static const Color infoColor = Color(0xFF74C0FC);

  @override
  void initState() {
    super.initState();
    _initializeTerminal();
  }

  void _initializeTerminal() {
    _addLogEntry(
      'Terminal initialized - Capturing real-time app logs',
      'System',
      LogType.info,
    );

    _startLogUpdates();
    _checkConnection();
    _setupLogStreams();
    _setupAppLogger();
  }

  void _setupLogStreams() {
    // Listen to System Status Provider updates (this one has a stream)
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final systemStatusProvider = Provider.of<SystemStatusProvider>(
        context,
        listen: false,
      );
      _systemStatusSubscription = systemStatusProvider.statusUpdateStream
          .listen((data) {
            _addLogEntry(
              'System Status: ${data.toString()}',
              'SYSTEM_STATUS_PROVIDER',
              LogType.info,
            );
          });
    });
  }

  void _setupAppLogger() {
    // Initialize the app logger
    AppLogger.instance.initialize();

    // Listen to app logger stream
    _appLoggerSubscription = AppLogger.instance.logStream.listen((logEntry) {
      _addLogEntry(
        logEntry.message,
        logEntry.source,
        _convertLogLevel(logEntry.level),
      );
    });

    // Add existing logs to terminal
    final existingLogs = AppLogger.instance.logHistory;
    for (var log in existingLogs) {
      _addLogEntry(log.message, log.source, _convertLogLevel(log.level));
    }
  }

  void _startLogUpdates() {
    _logUpdateTimer?.cancel();
    _logUpdateTimer = Timer.periodic(const Duration(seconds: 1), (_) {
      _fetchBackendLogs();
      _fetchFrontendLogs();
      _checkProviderStatus();
    });
  }

  void _checkProviderStatus() {
    if (!mounted) return;

    WidgetsBinding.instance.addPostFrameCallback((_) {
      try {
        final aiLearningProvider = Provider.of<AILearningProvider>(
          context,
          listen: false,
        );
        final proposalProvider = Provider.of<ProposalProvider>(
          context,
          listen: false,
        );
        final systemStatusProvider = Provider.of<SystemStatusProvider>(
          context,
          listen: false,
        );

        // Add periodic status updates
        _addLogEntry(
          'AI Learning Data: ${aiLearningProvider.learningData.length} entries | Proposals: ${proposalProvider.proposals.length} | System Health: ${systemStatusProvider.systemHealth} | AI Operations: ${false}',
          'Status',
          LogType.info,
        );
      } catch (e) {
        // Provider not available, skip this update
      }
    });
  }

  Future<void> _checkConnection() async {
    try {
      final response = await http
          .get(
            Uri.parse('http://34.202.215.209:4000/api/health'),
            headers: {
              'Content-Type': 'application/json',
              'User-Agent': 'LVL_UP_Flutter_App',
            },
          )
          .timeout(const Duration(seconds: 5));

      setState(() {
        _isConnected = response.statusCode == 200;
        _connectionStatus = _isConnected ? 'Connected' : 'Error';
        _connectionColor = _isConnected ? Colors.green : Colors.red;
      });

      _addLogEntry(
        _isConnected
            ? 'Backend connection established'
            : 'Backend connection failed',
        'System',
        _isConnected ? LogType.success : LogType.error,
      );
    } catch (e) {
      setState(() {
        _isConnected = false;
        _connectionStatus = 'Disconnected';
        _connectionColor = Colors.red;
      });

      _addLogEntry(
        'Backend connection error: ${e.toString()}',
        'System',
        LogType.error,
      );
    }
  }

  Future<void> _fetchBackendLogs() async {
    if (!_isConnected) return;

    try {
      final response = await http
          .get(
            Uri.parse('http://34.202.215.209:4000/api/logs/backend'),
            headers: {
              'Content-Type': 'application/json',
              'User-Agent': 'LVL_UP_Flutter_App',
            },
          )
          .timeout(const Duration(seconds: 5));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        final logs = data['logs'] as List? ?? [];

        for (var log in logs) {
          _addLogEntry(
            log['message'] ?? 'Unknown log message',
            log['source'] ?? 'Backend',
            _parseLogType(log['level'] ?? 'info'),
            timestamp: log['timestamp'],
          );
        }
      }
    } catch (e) {
      // Silently handle connection errors
    }
  }

  Future<void> _fetchFrontendLogs() async {
    // Simulate frontend logs for now
    // In a real implementation, this would fetch from a frontend logging service
    if (mounted && _isConnected) {
      _addLogEntry('Frontend status check completed', 'Frontend', LogType.info);
    }
  }

  LogType _parseLogType(String level) {
    switch (level.toLowerCase()) {
      case 'error':
        return LogType.error;
      case 'warn':
      case 'warning':
        return LogType.warning;
      case 'success':
        return LogType.success;
      case 'info':
      default:
        return LogType.info;
    }
  }

  LogType _convertLogLevel(LogLevel level) {
    switch (level) {
      case LogLevel.error:
        return LogType.error;
      case LogLevel.warning:
        return LogType.warning;
      case LogLevel.success:
        return LogType.success;
      case LogLevel.debug:
      case LogLevel.info:
        return LogType.info;
    }
  }

  void _addLogEntry(
    String message,
    String source,
    LogType type, {
    String? timestamp,
  }) {
    if (!mounted) return;

    setState(() {
      _logEntries.add(
        TerminalLogEntry(
          message: message,
          source: source,
          type: type,
          timestamp: timestamp ?? DateTime.now().toIso8601String(),
        ),
      );

      // Keep only last 200 entries to prevent memory issues
      if (_logEntries.length > 200) {
        _logEntries.removeAt(0);
      }
    });

    // Auto-scroll to bottom
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  void _executeCommand(String command) {
    if (command.trim().isEmpty) return;

    _addLogEntry('Executing command: $command', 'User', LogType.info);

    // Handle different commands
    switch (command.toLowerCase()) {
      case 'clear':
        setState(() {
          _logEntries.clear();
        });
        AppLogger.instance.clearHistory();
        _addLogEntry(
          'Terminal and log history cleared',
          'System',
          LogType.success,
        );
        break;
      case 'status':
        _addLogEntry(
          'Connection: $_connectionStatus | Logs: ${_logEntries.length} | Terminal Active',
          'System',
          LogType.info,
        );
        break;
      case 'health':
        _checkConnection();
        break;
      case 'providers':
        _addLogEntry(
          'Available Providers: AI Learning, Proposal, System Status, Mission, Chaos Warp',
          'System',
          LogType.info,
        );
        break;
      case 'logs':
        _addLogEntry(
          'Total logs captured: ${AppLogger.instance.logHistory.length}',
          'System',
          LogType.info,
        );
        break;
      case 'help':
        _addLogEntry(
          'Available commands: clear, status, health, providers, logs, help',
          'System',
          LogType.info,
        );
        break;
      default:
        _addLogEntry(
          'Unknown command: $command. Type "help" for available commands.',
          'System',
          LogType.warning,
        );
    }

    _commandController.clear();
  }

  @override
  Widget build(BuildContext context) {
    if (!widget.isVisible) return const SizedBox.shrink();

    return Container(
      width: 400,
      height: 600,
      decoration: BoxDecoration(
        color: backgroundColor,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: Colors.grey[800]!),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.3),
            blurRadius: 10,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: Column(
        children: [
          // Terminal header
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: Colors.grey[900],
              borderRadius: const BorderRadius.only(
                topLeft: Radius.circular(8),
                topRight: Radius.circular(8),
              ),
            ),
            child: Row(
              children: [
                // Connection indicator
                Container(
                  width: 8,
                  height: 8,
                  decoration: BoxDecoration(
                    color: _connectionColor,
                    shape: BoxShape.circle,
                  ),
                ),
                const SizedBox(width: 8),
                Text(
                  'LVL UP Terminal',
                  style: TextStyle(
                    color: textColor,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const Spacer(),
                Text(
                  _connectionStatus,
                  style: TextStyle(color: _connectionColor, fontSize: 12),
                ),
                const SizedBox(width: 8),
                IconButton(
                  onPressed: () {
                    if (widget.onClose != null) {
                      widget.onClose!();
                    } else {
                      Navigator.of(context).pop(); // Return to homepage
                    }
                  },
                  icon: Icon(Icons.close, color: textColor, size: 20),
                  padding: EdgeInsets.zero,
                  constraints: const BoxConstraints(),
                  tooltip: 'Close Terminal',
                ),
              ],
            ),
          ),

          // Terminal content
          Expanded(
            child: Container(
              padding: const EdgeInsets.all(12),
              child: Column(
                children: [
                  // Log display area
                  Expanded(
                    child: Container(
                      decoration: BoxDecoration(
                        color: Colors.black,
                        borderRadius: BorderRadius.circular(4),
                      ),
                      child: ListView.builder(
                        controller: _scrollController,
                        padding: const EdgeInsets.all(8),
                        itemCount: _logEntries.length,
                        itemBuilder: (context, index) {
                          final entry = _logEntries[index];
                          return _buildLogEntry(entry);
                        },
                      ),
                    ),
                  ),

                  const SizedBox(height: 8),

                  // Command input
                  Row(
                    children: [
                      Text(
                        '> ',
                        style: TextStyle(
                          color: textColor,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Expanded(
                        child: TextField(
                          controller: _commandController,
                          style: TextStyle(color: textColor),
                          decoration: const InputDecoration(
                            border: InputBorder.none,
                            hintText: 'Enter command...',
                            hintStyle: TextStyle(color: Colors.grey),
                          ),
                          onSubmitted: _executeCommand,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildLogEntry(TerminalLogEntry entry) {
    Color entryColor;
    switch (entry.type) {
      case LogType.error:
        entryColor = errorColor;
        break;
      case LogType.warning:
        entryColor = warningColor;
        break;
      case LogType.success:
        entryColor = successColor;
        break;
      case LogType.info:
        entryColor = infoColor;
        break;
    }

    final timestamp = DateTime.tryParse(entry.timestamp);
    final timeString =
        timestamp != null
            ? '${timestamp.hour.toString().padLeft(2, '0')}:${timestamp.minute.toString().padLeft(2, '0')}:${timestamp.second.toString().padLeft(2, '0')}'
            : '';

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 2),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Timestamp
          SizedBox(
            width: 70,
            child: Text(
              timeString,
              style: TextStyle(
                color: Colors.grey[500],
                fontSize: 11,
                fontFamily: 'monospace',
              ),
            ),
          ),

          // Source
          SizedBox(
            width: 80,
            child: Text(
              '[${entry.source}]',
              style: TextStyle(
                color: entryColor,
                fontSize: 11,
                fontWeight: FontWeight.bold,
                fontFamily: 'monospace',
              ),
            ),
          ),

          // Message
          Expanded(
            child: Text(
              entry.message,
              style: TextStyle(
                color: textColor,
                fontSize: 12,
                fontFamily: 'monospace',
              ),
            ),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _logUpdateTimer?.cancel();
    _systemStatusSubscription?.cancel();
    _appLoggerSubscription?.cancel();
    _scrollController.dispose();
    _commandController.dispose();
    super.dispose();
  }
}

/// Terminal Log Entry
class TerminalLogEntry {
  final String message;
  final String source;
  final LogType type;
  final String timestamp;

  TerminalLogEntry({
    required this.message,
    required this.source,
    required this.type,
    required this.timestamp,
  });
}

/// Log Types
enum LogType { info, success, warning, error }
