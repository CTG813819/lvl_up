import 'package:flutter/material.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'dart:io';
import 'guardian_service.dart';
import 'dart:math';
import 'widgets/guardian_suggestions_widget.dart';
import 'widgets/mission_sync_widget.dart';

class TerraScreen extends StatefulWidget {
  const TerraScreen({Key? key}) : super(key: key);

  @override
  State<TerraScreen> createState() => _TerraScreenState();
}

class _TerraScreenState extends State<TerraScreen> {
  List<Map<String, dynamic>> _guardianLogs = [];
  List<Map<String, dynamic>> _guardianProposals = [];
  bool _isLoading = true;
  String? _error;
  Map<String, dynamic>? _diagnostics;
  bool _safeMode = false;
  bool _showFeedbackPrompt = false;
  bool _lastRecoverySuccess = false;
  // For log expansion
  int? _expandedLogIndex;
  // Removed button info toggles
  // Add a toggle for diagnostics visibility
  bool _showDiagnostics = false;
  bool _diagnosticsRunning = false;

  @override
  void initState() {
    super.initState();
    _fetchGuardianLogs();
  }

  Future<void> _fetchGuardianLogs() async {
    setState(() {
      _isLoading = true;
      _error = null;
    });
    try {
      final response = await http.get(
        Uri.parse(
          'http://ec2-34-202-215-209.compute-1.amazonaws.com:4000/api/codex/',
        ),
      );
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        final chapters = data['chapters'] as List;
        final logs = <Map<String, dynamic>>[];
        final proposals = <Map<String, dynamic>>[];
        for (final chapter in chapters) {
          for (final event in (chapter['proposals'] ?? [])) {
            if (event['ai_type'] == 'guardian' ||
                event['type'] == 'guardian_self_heal' ||
                event['type'] == 'guardian_ui_error' ||
                event['type'] == 'guardian_custom') {
              logs.add(event);
              proposals.add({
                ...event,
                'chapter': chapter['chapter'],
                'date': chapter['date'],
                'summary': chapter['summary'],
              });
            }
          }
        }
        setState(() {
          _guardianLogs = logs.reversed.toList();
          _guardianProposals = proposals.reversed.toList();
          _isLoading = false;
        });
      } else {
        setState(() {
          _error = 'Failed to load Guardian logs.';
          _isLoading = false;
        });
      }
    } catch (e) {
      setState(() {
        _error = 'Error: $e';
        _isLoading = false;
      });
    }
  }

  Future<void> _runDiagnostics() async {
    setState(() {
      if (_showDiagnostics) {
        // Hide diagnostics if already shown
        _showDiagnostics = false;
        _diagnostics = null;
        return;
      }
      _diagnostics = null;
      _showDiagnostics = true;
      _diagnosticsRunning = true;
    });
    final results = <String, dynamic>{};
    // Run all backend diagnostics in parallel
    final futures = await Future.wait([
      GuardianService.getBackendHealth(),
      GuardianService.getImperiumMonitoring(),
      GuardianService.getImperiumImprovements(),
      GuardianService.getImperiumIssues(),
      GuardianService.getImperiumStatus(),
      GuardianService.getGuardianOverview(),
      GuardianService.getSecurityStatus(),
      GuardianService.getCodeReviewStatus(),
      GuardianService.getThreatDetection(),
      GuardianService.getVulnerabilityScan(),
      GuardianService.getGuardianLearnings(),
    ]);
    // Assign results
    results['Internet'] =
        futures[0] != null ? 'OK' : 'No internet or backend unreachable';
    results['Backend Health'] = futures[0];
    results['Imperium Monitoring'] = futures[1];
    results['Imperium Improvements'] = futures[2];
    results['Imperium Issues'] = futures[3];
    results['Imperium Status'] = futures[4];
    results['Guardian Overview'] = futures[5];
    results['Guardian Security'] = futures[6];
    results['Guardian Code Review'] = futures[7];
    results['Guardian Threat Detection'] = futures[8];
    results['Guardian Vulnerability Scan'] = futures[9];
    results['Guardian Learnings'] = futures[10];
    // Permissions and Storage (simulate)
    results['Permissions'] = 'OK';
    try {
      final file = File('/tmp/terra_test.txt');
      await file.writeAsString('test');
      final content = await file.readAsString();
      results['Storage'] = content == 'test' ? 'OK' : 'Storage error';
      await file.delete();
    } catch (_) {
      results['Storage'] = 'Storage error';
    }
    setState(() {
      _diagnostics = results;
      _diagnosticsRunning = false;
    });
  }

  Future<void> _sendDiagnosticReport() async {
    final summary = 'User sent diagnostic report';
    final details = {'diagnostics': _diagnostics, 'safe_mode': _safeMode};
    await GuardianService.logCustomGuardianEvent(
      summary,
      details: details,
      allOk: _diagnostics?['Backend'] == 'OK',
    );
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Diagnostic report sent to Guardian.'),
        backgroundColor: Colors.blue,
      ),
    );
  }

  void _clearCache() {
    // Simulate cache clear
    setState(() {
      _showFeedbackPrompt = true;
      _lastRecoverySuccess = true;
    });
    GuardianService.logCustomGuardianEvent('User cleared cache', allOk: true);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Cache cleared.'), backgroundColor: Colors.green),
    );
  }

  void _restartApp() {
    // Simulate app restart (in real app, use restart_app or similar)
    setState(() {
      _showFeedbackPrompt = true;
      _lastRecoverySuccess = true;
    });
    GuardianService.logCustomGuardianEvent('User restarted app', allOk: true);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('App restart simulated.'),
        backgroundColor: Colors.green,
      ),
    );
  }

  void _toggleSafeMode() {
    setState(() {
      _safeMode = !_safeMode;
      _showFeedbackPrompt = true;
      _lastRecoverySuccess = _safeMode;
    });
    GuardianService.logCustomGuardianEvent(
      'User toggled Safe Mode',
      details: {'enabled': _safeMode},
      allOk: _safeMode,
    );
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(_safeMode ? 'Safe Mode enabled.' : 'Safe Mode disabled.'),
        backgroundColor: Colors.orange,
      ),
    );
  }

  void _sendFeedback(bool fixed) {
    GuardianService.logCustomGuardianEvent(
      'User feedback after recovery',
      details: {'fixed': fixed},
      allOk: fixed,
    );
    setState(() {
      _showFeedbackPrompt = false;
    });
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          fixed ? 'Thank you for your feedback!' : 'We will keep monitoring.',
        ),
        backgroundColor: fixed ? Colors.green : Colors.red,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: const Text(
          'Terra',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: _fetchGuardianLogs,
          ),
        ],
      ),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Color(0xFFB3C6FF), Color(0xFF4F8DFF)],
          ),
        ),
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 80, 16, 16),
          children: [
            Card(
              elevation: 8,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(24),
              ),
              color: Colors.white.withOpacity(0.95),
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: ElevatedButton.icon(
                            icon: Icon(
                              Icons.health_and_safety,
                              color: Colors.white,
                            ),
                            label: Text(
                              'Run Diagnostics',
                              style: TextStyle(fontWeight: FontWeight.bold),
                            ),
                            style: ElevatedButton.styleFrom(
                              backgroundColor:
                                  _diagnosticsRunning
                                      ? Colors.red
                                      : Colors.blue[100],
                              foregroundColor:
                                  _diagnosticsRunning
                                      ? Colors.white
                                      : Colors.blue[900],
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(16),
                              ),
                              elevation: 0,
                              padding: const EdgeInsets.symmetric(vertical: 16),
                            ),
                            onPressed: _runDiagnostics,
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: ElevatedButton.icon(
                            icon: Icon(
                              Icons.report,
                              color: Colors.blueGrey[700],
                            ),
                            label: Text(
                              'Send Diagnostic Report',
                              style: TextStyle(fontWeight: FontWeight.bold),
                            ),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.blueGrey[100],
                              foregroundColor: Colors.blueGrey[900],
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(16),
                              ),
                              elevation: 0,
                              padding: const EdgeInsets.symmetric(vertical: 16),
                            ),
                            onPressed:
                                _diagnostics == null
                                    ? null
                                    : _sendDiagnosticReport,
                          ),
                        ),
                      ],
                    ),
                    if (_showDiagnostics && _diagnostics != null) ...[
                      const SizedBox(height: 18),
                      Text(
                        'Diagnostics Results:',
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 18,
                          color: Color(0xFF4F8DFF),
                        ),
                      ),
                      const SizedBox(height: 8),
                      ..._diagnostics!.entries.map((e) {
                        if (e.key == 'Guardian Learnings' &&
                            e.value != null &&
                            e.value['learnings'] != null) {
                          return Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Guardian AI Learnings:',
                                style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  color: Colors.indigo,
                                ),
                              ),
                              ...List.generate(
                                (e.value['learnings'] as List).length,
                                (i) {
                                  final l = e.value['learnings'][i];
                                  return Padding(
                                    padding: const EdgeInsets.symmetric(
                                      vertical: 2,
                                    ),
                                    child: Row(
                                      children: [
                                        Icon(
                                          Icons.school,
                                          color: Colors.blue[700],
                                          size: 18,
                                        ),
                                        const SizedBox(width: 6),
                                        Expanded(
                                          child: Text(
                                            '- ${l['type']}: ${l['insight']}',
                                            style: TextStyle(
                                              color: Colors.black87,
                                            ),
                                          ),
                                        ),
                                        Container(
                                          margin: const EdgeInsets.only(
                                            left: 8,
                                          ),
                                          padding: const EdgeInsets.symmetric(
                                            horizontal: 8,
                                            vertical: 2,
                                          ),
                                          decoration: BoxDecoration(
                                            color: Colors.blue[50],
                                            borderRadius: BorderRadius.circular(
                                              8,
                                            ),
                                          ),
                                          child: Text(
                                            '${(l['confidence'] * 100).toStringAsFixed(1)}%',
                                            style: TextStyle(
                                              fontSize: 12,
                                              color: Colors.blue[900],
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  );
                                },
                              ),
                            ],
                          );
                        } else if (e.value is Map<String, dynamic> &&
                            e.value['status'] == 'success') {
                          return Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                '${e.key}:',
                                style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  color: Colors.indigo,
                                ),
                              ),
                              ...e.value.entries
                                  .where((kv) => kv.key != 'status')
                                  .map((kv) {
                                    final isOk =
                                        kv.value == 'OK' || kv.value == true;
                                    return Padding(
                                      padding: const EdgeInsets.symmetric(
                                        vertical: 2,
                                      ),
                                      child: Row(
                                        children: [
                                          Icon(
                                            isOk
                                                ? Icons.check_circle
                                                : Icons.error,
                                            color:
                                                isOk
                                                    ? Colors.green
                                                    : Colors.red,
                                            size: 18,
                                          ),
                                          const SizedBox(width: 6),
                                          Expanded(
                                            child: Text(
                                              '${kv.key}: ${kv.value}',
                                              style: TextStyle(
                                                color: Colors.black87,
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    );
                                  }),
                            ],
                          );
                        } else {
                          final isOk = e.value == 'OK' || e.value == true;
                          return Padding(
                            padding: const EdgeInsets.symmetric(vertical: 2),
                            child: Row(
                              children: [
                                Icon(
                                  isOk ? Icons.check_circle : Icons.error,
                                  color: isOk ? Colors.green : Colors.red,
                                  size: 18,
                                ),
                                const SizedBox(width: 6),
                                Expanded(
                                  child: Text(
                                    '${e.key}: ${e.value}',
                                    style: TextStyle(color: Colors.black87),
                                  ),
                                ),
                              ],
                            ),
                          );
                        }
                      }),
                    ],
                    const SizedBox(height: 18),
                    Row(
                      children: [
                        Expanded(
                          child: ElevatedButton.icon(
                            icon: Icon(
                              Icons.cleaning_services,
                              color: Colors.blue[800],
                            ),
                            label: Text(
                              'Clear Cache',
                              style: TextStyle(fontWeight: FontWeight.bold),
                            ),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.blue[50],
                              foregroundColor: Colors.blue[900],
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(16),
                              ),
                              elevation: 0,
                              padding: const EdgeInsets.symmetric(vertical: 16),
                            ),
                            onPressed: _clearCache,
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: ElevatedButton.icon(
                            icon: Icon(
                              Icons.restart_alt,
                              color: Colors.blue[800],
                            ),
                            label: Text(
                              'Restart App',
                              style: TextStyle(fontWeight: FontWeight.bold),
                            ),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.blue[50],
                              foregroundColor: Colors.blue[900],
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(16),
                              ),
                              elevation: 0,
                              padding: const EdgeInsets.symmetric(vertical: 16),
                            ),
                            onPressed: _restartApp,
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: ElevatedButton.icon(
                            icon: Icon(Icons.shield, color: Colors.white),
                            label: Text(
                              _safeMode
                                  ? 'Disable Safe Mode'
                                  : 'Enable Safe Mode',
                              style: TextStyle(fontWeight: FontWeight.bold),
                            ),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.orange,
                              foregroundColor: Colors.white,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(16),
                              ),
                              elevation: 0,
                              padding: const EdgeInsets.symmetric(vertical: 16),
                            ),
                            onPressed: _toggleSafeMode,
                          ),
                        ),
                      ],
                    ),
                    if (_showFeedbackPrompt) ...[
                      const SizedBox(height: 16),
                      Text(
                        'Did this fix your issue?',
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          color: Colors.indigo,
                        ),
                      ),
                      Row(
                        children: [
                          Expanded(
                            child: ElevatedButton(
                              onPressed: () => _sendFeedback(true),
                              child: Text(
                                'Yes',
                                style: TextStyle(fontWeight: FontWeight.bold),
                              ),
                              style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.green,
                                foregroundColor: Colors.white,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(12),
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: ElevatedButton(
                              onPressed: () => _sendFeedback(false),
                              child: Text(
                                'No',
                                style: TextStyle(fontWeight: FontWeight.bold),
                              ),
                              style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.red,
                                foregroundColor: Colors.white,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(12),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ],
                ),
              ),
            ),
            const SizedBox(height: 32),

            // Guardian AI Suggestions Section
            GuardianSuggestionsWidget(),
            const SizedBox(height: 32),

            // Mission Sync & Health Section
            MissionSyncWidget(),
            const SizedBox(height: 32),

            Text(
              'Terra Protects',
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 22,
                color: Colors.black,
                fontFamily: 'Roboto',
              ),
            ),
            // Show the improved endpoint status graph only when diagnostics are not being shown
            if (!_showDiagnostics)
              _diagnostics != null
                  ? Padding(
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    child: _EndpointStatusGraph(diagnostics: _diagnostics!),
                  )
                  : SizedBox.shrink(),
            const SizedBox(height: 12),
            _isLoading
                ? const Center(child: CircularProgressIndicator())
                : _error != null
                ? Center(child: Text(_error!))
                : _guardianProposals.isEmpty
                ? const Center(
                  child: Text('No Guardian AI actions logged yet.'),
                )
                : Container(
                  decoration: BoxDecoration(
                    color: Colors.blue[50]?.withOpacity(0.7),
                    borderRadius: BorderRadius.circular(18),
                  ),
                  height: 350, // Adjust as needed for your layout
                  child: Scrollbar(
                    thumbVisibility: true,
                    child: SingleChildScrollView(
                      child: ListView.builder(
                        shrinkWrap: true,
                        physics: NeverScrollableScrollPhysics(),
                        itemCount: _guardianProposals.length,
                        itemBuilder: (context, idx) {
                          final proposal = _guardianProposals[idx];
                          final romanNumeral = _toRoman(
                            _guardianProposals.length - idx,
                          );
                          final isExpanded = _expandedLogIndex == idx;
                          return Card(
                            margin: const EdgeInsets.symmetric(
                              horizontal: 8,
                              vertical: 10,
                            ),
                            elevation: 3,
                            color: isExpanded ? Colors.red[100] : Colors.white,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(16),
                            ),
                            child: InkWell(
                              borderRadius: BorderRadius.circular(16),
                              onTap: () {
                                setState(() {
                                  _expandedLogIndex = isExpanded ? null : idx;
                                });
                              },
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  ListTile(
                                    leading: Icon(
                                      Icons.shield,
                                      color: Colors.blue[700],
                                    ),
                                    title: Text(
                                      'Terra $romanNumeral',
                                      style: TextStyle(
                                        fontWeight: FontWeight.bold,
                                        color: Colors.blue[900],
                                      ),
                                    ),
                                    subtitle: Text(
                                      proposal['date'] != null
                                          ? 'Date: ${proposal['date']}'
                                          : '',
                                      style: TextStyle(color: Colors.black54),
                                    ),
                                  ),
                                  if (isExpanded)
                                    Padding(
                                      padding: const EdgeInsets.fromLTRB(
                                        16,
                                        0,
                                        16,
                                        16,
                                      ),
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          if (proposal['summary'] != null)
                                            Text(
                                              'Summary: ${proposal['summary']}',
                                              style: TextStyle(
                                                color: Colors.black87,
                                              ),
                                            ),
                                          if (proposal['ai_type'] != null)
                                            Text(
                                              'AI Type: ${proposal['ai_type']}',
                                              style: TextStyle(
                                                color: Colors.black87,
                                              ),
                                            ),
                                          if (proposal['status'] != null)
                                            Text(
                                              'Status: ${proposal['status']}',
                                              style: TextStyle(
                                                color: Colors.black87,
                                              ),
                                            ),
                                          if (proposal['file_path'] != null)
                                            Text(
                                              'File: ${proposal['file_path']}',
                                              style: TextStyle(
                                                color: Colors.black87,
                                              ),
                                            ),
                                          if (proposal['improvement_type'] !=
                                              null)
                                            Text(
                                              'Improvement: ${proposal['improvement_type']}',
                                              style: TextStyle(
                                                color: Colors.black87,
                                              ),
                                            ),
                                          if (proposal['confidence'] != null)
                                            Text(
                                              'Confidence: ${(proposal['confidence'] * 100).toStringAsFixed(1)}%',
                                              style: TextStyle(
                                                color: Colors.black87,
                                              ),
                                            ),
                                          if (proposal['user_feedback'] != null)
                                            Text(
                                              'User Feedback: ${proposal['user_feedback']}',
                                              style: TextStyle(
                                                color: Colors.black87,
                                              ),
                                            ),
                                          if (proposal['test_status'] != null)
                                            Text(
                                              'Test Status: ${proposal['test_status']}',
                                              style: TextStyle(
                                                color: Colors.black87,
                                              ),
                                            ),
                                          if (proposal['ai_reasoning'] != null)
                                            Text(
                                              'AI Reasoning: ${proposal['ai_reasoning']}',
                                              style: TextStyle(
                                                color: Colors.black87,
                                              ),
                                            ),
                                          if (proposal['user_feedback_reason'] !=
                                              null)
                                            Text(
                                              'User Feedback Reason: ${proposal['user_feedback_reason']}',
                                              style: TextStyle(
                                                color: Colors.black87,
                                              ),
                                            ),
                                          if (proposal['created_at'] != null)
                                            Text(
                                              'Created: ${proposal['created_at']}',
                                              style: TextStyle(
                                                color: Colors.black54,
                                              ),
                                            ),
                                          if (proposal['updated_at'] != null)
                                            Text(
                                              'Updated: ${proposal['updated_at']}',
                                              style: TextStyle(
                                                color: Colors.black54,
                                              ),
                                            ),
                                        ],
                                      ),
                                    ),
                                ],
                              ),
                            ),
                          );
                        },
                      ),
                    ),
                  ),
                ),
          ],
        ),
      ),
    );
  }

  // Helper for Roman numerals
  String _toRoman(int number) {
    if (number < 1) return '';
    final List<MapEntry<String, int>> numerals = [
      MapEntry('M', 1000),
      MapEntry('CM', 900),
      MapEntry('D', 500),
      MapEntry('CD', 400),
      MapEntry('C', 100),
      MapEntry('XC', 90),
      MapEntry('L', 50),
      MapEntry('XL', 40),
      MapEntry('X', 10),
      MapEntry('IX', 9),
      MapEntry('V', 5),
      MapEntry('IV', 4),
      MapEntry('I', 1),
    ];
    var result = '';
    var n = number;
    for (final pair in numerals) {
      while (n >= pair.value) {
        result += pair.key;
        n -= pair.value;
      }
    }
    return result;
  }
}

// --- Endpoint Status Graph Widget ---
class _EndpointStatusGraph extends StatelessWidget {
  final Map<String, dynamic> diagnostics;
  _EndpointStatusGraph({required this.diagnostics});

  @override
  Widget build(BuildContext context) {
    final endpoints = diagnostics.entries.where(
      (e) =>
          e.key != 'Permissions' && e.key != 'Storage' && e.key != 'Internet',
    );
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Live Endpoint Status',
          style: TextStyle(
            fontWeight: FontWeight.bold,
            color: Colors.blue[900],
            fontSize: 16,
          ),
        ),
        const SizedBox(height: 8),
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: Row(
            children:
                endpoints.map((e) {
                  final isOk =
                      e.value == 'OK' ||
                      (e.value is Map &&
                          (e.value['status'] == 'success' ||
                              e.value['ok'] == true));
                  return Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 8.0),
                    child: Column(
                      children: [
                        Container(
                          height: 44,
                          width: 44,
                          decoration: BoxDecoration(
                            color: isOk ? Colors.green : Colors.red,
                            shape: BoxShape.circle,
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black12,
                                blurRadius: 4,
                                offset: Offset(0, 2),
                              ),
                            ],
                          ),
                          child: Icon(
                            isOk ? Icons.check : Icons.error,
                            color: Colors.white,
                            size: 28,
                          ),
                        ),
                        const SizedBox(height: 4),
                        SizedBox(
                          width: 60,
                          child: Text(
                            _shortLabel(e.key),
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              fontSize: 11,
                              color: Colors.black87,
                            ),
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                      ],
                    ),
                  );
                }).toList(),
          ),
        ),
      ],
    );
  }

  String _shortLabel(String key) {
    // Shorten common endpoint names for clarity
    if (key.toLowerCase().contains('imperium'))
      return 'Imperium\n' + key.split(' ').last;
    if (key.toLowerCase().contains('guardian'))
      return 'Guardian\n' + key.split(' ').last;
    if (key.toLowerCase().contains('backend')) return 'Backend';
    if (key.toLowerCase().contains('learnings')) return 'Learnings';
    if (key.toLowerCase().contains('health')) return 'Health';
    return key.length > 14 ? key.substring(0, 13) + '…' : key;
  }
}
