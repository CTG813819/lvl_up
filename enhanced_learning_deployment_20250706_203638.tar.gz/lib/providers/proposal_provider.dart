import 'dart:collection';
import 'package:flutter/material.dart';
import 'package:the_codex/main.dart';
import '../models/ai_proposal.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:socket_io_client/socket_io_client.dart' as IO;
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'dart:io';
import 'dart:async';
import 'package:provider/provider.dart';
import '../providers/ai_learning_provider.dart';
import 'package:flutter/foundation.dart';
import '../services/network_config.dart';

class ProposalProvider extends ChangeNotifier {
  final List<AIProposal> _proposals = [];
  IO.Socket? _socket;
  final FlutterLocalNotificationsPlugin _notifications =
      FlutterLocalNotificationsPlugin();

  // Flag to prevent multiple initializations
  bool _isInitialized = false;

  // AI Learning integration

  // Use network configuration service
  static String get _backendUrl => NetworkConfig.backendUrl;

  // Public getter for backend URL
  static String get backendUrl => _backendUrl;

  // Mock mode for testing when backend is not available
  static bool _useMockMode =
      false; // Start in real mode, fallback to mock if needed

  // Connection state tracking
  static bool _isBackendAvailable = false;
  static int _consecutiveFailures = 0;
  static const int _maxFailures =
      10; // Switch to mock mode after 10 consecutive failures

  // Public getter for mock mode status
  static bool get useMockMode => _useMockMode;
  static bool get isBackendAvailable => _isBackendAvailable;

  // Connection notification tracking
  static const int _fourHoursMs = 4 * 60 * 60 * 1000;
  static int _lastConnectionNotification = 0;
  static List<Map<String, dynamic>> _connectionErrorBuffer = [];

  // Timer for periodic polling
  Timer? _pollingTimer;

  bool get isOperating {
    return true;
  }

  UnmodifiableListView<AIProposal> get proposals {
    final seen = <String>{};
    final unique = <AIProposal>[];
    for (final p in _proposals) {
      final key = '${p.filePath}|${p.aiType}|${p.status}';
      if (!seen.contains(key)) {
        seen.add(key);
        unique.add(p);
      }
    }
    return UnmodifiableListView(unique);
  }

  List<AIProposal> get pendingProposals =>
      proposals.where((p) => p.status == ProposalStatus.pending).toList();

  void _disposeSocket() {
    if (_socket != null) {
      _socket!.disconnect();
      _socket!.dispose();
      _socket = null;
    }
  }

  void _disposeNotifications() {
    // Stop any notification timers or listeners
  }

  ProposalProvider() {
    print(
      '[PROPOSAL_PROVIDER] 📋 Proposal Provider created - starting autonomous operation',
    );
    // Initialize immediately
    WidgetsBinding.instance.addPostFrameCallback((_) {
      initialize();
    });
  }

  Future<void> initialize() async {
    if (_isInitialized) {
      print('[PROPOSAL_PROVIDER] Already initialized, skipping...');
      return;
    }

    print(
      '[PROPOSAL_PROVIDER] 🚀 Initializing autonomous proposal provider...',
    );
    _isInitialized = true;

    // Always start autonomous operation - don't depend on user interaction
    await _initializeSocketConnection();
    await fetchProposals();
    _startAutonomousPolling();

    print(
      '[PROPOSAL_PROVIDER] ✅ Autonomous proposal provider initialized and running',
    );
  }

  void _startAutonomousPolling() {
    if (_pollingTimer != null) return; // Already polling
    _pollingTimer = Timer.periodic(const Duration(seconds: 60), (_) {
      // Check operational hours but still run autonomously
      if (isOperating) {
        fetchProposals();
      } else {
        print(
          '[PROPOSAL_PROVIDER] ⏸️ Autonomous polling paused - outside operational hours',
        );
      }
    });
    print(
      '[PROPOSAL_PROVIDER] 🔄 Started autonomous polling for proposals (every 60 seconds)',
    );
  }

  Future<void> fetchProposals() async {
    if (!isOperating) {
      print(
        '[PROPOSAL_PROVIDER] Blocked: AI operations not allowed (time, warp, or chaos state).',
      );
      notifyListeners();
      return;
    }
    print('[PROPOSAL_PROVIDER] 🔍 Fetching proposals from backend...');

    if (_useMockMode) {
      print(
        '[PROPOSAL_PROVIDER] 🎭 Using mock mode - creating sample proposals',
      );
      _createMockProposals();
      return;
    }

    // Check backend connectivity first
    final isHealthy = await checkBackendConnectivity();
    if (!isHealthy) {
      print('[PROPOSAL_PROVIDER] ⚠️ Backend not healthy, using mock mode');
      _createMockProposals();
      return;
    }

    // Limit to 10 proposals to prevent overwhelming the system
    final url = Uri.parse('$_backendUrl/api/proposals?limit=10');
    print('[PROPOSAL_PROVIDER] 📡 Making request to: $url');

    try {
      print('[PROPOSAL_PROVIDER] ⏳ Sending HTTP GET request...');
      final response = await http
          .get(url)
          .timeout(
            const Duration(seconds: 10),
            onTimeout: () {
              print('[PROPOSAL_PROVIDER] ⏰ Request timed out after 10 seconds');
              throw TimeoutException(
                'Request timed out',
                const Duration(seconds: 10),
              );
            },
          );
      print('[PROPOSAL_PROVIDER] 📥 Backend response received');
      print('[PROPOSAL_PROVIDER] 📊 Response status: ${response.statusCode}');
      print('[PROPOSAL_PROVIDER] 📄 Response headers: ${response.headers}');

      if (response.statusCode == 200) {
        print('[PROPOSAL_PROVIDER] ✅ Success response from backend');
        _handleBackendSuccess(); // Mark backend as available

        final responseBody = response.body;
        print(
          '[PROPOSAL_PROVIDER] 📝 Response body length: ${responseBody.length}',
        );
        print(
          '[PROPOSAL_PROVIDER] 📝 Response body preview: ${responseBody.substring(0, responseBody.length > 200 ? 200 : responseBody.length)}...',
        );

        final List data = jsonDecode(responseBody);
        print(
          '[PROPOSAL_PROVIDER] 📊 Parsed ${data.length} proposals from JSON',
        );

        if (data.isNotEmpty) {
          print('[PROPOSAL_PROVIDER] 📋 First proposal data: ${data.first}');
        }

        _proposals.clear();

        // Filter out proposals with null IDs and only show pending proposals
        final validProposals =
            data
                .where((json) {
                  final id = json['id']?.toString() ?? json['_id']?.toString();
                  final aiType =
                      json['ai_type']?.toString() ?? json['aiType']?.toString();
                  final status = json['status']?.toString();

                  if (id == null || aiType == null || status == null) {
                    print(
                      '[PROPOSAL_PROVIDER] ⚠️ Skipping invalid proposal: $json',
                    );
                    return false;
                  }

                  // Show pending and testing proposals - filter out accepted, rejected, etc.
                  if (status != 'pending' && status != 'testing') {
                    print(
                      '[PROPOSAL_PROVIDER] ⚠️ Skipping non-pending/testing proposal: $status',
                    );
                    return false;
                  }

                  return true;
                })
                .take(10)
                .toList();

        _proposals.addAll(
          validProposals.map((json) {
            print(
              '[PROPOSAL_PROVIDER] 🔄 Converting proposal: ${json['id'] ?? json['_id']} - ${json['ai_type'] ?? json['aiType']} - ${json['status']}',
            );
            return AIProposal.fromBackend(json);
          }),
        );

        final pendingCount =
            _proposals.where((p) => p.status == ProposalStatus.pending).length;
        final testingCount =
            _proposals.where((p) => p.status == ProposalStatus.testing).length;

        print('[PROPOSAL_PROVIDER] 📊 Final proposal counts:');
        print('[PROPOSAL_PROVIDER]   - Total: ${_proposals.length}');
        print('[PROPOSAL_PROVIDER]   - Pending: $pendingCount');
        print('[PROPOSAL_PROVIDER]   - Testing: $testingCount');

        notifyListeners();

        if (pendingCount > 0) {
          _showNotification(
            '📋 New AI Proposals',
            'You have $pendingCount new AI proposals to review',
            channelId: 'ai_proposals',
          );
        }
      } else {
        print(
          '[PROPOSAL_PROVIDER] ❌ Backend responded with error status: ${response.statusCode}',
        );
        print('[PROPOSAL_PROVIDER] 📄 Error response body: ${response.body}');
        _handleBackendFailure('HTTP ${response.statusCode}');
        _createMockProposals(); // Fallback to mock mode
      }
    } catch (error) {
      print(
        '[PROPOSAL_PROVIDER] ❌ Unexpected error fetching proposals: $error',
      );
      print('[PROPOSAL_PROVIDER] 🔍 Error type: ${error.runtimeType}');
      print('[PROPOSAL_PROVIDER] 📚 Error details: ${error.toString()}');
      _handleBackendFailure(error.toString());
      _bufferConnectionError(
        'Unexpected error: ${error.toString().substring(0, 50)}',
      );
      _createMockProposals(); // Fallback to mock mode
    }
  }

  Future<void> approveProposal(String id) async {
    if (!isOperating) {
      print(
        '[PROPOSAL_PROVIDER] Blocked: AI operations not allowed (time, warp, or chaos state).',
      );
      notifyListeners();
      return;
    }
    print('[PROPOSAL_PROVIDER] Approving proposal: $id');

    final proposalIndex = _proposals.indexWhere((p) => p.id == id);
    if (proposalIndex == -1) return;
    final proposal = _proposals[proposalIndex];

    // Optimistically remove proposal
    _proposals.removeAt(proposalIndex);
    notifyListeners();

    if (_useMockMode) {
      print('[PROPOSAL_PROVIDER] 🎭 Mock mode - approving proposal locally');
      // Show testing status first
      proposal.status = ProposalStatus.testing;
      _proposals.insert(proposalIndex, proposal);
      notifyListeners();

      _showNotification(
        '🔄 Mock Proposal Testing',
        'Proposal for ${proposal.filePath.split('/').last} is being tested (Mock Mode)',
        channelId: 'ai_proposals',
      );

      // Simulate testing delay
      await Future.delayed(const Duration(seconds: 3));

      // Remove proposal after testing (simulate success)
      _proposals.removeAt(proposalIndex);
      notifyListeners();

      _showNotification(
        '✅ Mock Proposal Approved',
        'Proposal for ${proposal.filePath.split('/').last} has been approved (Mock Mode)',
        channelId: 'ai_proposals',
      );
      return;
    }

    try {
      // First, show the proposal as testing
      proposal.status = ProposalStatus.testing;
      _proposals.insert(proposalIndex, proposal);
      notifyListeners();

      _showNotification(
        '🔄 Proposal Testing Started',
        'Proposal for ${proposal.filePath.split('/').last} is being tested...',
        channelId: 'ai_proposals',
      );

      // Wait a moment to show the testing status
      await Future.delayed(const Duration(seconds: 2));

      final url = Uri.parse('$_backendUrl/api/proposals/$id/accept');
      print('[PROPOSAL_PROVIDER] 📡 Approving proposal at: $url');

      final response = await http
          .post(
            url,
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode({
              'userFeedback': 'approved',
              'userFeedbackReason': 'User approved the proposal',
            }),
          )
          .timeout(const Duration(seconds: 15));

      print('[PROPOSAL_PROVIDER] 📥 Approval response: ${response.statusCode}');
      print('[PROPOSAL_PROVIDER] 📄 Response body: ${response.body}');

      if (response.statusCode == 200) {
        print('[PROPOSAL_PROVIDER] ✅ Proposal approved successfully');

        // Parse response to check test status
        final responseData = jsonDecode(response.body);
        final testStatus = responseData['test_status'];
        final testOutput = responseData['test_output'];
        final overallResult = responseData['overall_result'];

        if (overallResult == 'passed') {
          // Tests passed - remove proposal and show success
          print(
            '[PROPOSAL_PROVIDER] ✅ Tests passed - proposal applied successfully',
          );

          // Learn from the approval
          try {
            final learningProvider = Provider.of<AILearningProvider>(
              navigatorKey.currentContext!,
              listen: false,
            );
            await learningProvider.learnFromProposal(
              proposal,
              'approved',
              'User approved the proposal',
            );
            print('[PROPOSAL_PROVIDER] ✅ Learned from proposal approval');
          } catch (e) {
            print('[PROPOSAL_PROVIDER] ⚠️ Could not learn from approval: $e');
          }

          _showNotification(
            '✅ Proposal Applied Successfully',
            'Proposal has been approved and all tests passed',
            channelId: 'ai_proposals',
          );
        } else {
          // Tests failed - remove proposal and show failure
          print('[PROPOSAL_PROVIDER] ❌ Tests failed - proposal removed');
          _showNotification(
            '❌ Proposal Failed Testing',
            'Proposal was approved but failed testing and has been removed',
            channelId: 'ai_proposals',
          );
        }
      } else {
        // Restore proposal if backend call fails
        _proposals.insert(proposalIndex, proposal);
        notifyListeners();
        print(
          '[PROPOSAL_PROVIDER] ❌ Failed to approve proposal: ${response.statusCode}',
        );
        _showNotification(
          '❌ Approval Failed',
          'Backend returned status ${response.statusCode}',
          channelId: 'ai_proposals',
        );
      }
    } catch (e) {
      // Restore proposal if backend call fails
      _proposals.insert(proposalIndex, proposal);
      notifyListeners();
      print('[PROPOSAL_PROVIDER] ❌ Error approving proposal: $e');
      _showNotification(
        '❌ Approval Error',
        'Failed to approve proposal: ${e.toString().substring(0, 50)}...',
        channelId: 'ai_proposals',
      );
    }
  }

  Future<void> rejectProposal(String id) async {
    print('[PROPOSAL_PROVIDER] Rejecting proposal: $id');

    final proposalIndex = _proposals.indexWhere((p) => p.id == id);
    if (proposalIndex == -1) return;
    final proposal = _proposals[proposalIndex];

    // Optimistically remove proposal
    _proposals.removeAt(proposalIndex);
    notifyListeners();

    if (_useMockMode) {
      print('[PROPOSAL_PROVIDER] 🎭 Mock mode - rejecting proposal locally');
      proposal.status = ProposalStatus.rejected;
      _showNotification(
        '❌ Mock Proposal Rejected',
        'Proposal for ${proposal.filePath.split('/').last} has been rejected (Mock Mode)',
        channelId: 'ai_proposals',
      );
      return;
    }

    try {
      final url = Uri.parse('$_backendUrl/api/proposals/$id/reject');
      print('[PROPOSAL_PROVIDER] 📡 Rejecting proposal at: $url');

      final response = await http
          .post(
            url,
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode({
              'userFeedback': 'rejected',
              'userFeedbackReason': 'User rejected the proposal',
            }),
          )
          .timeout(const Duration(seconds: 15));

      print(
        '[PROPOSAL_PROVIDER] 📥 Rejection response: ${response.statusCode}',
      );
      print('[PROPOSAL_PROVIDER] 📄 Response body: ${response.body}');

      if (response.statusCode == 200) {
        print('[PROPOSAL_PROVIDER] ✅ Proposal rejected successfully');
        // Learn from the rejection
        try {
          final learningProvider = Provider.of<AILearningProvider>(
            navigatorKey.currentContext!,
            listen: false,
          );
          await learningProvider.learnFromProposal(
            proposal,
            'rejected',
            'User rejected the proposal',
          );
          print('[PROPOSAL_PROVIDER] ✅ Learned from proposal rejection');
        } catch (e) {
          print('[PROPOSAL_PROVIDER] ⚠️ Could not learn from rejection: $e');
        }
        _showNotification(
          '❌ Proposal Rejected',
          'Proposal has been rejected and removed',
          channelId: 'ai_proposals',
        );
      } else {
        // Restore proposal if backend call fails
        _proposals.insert(proposalIndex, proposal);
        notifyListeners();
        print(
          '[PROPOSAL_PROVIDER] ❌ Failed to reject proposal: ${response.statusCode}',
        );
        _showNotification(
          '❌ Rejection Failed',
          'Backend returned status ${response.statusCode}',
          channelId: 'ai_proposals',
        );
      }
    } catch (e) {
      // Restore proposal if backend call fails
      _proposals.insert(proposalIndex, proposal);
      notifyListeners();
      print('[PROPOSAL_PROVIDER] ❌ Error rejecting proposal: $e');
      _showNotification(
        '❌ Rejection Error',
        'Failed to reject proposal: ${e.toString().substring(0, 50)}...',
        channelId: 'ai_proposals',
      );
    }
  }

  Future<void> approveAllProposals() async {
    print('[PROPOSAL_PROVIDER] Approving all pending proposals');

    final pendingProposals =
        _proposals.where((p) => p.status == ProposalStatus.pending).toList();

    if (pendingProposals.isEmpty) {
      print('[PROPOSAL_PROVIDER] No pending proposals to approve');
      _showNotification(
        'ℹ️ No Pending Proposals',
        'There are no pending proposals to approve.',
        channelId: 'ai_proposals',
      );
      return;
    }

    print(
      '[PROPOSAL_PROVIDER] Found ${pendingProposals.length} pending proposals to approve',
    );

    if (_useMockMode) {
      print(
        '[PROPOSAL_PROVIDER] 🎭 Mock mode - approving all proposals locally',
      );

      // Show testing status for all proposals
      for (final proposal in pendingProposals) {
        proposal.status = ProposalStatus.testing;
      }
      notifyListeners();

      _showNotification(
        '🔄 Mock Proposals Testing',
        '${pendingProposals.length} proposals are being tested (Mock Mode)',
        channelId: 'ai_proposals',
      );

      // Simulate testing delay
      await Future.delayed(const Duration(seconds: 3));

      // Remove all proposals after testing (simulate success)
      _proposals.removeWhere((p) => p.status == ProposalStatus.testing);
      notifyListeners();

      _showNotification(
        '✅ All Mock Proposals Approved',
        '${pendingProposals.length} proposals have been approved (Mock Mode)',
        channelId: 'ai_proposals',
      );
      return;
    }

    // Show testing status for all proposals first
    for (final proposal in pendingProposals) {
      proposal.status = ProposalStatus.testing;
    }
    notifyListeners();

    _showNotification(
      '🔄 Bulk Testing Started',
      '${pendingProposals.length} proposals are being tested...',
      channelId: 'ai_proposals',
    );

    // Wait a moment to show testing status
    await Future.delayed(const Duration(seconds: 2));

    int successCount = 0;
    int failureCount = 0;

    for (final proposal in pendingProposals) {
      try {
        print('[PROPOSAL_PROVIDER] Approving proposal: ${proposal.id}');

        final url = Uri.parse(
          '$_backendUrl/api/proposals/${proposal.id}/accept',
        );
        final response = await http.post(
          url,
          headers: {'Content-Type': 'application/json'},
          body: jsonEncode({'feedbackReason': 'Approved via bulk approval'}),
        );

        if (response.statusCode == 200) {
          // Parse response to check test status
          final responseData = jsonDecode(response.body);
          final testStatus = responseData['test_status'];
          final testOutput = responseData['test_output'];

          if (testStatus == 'tested' && testOutput == 'All tests passed.') {
            successCount++;
            print(
              '[PROPOSAL_PROVIDER] ✅ Successfully approved proposal: ${proposal.id}',
            );
          } else {
            failureCount++;
            print(
              '[PROPOSAL_PROVIDER] ❌ Proposal failed testing: ${proposal.id}',
            );
          }
        } else {
          failureCount++;
          print(
            '[PROPOSAL_PROVIDER] ❌ Failed to approve proposal: ${proposal.id} - Status: ${response.statusCode}',
          );
        }
      } catch (error) {
        failureCount++;
        print(
          '[PROPOSAL_PROVIDER] ❌ Error approving proposal: ${proposal.id} - $error',
        );
      }
    }

    // Refresh proposals to get updated status
    await fetchProposals();

    // Show summary notification
    if (successCount > 0) {
      _showNotification(
        '✅ Bulk Approval Complete',
        'Successfully approved $successCount proposals${failureCount > 0 ? ', $failureCount failed' : ''}',
        channelId: 'ai_proposals',
      );
    } else {
      _showNotification(
        '❌ Bulk Approval Failed',
        'Failed to approve any proposals. Please try individual approvals.',
        channelId: 'ai_proposals',
      );
    }

    print(
      '[PROPOSAL_PROVIDER] Bulk approval complete: $successCount successful, $failureCount failed',
    );
  }

  void _initNotifications() {
    const AndroidInitializationSettings initializationSettingsAndroid =
        AndroidInitializationSettings('@mipmap/ic_launcher');
    final InitializationSettings initializationSettings =
        InitializationSettings(android: initializationSettingsAndroid);
    _notifications.initialize(initializationSettings);
    print('[PROPOSAL_PROVIDER] Notifications initialized');
  }

  void _showNotification(
    String title,
    String body, {
    String? channelId,
    int? id,
  }) {
    final notificationId = id ?? DateTime.now().millisecondsSinceEpoch % 100000;
    final channel = channelId ?? 'ai_processes';

    _notifications.show(
      notificationId,
      title,
      body,
      NotificationDetails(
        android: AndroidNotificationDetails(
          channel,
          'AI Processes',
          channelDescription: 'Notifications for AI proposal processing',
          importance: Importance.high,
          priority: Priority.high,
          showWhen: true,
          enableVibration: true,
          playSound: true,
          icon: '@mipmap/ic_launcher',
          color: const Color(0xFF2196F3),
          largeIcon: const DrawableResourceAndroidBitmap('@mipmap/ic_launcher'),
          styleInformation: BigTextStyleInformation(body),
        ),
      ),
    );
    print('[PROPOSAL_PROVIDER] 📱 Notification shown: $title - $body');
  }

  void _initSocket() {
    print('[PROPOSAL_PROVIDER] Initializing Socket.IO connection...');

    // Check backend connectivity first
    checkBackendConnectivity().then((isHealthy) {
      if (!isHealthy) {
        print(
          '[PROPOSAL_PROVIDER] ⚠️ Backend not healthy, delaying socket connection',
        );
        // Retry after 10 seconds
        Future.delayed(const Duration(seconds: 10), () {
          _initSocket();
        });
        return;
      }

      if (_socket != null) return; // Already connected

      print('[PROPOSAL_PROVIDER] Connecting to Socket.IO at: $_backendUrl');

      _socket = IO.io(_backendUrl, <String, dynamic>{
        'transports': ['websocket', 'polling'],
        'autoConnect': false, // Don't auto-connect, we'll connect manually
        'timeout': 30000, // Increase timeout to 30 seconds
        'forceNew': true,
        'reconnection': true,
        'reconnectionAttempts': 10, // Increase retry attempts
        'reconnectionDelay': 2000, // Increase delay between retries
        'reconnectionDelayMax': 10000, // Max delay between retries
      });

      _socket!.onConnect((_) async {
        print('[PROPOSAL_PROVIDER] ✅ Socket.IO connected to backend');
        await _notifyBackendConnected();
      });

      _socket!.onDisconnect((_) {
        print('[PROPOSAL_PROVIDER] ⚠️ Socket.IO disconnected from backend');
      });

      _socket!.onConnectError((error) {
        print('[PROPOSAL_PROVIDER] ❌ Socket.IO connection error: $error');
        // Don't show notification for every connection error to avoid spam
        // Only show if it's been a while since the last notification
        final now = DateTime.now().millisecondsSinceEpoch;
        if (now - _lastConnectionNotification > _fourHoursMs) {
          _showNotification(
            '❌ Backend Connection Failed',
            'Cannot connect to AI backend: $error',
            channelId: 'ai_processes',
          );
          _lastConnectionNotification = now;
        }
      });

      // Register all event handlers
      _registerSocketEventHandlers();

      // Connect manually after setting up handlers
      print('[PROPOSAL_PROVIDER] Socket.IO event handlers registered');
      _socket!.connect();
    });
  }

  void connect() {
    print('[PROPOSAL_PROVIDER] Connecting to Socket.IO backend...');
    _socket?.connect();
    _showNotification(
      '🔗 Connecting to AI Backend',
      'Establishing connection to AI system...',
      channelId: 'ai_processes',
      id: 0, // Use fixed ID for connection status
    );

    // Add retry logic for connection failures
    _socket?.onConnectError((error) {
      print('[PROPOSAL_PROVIDER] ❌ Socket.IO connection error: $error');
      _showNotification(
        '🔌 Connection Failed',
        'Failed to connect to AI backend. Retrying in 30 seconds...',
        channelId: 'ai_processes',
      );

      // Retry connection after 30 seconds
      Future.delayed(const Duration(seconds: 30), () {
        if (_socket != null && !_socket!.connected) {
          print('[PROPOSAL_PROVIDER] 🔄 Retrying Socket.IO connection...');
          _socket!.connect();
        }
      });
    });
  }

  @override
  void dispose() {
    _socket?.dispose();
    super.dispose();
  }

  // Check if backend is reachable
  Future<bool> checkBackendConnectivity() async {
    try {
      final url = Uri.parse('$_backendUrl/health');
      final response = await http
          .get(url)
          .timeout(
            const Duration(seconds: 5),
            onTimeout: () {
              throw TimeoutException(
                'Health check timed out',
                const Duration(seconds: 5),
              );
            },
          );

      if (response.statusCode == 200) {
        print('[PROPOSAL_PROVIDER] ✅ Backend is healthy and responding');
        _handleBackendSuccess();
        return true;
      } else {
        print(
          '[PROPOSAL_PROVIDER] ⚠️ Backend responded with status: ${response.statusCode}',
        );
        _handleBackendFailure('HTTP ${response.statusCode}');
        return false;
      }
    } catch (error) {
      print('[PROPOSAL_PROVIDER] ❌ Backend connectivity check failed: $error');
      _handleBackendFailure(error.toString());
      return false;
    }
  }

  /// Handle successful backend connection
  void _handleBackendSuccess() {
    _consecutiveFailures = 0;
    _isBackendAvailable = true;

    // Switch back to real mode if we were in mock mode
    if (_useMockMode) {
      print(
        '[PROPOSAL_PROVIDER] 🔄 Backend available - switching from mock to real mode',
      );
      _useMockMode = false;
      _isBackendAvailable = true;
      _showNotification(
        '✅ Backend Connected',
        'Switched to real mode - AI proposals will come from backend',
        channelId: 'ai_processes',
      );
    }
  }

  /// Handle backend connection failure
  void _handleBackendFailure(String error) {
    _consecutiveFailures++;
    print(
      '[PROPOSAL_PROVIDER] ❌ Backend failure #$_consecutiveFailures: $error',
    );

    if (_consecutiveFailures >= _maxFailures && !_useMockMode) {
      print(
        '[PROPOSAL_PROVIDER] 🔄 Too many failures - switching to mock mode',
      );
      _useMockMode = true;
      _isBackendAvailable = false;
      _showNotification(
        '🎭 Backend Unavailable',
        'Switched to mock mode - using local AI proposals',
        channelId: 'ai_processes',
      );
    }
  }

  /// Manual retry connection (public method)
  Future<void> retryConnection() async {
    print('[PROPOSAL_PROVIDER] 🔄 Manual retry requested');

    // Reset failure count for manual retry
    _consecutiveFailures = 0;

    // In retryConnection, remove all references to ChaosWarpProvider and chaos/warp state. Always attempt backend connection and fetch proposals.
    // Remove any logic or notifications about operational hours or chaos/warp.
    try {
      // Test backend connectivity
      final isHealthy = await checkBackendConnectivity();
      if (isHealthy) {
        print(
          '[PROPOSAL_PROVIDER] ✅ Backend is healthy - switching to real mode',
        );
        _useMockMode = false;
        _isBackendAvailable = true;

        // Fetch fresh proposals from backend
        await fetchProposals();

        _showNotification(
          '✅ Connection Restored',
          'Successfully connected to backend and switched to real mode',
          channelId: 'ai_processes',
        );
      } else {
        print(
          '[PROPOSAL_PROVIDER] ❌ Backend still unavailable - staying in mock mode',
        );
        _showNotification(
          '❌ Connection Failed',
          'Backend is still unavailable - staying in mock mode',
          channelId: 'ai_processes',
        );
      }
    } catch (e) {
      print('[PROPOSAL_PROVIDER] ❌ Error during retry connection: $e');
      _showNotification(
        '❌ Connection Error',
        'Failed to establish connection to backend: ${e.toString().substring(0, 50)}...',
        channelId: 'ai_processes',
      );
    }

    notifyListeners();
  }

  /// Force switch to real mode (for testing)
  void forceRealMode() {
    print('[PROPOSAL_PROVIDER] 🔧 Force switching to real mode');
    _useMockMode = false;
    _consecutiveFailures = 0;
    _isBackendAvailable = true;
    notifyListeners();

    _showNotification(
      '🔧 Forced Real Mode',
      'Manually switched to real mode for testing',
      channelId: 'ai_processes',
    );
  }

  /// Force switch to mock mode (for testing)
  void forceMockMode() {
    print('[PROPOSAL_PROVIDER] 🔧 Force switching to mock mode');
    _useMockMode = true;
    _isBackendAvailable = false;
    notifyListeners();

    _showNotification(
      '🔧 Forced Mock Mode',
      'Manually switched to mock mode for testing',
      channelId: 'ai_processes',
    );
  }

  Future<void> testBackendConnection() async {
    print('[PROPOSAL_PROVIDER] 🔍 Testing backend connection...');
    print(
      '[PROPOSAL_PROVIDER] 📊 Current mode: ${_useMockMode ? "Mock" : "Real"}',
    );
    print('[PROPOSAL_PROVIDER] 📊 Backend available: $_isBackendAvailable');
    print('[PROPOSAL_PROVIDER] 📊 Consecutive failures: $_consecutiveFailures');

    // Test health endpoint first
    try {
      final healthUrl = Uri.parse('$_backendUrl/health');
      print('[PROPOSAL_PROVIDER] 📡 Testing health endpoint: $healthUrl');

      final healthResponse = await http
          .get(healthUrl)
          .timeout(const Duration(seconds: 5));
      print(
        '[PROPOSAL_PROVIDER] ✅ Health endpoint response: ${healthResponse.statusCode}',
      );
      print(
        '[PROPOSAL_PROVIDER] 📄 Health response body: ${healthResponse.body}',
      );

      if (healthResponse.statusCode == 200) {
        _showNotification(
          '✅ Backend Connected',
          'Backend is running and accessible',
          channelId: 'ai_processes',
        );
      }
    } catch (e) {
      print('[PROPOSAL_PROVIDER] ❌ Health endpoint failed: $e');
      _showNotification(
        '❌ Backend Unreachable',
        'Cannot reach backend health endpoint: $e',
        channelId: 'ai_processes',
      );
      return;
    }

    // Test proposals endpoint
    try {
      final proposalsUrl = Uri.parse('$_backendUrl/api/proposals');
      print('[PROPOSAL_PROVIDER] 📡 Testing proposals endpoint: $proposalsUrl');

      final proposalsResponse = await http
          .get(proposalsUrl)
          .timeout(const Duration(seconds: 10));
      print(
        '[PROPOSAL_PROVIDER] 📊 Proposals endpoint response: ${proposalsResponse.statusCode}',
      );

      if (proposalsResponse.statusCode == 200) {
        final data = jsonDecode(proposalsResponse.body);
        print(
          '[PROPOSAL_PROVIDER] 📋 Found ${data.length} proposals in backend',
        );

        final pendingCount = data.where((p) => p['status'] == 'pending').length;
        final approvedCount =
            data.where((p) => p['status'] == 'approved').length;

        _showNotification(
          '📊 Backend Data',
          'Found ${data.length} total proposals ($pendingCount pending, $approvedCount approved)',
          channelId: 'ai_processes',
        );
      } else {
        print(
          '[PROPOSAL_PROVIDER] ❌ Proposals endpoint failed: ${proposalsResponse.statusCode}',
        );
        print(
          '[PROPOSAL_PROVIDER] 📄 Error response: ${proposalsResponse.body}',
        );
        _showNotification(
          '❌ Proposals Error',
          'Backend returned ${proposalsResponse.statusCode}',
          channelId: 'ai_processes',
        );
      }
    } catch (e) {
      print('[PROPOSAL_PROVIDER] ❌ Proposals endpoint failed: $e');
      _showNotification(
        '❌ Proposals Unreachable',
        'Cannot reach proposals endpoint: $e',
        channelId: 'ai_processes',
      );
    }
  }

  /// Get current connection status for UI
  Map<String, dynamic> getConnectionStatus() {
    return {
      'mode': _useMockMode ? 'Mock' : 'Real',
      'backendAvailable': _isBackendAvailable,
      'consecutiveFailures': _consecutiveFailures,
      'backendUrl': _backendUrl,
    };
  }

  // Get backend status for UI
  bool get isBackendConnected => _socket?.connected ?? false;

  Future<void> createTestProposal() async {
    print('[PROPOSAL_PROVIDER] 🧪 Creating test proposal...');

    if (_useMockMode) {
      print('[PROPOSAL_PROVIDER] 🎭 Mock mode - creating local test proposal');
      final testProposal = AIProposal(
        id: 'test-${DateTime.now().millisecondsSinceEpoch}',
        aiType: 'Test AI',
        filePath: 'lib/test_file.dart',
        oldCode: '// Old code\nvoid oldFunction() {\n  print("old");\n}',
        newCode: '// New code\nvoid newFunction() {\n  print("new");\n}',
        timestamp: DateTime.now(),
        status: ProposalStatus.pending,
      );

      _proposals.add(testProposal);
      notifyListeners();

      _showNotification(
        '✅ Test Proposal Created',
        'Created test proposal in mock mode',
        channelId: 'ai_proposals',
      );
      return;
    }

    // Create test proposal on backend
    try {
      final url = Uri.parse('$_backendUrl/api/proposals');
      final testData = {
        'aiType': 'Test AI',
        'filePath': 'lib/test_file.dart',
        'codeBefore': '// Old code\nvoid oldFunction() {\n  print("old");\n}',
        'codeAfter': '// New code\nvoid newFunction() {\n  print("new");\n}',
        'status': 'pending',
      };

      final response = await http
          .post(
            url,
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode(testData),
          )
          .timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        print('[PROPOSAL_PROVIDER] ✅ Test proposal created successfully');
        await fetchProposals(); // Refresh the list
        _showNotification(
          '✅ Test Proposal Created',
          'Test proposal created on backend',
          channelId: 'ai_proposals',
        );
      } else {
        print(
          '[PROPOSAL_PROVIDER] ❌ Failed to create test proposal: ${response.statusCode}',
        );
        _showNotification(
          '❌ Test Proposal Failed',
          'Backend returned ${response.statusCode}',
          channelId: 'ai_proposals',
        );
      }
    } catch (e) {
      print('[PROPOSAL_PROVIDER] ❌ Error creating test proposal: $e');
      _showNotification(
        '❌ Test Proposal Error',
        'Failed to create test proposal: $e',
        channelId: 'ai_proposals',
      );
    }
  }

  void _createMockProposals() {
    _proposals.clear();

    // Mock Imperium proposal
    _proposals.add(
      AIProposal(
        id: 'mock-1',
        aiType: 'Imperium',
        filePath: 'lib/main.dart',
        oldCode: '''void main() {
  runApp(MyApp());
}''',
        newCode: '''void main() {
  runApp(MyApp());
  // Added error handling and logging
  FlutterError.onError = (FlutterErrorDetails details) {
    FlutterError.presentError(details);
  };
}''',
        timestamp: DateTime.now().subtract(const Duration(hours: 2)),
        status: ProposalStatus.pending,
      ),
    );

    // Mock Sandbox proposal
    _proposals.add(
      AIProposal(
        id: 'mock-2',
        aiType: 'Sandbox',
        filePath: 'lib/mission.dart',
        oldCode: '''class Mission {
  String title;
  Mission(this.title);
}''',
        newCode: '''class Mission {
  String title;
  String? description;
  DateTime? dueDate;
  
  Mission(this.title, {this.description, this.dueDate});
  
  Map<String, dynamic> toJson() => {
    'title': title,
    'description': description,
    'dueDate': dueDate?.toIso8601String(),
  };
}''',
        timestamp: DateTime.now().subtract(const Duration(hours: 1)),
        status: ProposalStatus.pending,
      ),
    );

    // Mock Guardian proposal
    _proposals.add(
      AIProposal(
        id: 'mock-3',
        aiType: 'Guardian',
        filePath: 'lib/providers/proposal_provider.dart',
        oldCode: '''Future<void> fetchProposals() async {
  // Basic implementation
}''',
        newCode: '''Future<void> fetchProposals() async {
  try {
    // Enhanced implementation with error handling
    final response = await http.get(url);
    if (response.statusCode == 200) {
      // Process response
    } else {
      throw Exception('Failed to fetch proposals');
    }
  } catch (error) {
    print('Error: \$error');
    rethrow;
  }
}''',
        timestamp: DateTime.now().subtract(const Duration(minutes: 30)),
        status: ProposalStatus.pending,
      ),
    );

    // Mock approved proposal
    _proposals.add(
      AIProposal(
        id: 'mock-4',
        aiType: 'Imperium',
        filePath: 'lib/theme.dart',
        oldCode: '''ThemeData get lightTheme => ThemeData(
  primarySwatch: Colors.blue,
);''',
        newCode: '''ThemeData get lightTheme => ThemeData(
  primarySwatch: Colors.blue,
  brightness: Brightness.light,
  useMaterial3: true,
);''',
        timestamp: DateTime.now().subtract(const Duration(days: 1)),
        status: ProposalStatus.approved,
      ),
    );

    print('[PROPOSAL_PROVIDER] 🎭 Created ${_proposals.length} mock proposals');
    print('[PROPOSAL_PROVIDER] 📊 Mock proposal counts:');
    print('[PROPOSAL_PROVIDER]   - Total: ${_proposals.length}');
    print(
      '[PROPOSAL_PROVIDER]   - Pending: ${_proposals.where((p) => p.status == ProposalStatus.pending).length}',
    );
    print(
      '[PROPOSAL_PROVIDER]   - Approved: ${_proposals.where((p) => p.status == ProposalStatus.approved).length}',
    );

    notifyListeners();

    // Show notification for mock proposals
    final pendingCount =
        _proposals.where((p) => p.status == ProposalStatus.pending).length;
    if (pendingCount > 0) {
      _showNotification(
        '🎭 Mock Proposals Available',
        'You have $pendingCount mock AI proposals to review (Mock Mode)',
        channelId: 'ai_proposals',
      );
    }
  }

  /// Notify successful backend connection (once every 4 hours)
  Future<void> _notifyBackendConnected() async {
    final now = DateTime.now().millisecondsSinceEpoch;
    if (now - _lastConnectionNotification < _fourHoursMs) return;

    _lastConnectionNotification = now;
    String errorSummary = '';

    if (_connectionErrorBuffer.isNotEmpty) {
      errorSummary =
          '\n${_connectionErrorBuffer.length} connection errors/timeouts occurred in the last 4 hours.';
    }

    // Send notification to backend
    try {
      final response = await http.post(
        Uri.parse('$_backendUrl/api/notifications/send'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'title': 'Connected to AI Backend',
          'body': 'The app is connected to the backend.$errorSummary',
          'type': 'system',
          'userId': 'proposal-provider',
        }),
      );
      if (response.statusCode == 200) {
        print('[PROPOSAL_PROVIDER] ✅ Connection notification sent');
      }
    } catch (e) {
      print('[PROPOSAL_PROVIDER] Failed to send connection notification: $e');
    }

    // Clear error buffer after sending summary
    _connectionErrorBuffer.clear();
  }

  /// Buffer connection errors (don't send immediately)
  void _bufferConnectionError(String errorType) {
    _connectionErrorBuffer.add({
      'timestamp': DateTime.now().millisecondsSinceEpoch,
      'errorType': errorType,
    });
    print('[PROPOSAL_PROVIDER] Connection error buffered: $errorType');
  }

  /// Send oath paper to AI for learning
  Future<bool> sendOathPaperToAI(Map<String, dynamic> oathPaper) async {
    if (!isOperating) {
      print(
        '[PROPOSAL_PROVIDER] Blocked: AI operations not allowed (time, warp, or chaos state).',
      );
      return false;
    }

    print('[PROPOSAL_PROVIDER] 📜 Sending oath paper to AI for learning...');
    print('[PROPOSAL_PROVIDER] Subject: ${oathPaper['subject']}');
    print('[PROPOSAL_PROVIDER] Tags: ${oathPaper['tags']}');
    print(
      '[PROPOSAL_PROVIDER] Target AI: ${oathPaper['targetAI'] ?? 'All AIs'}',
    );
    print('[PROPOSAL_PROVIDER] AI Weights: ${oathPaper['aiWeights']}');

    if (_useMockMode) {
      print('[PROPOSAL_PROVIDER] 🎭 Mock mode - processing oath paper locally');

      // Create mock learning proposal
      final mockProposal = AIProposal(
        id: 'oath-${DateTime.now().millisecondsSinceEpoch}',
        aiType: oathPaper['targetAI'] ?? 'Imperium',
        filePath: 'oath_papers/${oathPaper['subject']}',
        oldCode: '',
        newCode: oathPaper['code'] ?? '',
        timestamp: DateTime.now(),
        status: ProposalStatus.pending,
        description: oathPaper['description'] ?? '',
        tags: oathPaper['tags'],
      );

      _proposals.add(mockProposal);
      notifyListeners();

      _showNotification(
        '📜 Oath Paper Received',
        'AI will learn from: ${oathPaper['subject']}',
        channelId: 'ai_proposals',
      );

      return true;
    }

    try {
      // Enhanced oath paper data with keyword extraction and learning instructions
      final enhancedOathPaper = {
        ...oathPaper,
        'learningMode': 'enhanced',
        'extractKeywords': true,
        'internetSearch': true,
        'gitIntegration': true,
        'learningInstructions': {
          'scanDescription': true,
          'scanCode': true,
          'extractKeywords': true,
          'searchInternet': true,
          'learnFromResults': true,
          'updateCapabilities': true,
          'pushToGit': true,
        },
        'timestamp': DateTime.now().toIso8601String(),
      };

      final url = Uri.parse('$_backendUrl/api/oath-papers/enhanced-learning');
      print('[PROPOSAL_PROVIDER] 📡 Sending enhanced oath paper to: $url');

      final response = await http
          .post(
            url,
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode(enhancedOathPaper),
          )
          .timeout(
            const Duration(seconds: 60),
          ); // Increased timeout for enhanced processing

      print(
        '[PROPOSAL_PROVIDER] 📥 Enhanced oath paper response: ${response.statusCode}',
      );

      if (response.statusCode == 200) {
        final result = jsonDecode(response.body);
        print(
          '[PROPOSAL_PROVIDER] ✅ Enhanced oath paper processed successfully',
        );
        print('[PROPOSAL_PROVIDER] Result: $result');

        // Show detailed notification with learning progress
        final learningProgress = result['learningProgress'] ?? {};
        final keywordsFound = learningProgress['keywordsFound'] ?? [];
        final internetSearches = learningProgress['internetSearches'] ?? [];
        final gitUpdates = learningProgress['gitUpdates'] ?? [];

        String notificationMessage =
            'AI learning from: ${oathPaper['subject']}';
        if (keywordsFound.isNotEmpty) {
          notificationMessage +=
              '\nKeywords: ${keywordsFound.take(3).join(', ')}';
        }
        if (internetSearches.isNotEmpty) {
          notificationMessage +=
              '\nSearched: ${internetSearches.length} sources';
        }
        if (gitUpdates.isNotEmpty) {
          notificationMessage += '\nGit: ${gitUpdates.length} updates';
        }

        _showNotification(
          '🧠 AI Learning Enhanced',
          notificationMessage,
          channelId: 'ai_proposals',
        );

        return true;
      } else {
        print(
          '[PROPOSAL_PROVIDER] ❌ Failed to process enhanced oath paper: ${response.statusCode}',
        );
        print('[PROPOSAL_PROVIDER] Error response: ${response.body}');

        // Fallback to basic processing
        return await _fallbackOathPaperProcessing(oathPaper);
      }
    } catch (e) {
      print('[PROPOSAL_PROVIDER] ❌ Error processing enhanced oath paper: $e');

      // Fallback to basic processing
      return await _fallbackOathPaperProcessing(oathPaper);
    }
  }

  /// Fallback processing for oath papers when enhanced processing fails
  Future<bool> _fallbackOathPaperProcessing(
    Map<String, dynamic> oathPaper,
  ) async {
    try {
      print(
        '[PROPOSAL_PROVIDER] 🔄 Attempting fallback oath paper processing...',
      );

      final url = Uri.parse('$_backendUrl/api/oath-papers');
      final response = await http
          .post(
            url,
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode(oathPaper),
          )
          .timeout(const Duration(seconds: 30));

      if (response.statusCode == 200) {
        print(
          '[PROPOSAL_PROVIDER] ✅ Fallback oath paper processing successful',
        );
        _showNotification(
          '📜 Oath Paper Processed (Basic)',
          'AI will learn from: ${oathPaper['subject']}',
          channelId: 'ai_proposals',
        );
        return true;
      } else {
        print(
          '[PROPOSAL_PROVIDER] ❌ Fallback processing also failed: ${response.statusCode}',
        );
        return false;
      }
    } catch (e) {
      print('[PROPOSAL_PROVIDER] ❌ Error in fallback processing: $e');
      return false;
    }
  }

  void _registerSocketEventHandlers() {
    _socket!.on('proposal:created', (data) {
      print('[PROPOSAL_PROVIDER] 📨 Received proposal:created event');
      fetchProposals();
      _showNotification(
        '📋 New Proposal',
        'A new AI proposal has been created',
        channelId: 'ai_proposals',
      );
    });

    _socket!.on('proposal:approved', (data) {
      print('[PROPOSAL_PROVIDER] 📨 Received proposal:approved event');
      fetchProposals();
      _showNotification(
        '✅ Proposal Approved',
        'A proposal has been approved on the backend',
        channelId: 'ai_proposals',
      );
    });

    _socket!.on('proposal:rejected', (data) {
      print('[PROPOSAL_PROVIDER] 📨 Received proposal:rejected event');
      fetchProposals();
      _showNotification(
        '❌ Proposal Rejected',
        'A proposal has been rejected on the backend',
        channelId: 'ai_proposals',
      );
    });

    _socket!.on('proposal:applied', (data) {
      print('[PROPOSAL_PROVIDER] 📨 Received proposal:applied event');
      print('[PROPOSAL_PROVIDER] Applied proposal data: $data');
      fetchProposals();
      _showNotification(
        '🔧 Proposal Applied',
        'A proposal has been applied to the codebase',
        channelId: 'ai_proposals',
      );
    });

    _socket!.on('proposal:test-started', (data) {
      print('[PROPOSAL_PROVIDER] 📨 Received proposal:test-started event');
      final filePath = data['filePath'] ?? 'unknown file';
      _showNotification(
        '🧪 Test Started',
        'Testing proposal for $filePath',
        channelId: 'ai_processes',
      );
    });

    _socket!.on('proposal:test-finished', (data) {
      print('[PROPOSAL_PROVIDER] 📨 Received proposal:test-finished event');
      print('[PROPOSAL_PROVIDER] Test finished data: $data');
      final filePath = data['filePath'] ?? 'unknown file';
      final result = data['result'] ?? 'unknown';
      _showNotification(
        '✅ Test Finished',
        'Test for $filePath: $result',
        channelId: 'ai_processes',
      );
    });

    _socket!.on('proposal:test-failed', (data) {
      print('[PROPOSAL_PROVIDER] 📨 Received proposal:test-failed event');
      print('[PROPOSAL_PROVIDER] Test failed data: $data');
      final filePath = data['filePath'] ?? 'unknown file';
      final error = data['error'] ?? 'unknown error';
      _showNotification(
        '❌ Test Failed',
        'Test for $filePath failed: $error',
        channelId: 'ai_processes',
      );
    });

    _socket!.on('apk:built', (data) {
      print('[PROPOSAL_PROVIDER] 📨 Received apk:built event');
      print('[PROPOSAL_PROVIDER] APK built data: $data');
      _showNotification(
        '📱 APK Built',
        'New APK has been built and is ready for testing',
        channelId: 'ai_processes',
      );
    });

    _socket!.on('ai:pull', (data) {
      print('[PROPOSAL_PROVIDER] 📨 Received ai:pull event');
      final ai = data['ai'] ?? 'AI';
      _showNotification(
        '📥 Code Pull',
        '$ai is pulling latest code from repository',
        channelId: 'ai_processes',
      );
    });

    _socket!.on('ai:experiment-start', (data) {
      print('[PROPOSAL_PROVIDER] 📨 Received ai:experiment-start event');
      final ai = data['ai'] ?? 'AI';
      _showNotification(
        '🧪 Experiment Started',
        '$ai has started a new learning experiment',
        channelId: 'ai_processes',
      );
    });

    _socket!.on('ai:experiment-complete', (data) {
      print('[PROPOSAL_PROVIDER] 📨 Received ai:experiment-complete event');
      final ai = data['ai'] ?? 'AI';
      _showNotification(
        '✅ Experiment Complete',
        '$ai has completed a learning experiment',
        channelId: 'ai_processes',
      );
    });

    _socket!.on('backend:startup', (data) {
      print('[PROPOSAL_PROVIDER] 📨 Received backend:startup event');
      final message = data['message'] ?? 'Backend is starting up...';
      _showNotification(
        '🚀 Backend Starting',
        message,
        channelId: 'ai_processes',
      );
    });

    _socket!.on('backend:code-pulled', (data) {
      print('[PROPOSAL_PROVIDER] 📨 Received backend:code-pulled event');
      final message = data['message'] ?? 'Code pulled successfully';
      _showNotification('📥 Code Updated', message, channelId: 'ai_processes');
    });

    _socket!.on('backend:scan-complete', (data) {
      print('[PROPOSAL_PROVIDER] 📨 Received backend:scan-complete event');
      final fileCount = data['fileCount'] ?? 0;
      _showNotification(
        '🔍 Scan Complete',
        'Code scan completed: $fileCount files analyzed',
        channelId: 'ai_processes',
      );
    });

    _socket!.on('ai:periodic-start', (data) {
      print('[PROPOSAL_PROVIDER] 📨 Received ai:periodic-start event');
      final ai = data['ai'] ?? 'AI';
      _showNotification(
        '🔄 Periodic Start',
        '$ai has started periodic processing',
        channelId: 'ai_processes',
      );
    });

    _socket!.on('ai:periodic-complete', (data) {
      print('[PROPOSAL_PROVIDER] 📨 Received ai:periodic-complete event');
      final ai = data['ai'] ?? 'AI';
      _showNotification(
        '✅ Periodic Complete',
        '$ai has completed periodic processing',
        channelId: 'ai_processes',
      );
    });

    _socket!.on('ai:periodic-error', (data) {
      print('[PROPOSAL_PROVIDER] 📨 Received ai:periodic-error event');
      final ai = data['ai'] ?? 'AI';
      final error = data['error'] ?? 'unknown error';
      _showNotification(
        '❌ Periodic Error',
        '$ai encountered an error: $error',
        channelId: 'ai_processes',
      );
    });

    _socket!.on('ai:learning-updated', (data) {
      print('[PROPOSAL_PROVIDER] 📨 Received ai:learning-updated event');
      print('[PROPOSAL_PROVIDER] Learning data: $data');
      _showNotification(
        '🧠 Learning Updated',
        'AI learning data has been updated',
        channelId: 'ai_processes',
      );
    });
  }

  Future<void> _initializeSocketConnection() async {
    print('[PROPOSAL_PROVIDER] 🔌 Initializing socket connection...');

    // For now, just log that we're initializing
    // In a real implementation, this would set up Socket.IO connection
    print('[PROPOSAL_PROVIDER] 🔌 Socket connection initialization complete');
  }

  List<AIProposal> get mockProposals =>
      _proposals.where((p) => !RegExp(r'^[a-f\d]{24}').hasMatch(p.id)).toList();
}
