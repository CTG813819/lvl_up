import 'dart:async';
import 'package:flutter/foundation.dart';
import '../services/notification_service.dart';
import '../config/android_config.dart';
import '../services/network_config.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:flutter/material.dart';

/// Autonomous AI Orchestrator
/// Manages all four AIs (Imperium, Guardian, Conquest, Sandbox) to run independently
/// within the terms set by the app and backend, optimized for Android
class AutonomousAIOrchestrator extends ChangeNotifier {
  static final AutonomousAIOrchestrator _instance =
      AutonomousAIOrchestrator._internal();
  factory AutonomousAIOrchestrator() => _instance;
  AutonomousAIOrchestrator._internal();

  // AI Status tracking
  final Map<String, AIStatus> _aiStatus = {
    'Imperium': AIStatus(),
    'Guardian': AIStatus(),
    'Conquest': AIStatus(),
    'Sandbox': AIStatus(),
  };

  // Operational parameters
  bool _isOrchestratorActive = false;
  Timer? _orchestrationTimer;
  Timer? _healthCheckTimer;
  Timer? _learningCycleTimer;
  Timer? _operationalHoursCheckTimer;

  // Backend connectivity
  String? _currentBackendUrl;
  bool _backendConnected = false;

  // Android-specific tracking
  int _activeBackgroundTasks = 0;
  DateTime? _lastMemoryCheck;

  // Stream controllers for real-time updates
  final StreamController<Map<String, AIStatus>> _aiStatusController =
      StreamController<Map<String, AIStatus>>.broadcast();
  final StreamController<String> _aiEventController =
      StreamController<String>.broadcast();
  final StreamController<Map<String, dynamic>> _orchestrationLogController =
      StreamController<Map<String, dynamic>>.broadcast();

  // Getters
  Map<String, AIStatus> get aiStatus => Map.unmodifiable(_aiStatus);
  bool get isOrchestratorActive => _isOrchestratorActive;
  bool get backendConnected => _backendConnected;
  String? get currentBackendUrl => _currentBackendUrl;
  int get activeBackgroundTasks => _activeBackgroundTasks;

  // Streams
  Stream<Map<String, AIStatus>> get aiStatusStream =>
      _aiStatusController.stream;
  Stream<String> get aiEventStream => _aiEventController.stream;
  Stream<Map<String, dynamic>> get orchestrationLogStream =>
      _orchestrationLogController.stream;

  /// Initialize the autonomous AI orchestrator
  Future<void> initialize() async {
    print(
      '[AUTONOMOUS_AI_ORCHESTRATOR] 🎼 Initializing autonomous AI orchestrator for Android...',
    );

    try {
      // Validate Android configuration
      if (!AndroidConfig.validateConfiguration()) {
        throw Exception('Android configuration validation failed');
      }

      // Test backend connectivity
      await _testBackendConnectivity();

      // Initialize all AIs with Android-optimized settings
      await _initializeAllAIs();

      // Start orchestration
      _startOrchestration();

      _logOrchestrationEvent(
        'Autonomous AI Orchestrator initialized successfully for Android',
      );
      print('[AUTONOMOUS_AI_ORCHESTRATOR] ✅ Initialization complete');
    } catch (e) {
      _logOrchestrationEvent('Initialization failed: $e', isError: true);
      print('[AUTONOMOUS_AI_ORCHESTRATOR] ❌ Initialization error: $e');
    }
  }

  /// Test backend connectivity and find working URL
  Future<void> _testBackendConnectivity() async {
    print(
      '[AUTONOMOUS_AI_ORCHESTRATOR] 🔍 Testing backend connectivity for Android...',
    );

    try {
      // Use NetworkConfig to get the best working backend URL
      final workingUrl = await NetworkConfig.getBestBackendUrl();

      if (workingUrl != null && workingUrl.isNotEmpty) {
        _currentBackendUrl = workingUrl;
        _backendConnected = true;
        print(
          '[AUTONOMOUS_AI_ORCHESTRATOR] ✅ Backend connected: $_currentBackendUrl',
        );

        // Test AI endpoints
        await _testAIEndpoints();
      } else {
        throw Exception('No working backend found');
      }
    } catch (e) {
      _backendConnected = false;
      print('[AUTONOMOUS_AI_ORCHESTRATOR] ❌ Backend connectivity failed: $e');
      _logOrchestrationEvent('Backend connectivity failed: $e', isError: true);
    }
  }

  /// Test AI-specific endpoints
  Future<void> _testAIEndpoints() async {
    if (_currentBackendUrl == null) return;

    final aiEndpoints = [
      '/api/ai/imperium/status',
      '/api/ai/guardian/status',
      '/api/ai/conquest/status',
      '/api/ai/sandbox/status',
    ];

    for (final endpoint in aiEndpoints) {
      try {
        final response = await http
            .get(Uri.parse('$_currentBackendUrl$endpoint'))
            .timeout(const Duration(seconds: 5));

        if (response.statusCode == 200) {
          print('[AUTONOMOUS_AI_ORCHESTRATOR] ✅ $endpoint accessible');
        } else {
          print(
            '[AUTONOMOUS_AI_ORCHESTRATOR] ⚠️ $endpoint returned ${response.statusCode}',
          );
        }
      } catch (e) {
        print('[AUTONOMOUS_AI_ORCHESTRATOR] ❌ $endpoint failed: $e');
      }
    }
  }

  /// Initialize all AIs with Android-optimized parameters
  Future<void> _initializeAllAIs() async {
    print(
      '[AUTONOMOUS_AI_ORCHESTRATOR] 🤖 Initializing all AIs for Android...',
    );

    final cycleIntervals = AndroidConfig.aiCycleIntervals;

    // Initialize Imperium (Meta-AI)
    await _initializeAI('Imperium', AIType.meta, cycleIntervals['Imperium']!);

    // Initialize Guardian (Security & Monitoring)
    await _initializeAI(
      'Guardian',
      AIType.security,
      cycleIntervals['Guardian']!,
    );

    // Initialize Conquest (App Building)
    await _initializeAI(
      'Conquest',
      AIType.builder,
      cycleIntervals['Conquest']!,
    );

    // Initialize Sandbox (Experimentation)
    await _initializeAI(
      'Sandbox',
      AIType.experimental,
      cycleIntervals['Sandbox']!,
    );

    print('[AUTONOMOUS_AI_ORCHESTRATOR] ✅ All AIs initialized for Android');
  }

  /// Initialize a specific AI with Android optimization
  Future<void> _initializeAI(
    String aiName,
    AIType type,
    Duration cycleInterval,
  ) async {
    print(
      '[AUTONOMOUS_AI_ORCHESTRATOR] 🤖 Initializing $aiName for Android...',
    );

    final status = _aiStatus[aiName]!;
    status.type = type;
    status.cycleInterval = cycleInterval;
    status.isInitialized = true;
    status.lastActivity = DateTime.now();

    // Set AI-specific operational parameters for Android
    switch (type) {
      case AIType.meta:
        status.maxConcurrentTasks = 2; // Reduced for Android
        status.priority = AIPriority.high;
        status.operationalHours = OperationalHours.always;
        break;
      case AIType.security:
        status.maxConcurrentTasks = 1; // Reduced for Android
        status.priority = AIPriority.critical;
        status.operationalHours = OperationalHours.always;
        break;
      case AIType.builder:
        status.maxConcurrentTasks = 1; // Reduced for Android
        status.priority = AIPriority.medium;
        status.operationalHours = OperationalHours.businessHours;
        break;
      case AIType.experimental:
        status.maxConcurrentTasks = 1; // Reduced for Android
        status.priority = AIPriority.low;
        status.operationalHours = OperationalHours.always;
        break;
    }

    // Log operational hours configuration
    final operationalHoursDesc = _getOperationalHoursDescription(
      status.operationalHours,
    );
    print(
      '[AUTONOMOUS_AI_ORCHESTRATOR] ⏰ $aiName operational hours: $operationalHoursDesc',
    );

    _notifyAIStatusUpdate();
    _logOrchestrationEvent(
      '$aiName initialized for Android (${type.name}) - $operationalHoursDesc',
    );
  }

  /// Get human-readable description of operational hours
  String _getOperationalHoursDescription(OperationalHours hours) {
    switch (hours) {
      case OperationalHours.always:
        return '24/7 operation';
      case OperationalHours.businessHours:
        return 'Business hours (5:00 AM - 9:00 PM)';
      case OperationalHours.nightHours:
        return 'Night hours (9:00 PM - 5:00 AM)';
    }
  }

  /// Start the orchestration system with Android optimization
  void _startOrchestration() {
    if (_isOrchestratorActive) return;

    _isOrchestratorActive = true;
    print(
      '[AUTONOMOUS_AI_ORCHESTRATOR] 🎼 Starting Android-optimized orchestration...',
    );

    // Main orchestration cycle (Android-optimized interval)
    _orchestrationTimer = Timer.periodic(AndroidConfig.aiCycleInterval, (_) {
      _runOrchestrationCycle();
    });

    // Health check cycle (Android-optimized interval)
    _healthCheckTimer = Timer.periodic(AndroidConfig.aiHealthCheckInterval, (
      _,
    ) {
      _runHealthCheck();
    });

    // Learning cycle (Android-optimized interval)
    _learningCycleTimer = Timer.periodic(AndroidConfig.aiLearningInterval, (_) {
      _runLearningCycle();
    });

    // Operational hours check cycle (every minute to ensure compliance)
    _operationalHoursCheckTimer = Timer.periodic(const Duration(minutes: 1), (
      _,
    ) {
      _checkOperationalHoursCompliance();
    });

    _logOrchestrationEvent('Android-optimized orchestration started');
  }

  /// Main orchestration cycle with Android resource management
  void _runOrchestrationCycle() {
    if (!_isOrchestratorActive) return;

    final now = DateTime.now();
    print(
      '[AUTONOMOUS_AI_ORCHESTRATOR] 🔄 Android orchestration cycle at ${now.toIso8601String()}',
    );

    // Check Android resource constraints
    if (_activeBackgroundTasks >= AndroidConfig.maxBackgroundTasks) {
      print(
        '[AUTONOMOUS_AI_ORCHESTRATOR] ⚠️ Maximum background tasks reached, skipping cycle',
      );
      return;
    }

    // Check each AI's status and trigger cycles if needed
    for (final entry in _aiStatus.entries) {
      final aiName = entry.key;
      final status = entry.value;

      if (!status.isInitialized) continue;

      // Check operational hours FIRST - before any other checks
      if (!status.isWithinOperationalHours()) {
        if (status.isActive) {
          _pauseAI(
            aiName,
            'Outside operational hours (${status.operationalHours.name})',
          );
        }
        print(
          '[AUTONOMOUS_AI_ORCHESTRATOR] ⏰ $aiName is outside operational hours, skipping cycle',
        );
        continue; // Skip this AI entirely if outside operational hours
      } else {
        // Resume AI if it was paused due to operational hours and now is within hours
        if (!status.isActive &&
            status.pauseReason?.contains('operational hours') == true) {
          _resumeAI(aiName);
          print(
            '[AUTONOMOUS_AI_ORCHESTRATOR] ✅ $aiName resumed - now within operational hours',
          );
        }
      }

      // Check if it's time for this AI to run its cycle
      if (status.shouldRunCycle()) {
        // Double-check operational hours before triggering
        if (status.isWithinOperationalHours()) {
          _triggerAICycle(aiName, status);
        } else {
          print(
            '[AUTONOMOUS_AI_ORCHESTRATOR] ⏰ $aiName cycle skipped - outside operational hours',
          );
        }
      }

      // Check resource constraints
      if (status.activeTasks >= status.maxConcurrentTasks) {
        print(
          '[AUTONOMOUS_AI_ORCHESTRATOR] ⚠️ $aiName at capacity (${status.activeTasks}/${status.maxConcurrentTasks}), skipping cycle',
        );
        continue; // Skip this cycle if at capacity
      }
    }

    _notifyAIStatusUpdate();
  }

  /// Trigger an AI cycle with Android optimization
  void _triggerAICycle(String aiName, AIStatus status) {
    print(
      '[AUTONOMOUS_AI_ORCHESTRATOR] 🚀 Triggering $aiName cycle for Android',
    );

    status.lastActivity = DateTime.now();
    status.activeTasks++;
    status.totalCycles++;
    _activeBackgroundTasks++;

    // Send cycle trigger to backend
    _sendAICycleTrigger(aiName, status);

    _notifyAIStatusUpdate();
    _logOrchestrationEvent('$aiName cycle triggered for Android');
  }

  /// Send AI cycle trigger to backend with Android timeout
  Future<void> _sendAICycleTrigger(String aiName, AIStatus status) async {
    if (_currentBackendUrl == null) return;

    try {
      final response = await http
          .post(
            Uri.parse(
              '$_currentBackendUrl/api/ai/${aiName.toLowerCase()}/cycle',
            ),
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode({
              'aiName': aiName,
              'timestamp': DateTime.now().toIso8601String(),
              'cycleNumber': status.totalCycles,
              'priority': status.priority.name,
              'platform': 'android',
            }),
          )
          .timeout(AndroidConfig.networkTimeout);

      if (response.statusCode == 200) {
        print(
          '[AUTONOMOUS_AI_ORCHESTRATOR] ✅ $aiName cycle triggered successfully',
        );
        status.lastSuccessfulCycle = DateTime.now();
        status.consecutiveErrors = 0;
      } else {
        print(
          '[AUTONOMOUS_AI_ORCHESTRATOR] ❌ $aiName cycle trigger failed: ${response.statusCode}',
        );
        status.lastError = 'Cycle trigger failed: ${response.statusCode}';
        status.consecutiveErrors++;
      }
    } catch (e) {
      print('[AUTONOMOUS_AI_ORCHESTRATOR] ❌ $aiName cycle trigger error: $e');
      status.lastError = 'Cycle trigger error: $e';
      status.consecutiveErrors++;
    }

    status.activeTasks--;
    _activeBackgroundTasks--;
    _notifyAIStatusUpdate();
  }

  /// Run health check for all AIs with Android monitoring
  void _runHealthCheck() {
    print('[AUTONOMOUS_AI_ORCHESTRATOR] 🏥 Running Android health check...');

    for (final entry in _aiStatus.entries) {
      final aiName = entry.key;
      final status = entry.value;

      // Check if AI is responsive
      final timeSinceLastActivity = DateTime.now().difference(
        status.lastActivity,
      );
      if (timeSinceLastActivity > const Duration(minutes: 5)) {
        status.health = AIHealth.degraded;
        _logOrchestrationEvent(
          '$aiName health degraded - no recent activity',
          isWarning: true,
        );
      } else {
        status.health = AIHealth.healthy;
      }

      // Check for repeated errors
      if (status.consecutiveErrors > AndroidConfig.maxRetries) {
        status.health = AIHealth.critical;
        _pauseAI(aiName, 'Too many consecutive errors');
        _logOrchestrationEvent(
          '$aiName paused due to consecutive errors',
          isError: true,
        );
      }

      // Check operational hours compliance
      if (status.isActive && !status.isWithinOperationalHours()) {
        _pauseAI(
          aiName,
          'Outside operational hours - health check enforcement',
        );
        _logOrchestrationEvent(
          '$aiName paused during health check - outside operational hours',
          isWarning: true,
        );
      }
    }

    // Verify all AIs are respecting operational hours
    if (areAllAIsRespectingOperationalHours()) {
      print(
        '[AUTONOMOUS_AI_ORCHESTRATOR] ✅ All AIs are respecting operational hours',
      );
    } else {
      print(
        '[AUTONOMOUS_AI_ORCHESTRATOR] ⚠️ Some AIs are not respecting operational hours',
      );
    }

    // Check Android-specific constraints
    _checkAndroidConstraints();

    _notifyAIStatusUpdate();
  }

  /// Check Android-specific constraints
  void _checkAndroidConstraints() {
    final now = DateTime.now();

    // Check memory usage (simplified check)
    if (_lastMemoryCheck == null ||
        now.difference(_lastMemoryCheck!) > const Duration(minutes: 5)) {
      _lastMemoryCheck = now;

      // Check if we're approaching memory limits
      if (_activeBackgroundTasks > AndroidConfig.maxBackgroundTasks * 0.8) {
        _logOrchestrationEvent(
          'Approaching Android memory limits',
          isWarning: true,
        );
      }
    }
  }

  /// Run learning cycle for AIs to share knowledge
  void _runLearningCycle() {
    print('[AUTONOMOUS_AI_ORCHESTRATOR] 🧠 Running Android learning cycle...');

    // Trigger cross-AI learning
    _triggerCrossAILearning();

    _logOrchestrationEvent('Android learning cycle completed');
  }

  /// Trigger cross-AI learning with Android optimization
  Future<void> _triggerCrossAILearning() async {
    if (_currentBackendUrl == null) return;

    try {
      final response = await http
          .post(
            Uri.parse('$_currentBackendUrl/api/ai/learning/cross-ai'),
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode({
              'timestamp': DateTime.now().toIso8601String(),
              'participatingAIs': _aiStatus.keys.toList(),
              'platform': 'android',
            }),
          )
          .timeout(AndroidConfig.networkTimeout);

      if (response.statusCode == 200) {
        print(
          '[AUTONOMOUS_AI_ORCHESTRATOR] ✅ Cross-AI learning triggered for Android',
        );
      } else {
        print(
          '[AUTONOMOUS_AI_ORCHESTRATOR] ❌ Cross-AI learning failed: ${response.statusCode}',
        );
      }
    } catch (e) {
      print('[AUTONOMOUS_AI_ORCHESTRATOR] ❌ Cross-AI learning error: $e');
    }
  }

  /// Pause an AI
  void _pauseAI(String aiName, String reason) {
    final status = _aiStatus[aiName]!;
    status.isActive = false;
    status.pauseReason = reason;
    status.pausedAt = DateTime.now();

    _notifyAIStatusUpdate();
    _logOrchestrationEvent('$aiName paused: $reason', isWarning: true);
  }

  /// Resume an AI
  void _resumeAI(String aiName) {
    final status = _aiStatus[aiName]!;
    status.isActive = true;
    status.pauseReason = null;
    status.pausedAt = null;

    _notifyAIStatusUpdate();
    _logOrchestrationEvent('$aiName resumed');
  }

  /// Notify listeners of AI status updates
  void _notifyAIStatusUpdate() {
    _aiStatusController.add(_aiStatus);
    notifyListeners();
  }

  /// Log orchestration events with Android context
  void _logOrchestrationEvent(
    String message, {
    bool isError = false,
    bool isWarning = false,
  }) {
    final logEntry = {
      'timestamp': DateTime.now().toIso8601String(),
      'message': message,
      'level': isError ? 'error' : (isWarning ? 'warning' : 'info'),
      'platform': 'android',
      'activeBackgroundTasks': _activeBackgroundTasks,
    };

    _orchestrationLogController.add(logEntry);

    // Show notification for important events
    if (isError || isWarning) {
      NotificationService.instance.showNotification(
        aiSource: 'AI Orchestrator',
        message: message,
        iconChar: isError ? '❌' : '⚠️',
      );
    }
  }

  /// Get AI status by name
  AIStatus? getAIStatus(String aiName) {
    return _aiStatus[aiName];
  }

  /// Get operational status for all AIs
  Map<String, Map<String, dynamic>> getOperationalStatus() {
    final now = DateTime.now();
    final status = <String, Map<String, dynamic>>{};

    for (final entry in _aiStatus.entries) {
      final aiName = entry.key;
      final aiStatus = entry.value;

      status[aiName] = {
        'isActive': aiStatus.isActive,
        'isWithinOperationalHours': aiStatus.isWithinOperationalHours(),
        'operationalHours': aiStatus.operationalHours.name,
        'currentTime':
            '${now.hour.toString().padLeft(2, '0')}:${now.minute.toString().padLeft(2, '0')}',
        'pauseReason': aiStatus.pauseReason,
        'health': aiStatus.health.name,
        'totalCycles': aiStatus.totalCycles,
        'lastActivity': aiStatus.lastActivity.toIso8601String(),
      };
    }

    return status;
  }

  /// Check if all AIs are respecting operational hours
  bool areAllAIsRespectingOperationalHours() {
    for (final entry in _aiStatus.entries) {
      final aiName = entry.key;
      final status = entry.value;

      // If AI is active but outside operational hours, it's not respecting them
      if (status.isActive && !status.isWithinOperationalHours()) {
        print(
          '[AUTONOMOUS_AI_ORCHESTRATOR] ❌ $aiName is active but outside operational hours',
        );
        return false;
      }
    }
    return true;
  }

  /// Force trigger an AI cycle
  Future<void> forceTriggerAICycle(String aiName) async {
    final status = _aiStatus[aiName];
    if (status == null) {
      print('[AUTONOMOUS_AI_ORCHESTRATOR] ❌ AI $aiName not found');
      return;
    }

    print('[AUTONOMOUS_AI_ORCHESTRATOR] 🔧 Force triggering $aiName cycle');
    _triggerAICycle(aiName, status);
  }

  /// Stop the orchestrator
  void stop() {
    _isOrchestratorActive = false;
    _orchestrationTimer?.cancel();
    _healthCheckTimer?.cancel();
    _learningCycleTimer?.cancel();
    _operationalHoursCheckTimer?.cancel();

    _logOrchestrationEvent('Android orchestrator stopped');
    print('[AUTONOMOUS_AI_ORCHESTRATOR] 🛑 Android orchestrator stopped');
  }

  /// Force check and enforce operational hours for all AIs
  void enforceOperationalHours() {
    print(
      '[AUTONOMOUS_AI_ORCHESTRATOR] 🔍 Enforcing operational hours for all AIs...',
    );

    for (final entry in _aiStatus.entries) {
      final aiName = entry.key;
      final status = entry.value;

      if (!status.isInitialized) continue;

      if (status.isWithinOperationalHours()) {
        // Resume AI if it was paused due to operational hours
        if (!status.isActive &&
            status.pauseReason?.contains('operational hours') == true) {
          _resumeAI(aiName);
          print(
            '[AUTONOMOUS_AI_ORCHESTRATOR] ✅ $aiName resumed - now within operational hours',
          );
        }
      } else {
        // Pause AI if it's outside operational hours
        if (status.isActive) {
          _pauseAI(aiName, 'Outside operational hours - enforcement check');
          print(
            '[AUTONOMOUS_AI_ORCHESTRATOR] ⏰ $aiName paused - outside operational hours',
          );
        }
      }
    }

    _notifyAIStatusUpdate();
    _logOrchestrationEvent('Operational hours enforcement completed');
  }

  /// Check operational hours compliance for all AIs
  void _checkOperationalHoursCompliance() {
    if (!_isOrchestratorActive) return;

    final now = DateTime.now();
    final currentTime =
        '${now.hour.toString().padLeft(2, '0')}:${now.minute.toString().padLeft(2, '0')}';

    print(
      '[AUTONOMOUS_AI_ORCHESTRATOR] ⏰ Checking operational hours compliance at $currentTime...',
    );

    for (final entry in _aiStatus.entries) {
      final aiName = entry.key;
      final status = entry.value;

      if (!status.isInitialized) continue;

      if (status.isWithinOperationalHours()) {
        // Resume AI if it was paused due to operational hours
        if (!status.isActive &&
            status.pauseReason?.contains('operational hours') == true) {
          _resumeAI(aiName);
          print(
            '[AUTONOMOUS_AI_ORCHESTRATOR] ✅ $aiName resumed at $currentTime - now within operational hours',
          );
        }
      } else {
        // Pause AI if it's outside operational hours
        if (status.isActive) {
          _pauseAI(
            aiName,
            'Outside operational hours - periodic check at $currentTime',
          );
          print(
            '[AUTONOMOUS_AI_ORCHESTRATOR] ⏰ $aiName paused at $currentTime - outside operational hours',
          );
        }
      }
    }
  }

  @override
  void dispose() {
    stop();
    _aiStatusController.close();
    _aiEventController.close();
    _orchestrationLogController.close();
    super.dispose();
  }
}

/// AI Status class to track individual AI state
class AIStatus {
  AIType type = AIType.experimental;
  bool isInitialized = false;
  bool isActive = true;
  AIHealth health = AIHealth.healthy;
  AIPriority priority = AIPriority.medium;
  OperationalHours operationalHours = OperationalHours.always;

  DateTime lastActivity = DateTime.now();
  DateTime? lastSuccessfulCycle;
  DateTime? pausedAt;
  String? pauseReason;
  String? lastError;

  int activeTasks = 0;
  int maxConcurrentTasks = 1;
  int totalCycles = 0;
  int consecutiveErrors = 0;

  Duration cycleInterval = const Duration(seconds: 30);

  bool shouldRunCycle() {
    if (!isActive || !isInitialized) return false;

    final timeSinceLastActivity = DateTime.now().difference(lastActivity);
    return timeSinceLastActivity >= cycleInterval;
  }

  bool isWithinOperationalHours() {
    final now = DateTime.now();
    final hour = now.hour;
    final minute = now.minute;
    final currentTime =
        '${hour.toString().padLeft(2, '0')}:${minute.toString().padLeft(2, '0')}';

    switch (operationalHours) {
      case OperationalHours.always:
        return true;
      case OperationalHours.businessHours:
        // Business hours: 5:00 AM to 11:30 PM (23:30)
        final isBusinessHours =
            hour >= 5 && (hour < 23 || (hour == 23 && minute <= 30));
        if (!isBusinessHours) {
          print(
            '[AI_STATUS] ⏰ Current time: $currentTime - Outside business hours (5:00-23:30)',
          );
        }
        return isBusinessHours;
      case OperationalHours.nightHours:
        // Night hours: 11:30 PM (23:30) to 5:00 AM (05:00)
        final isNightHours = (hour >= 23 && minute > 30) || hour < 5;
        if (!isNightHours) {
          print(
            '[AI_STATUS] ⏰ Current time: $currentTime - Outside night hours (23:30-05:00)',
          );
        }
        return isNightHours;
    }
  }
}

/// AI Types
enum AIType {
  meta, // Imperium - Meta-AI that improves other AIs
  security, // Guardian - Security and monitoring
  builder, // Conquest - App building and development
  experimental, // Sandbox - Experimentation and testing
}

/// AI Health Status
enum AIHealth { healthy, degraded, critical }

/// AI Priority Levels
enum AIPriority {
  critical, // Guardian
  high, // Imperium
  medium, // Conquest
  low, // Sandbox
}

/// Operational Hours
enum OperationalHours {
  always, // 24/7 operation
  businessHours, // 5 AM - 11:30 PM
  nightHours, // 11:30 PM - 5 AM
}
