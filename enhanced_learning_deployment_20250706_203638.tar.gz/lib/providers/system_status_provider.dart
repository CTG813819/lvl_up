import 'dart:async';
import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import '../services/notification_service.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../providers/proposal_provider.dart';

// System status enums - moved to top level
enum SystemHealth { healthy, warning, critical, offline, unknown }

enum BackendStatus { connected, disconnected, error, unknown }

enum AILearningStatus { active, idle, error, disabled }

enum NotificationStatus { enabled, disabled, error }

/// System Status Provider
/// Manages real-time system health monitoring, backend connectivity, AI learning status,
/// and provides status indicators for the app bar
class SystemStatusProvider extends ChangeNotifier {
  static const String _statusStorageKey = 'system_status_data';

  // Configuration
  static const bool _enableHealthChecks =
      true; // Enabled for real health checks
  static const Duration _healthCheckTimeout = Duration(
    seconds: 2,
  ); // Very short timeout
  static const Duration _healthCheckInterval = Duration(
    hours: 1,
  ); // Run every hour

  // Current status
  SystemHealth _systemHealth = SystemHealth.unknown;
  BackendStatus _backendStatus = BackendStatus.unknown;
  AILearningStatus _aiLearningStatus = AILearningStatus.idle;
  NotificationStatus _notificationStatus = NotificationStatus.enabled;

  // Status details
  Map<String, dynamic> _statusDetails = {};
  List<Map<String, dynamic>> _statusHistory = [];
  List<Map<String, dynamic>> _errorLog = [];

  // Health check endpoints
  final List<String> _healthCheckEndpoints = [
    'http://34.202.215.209:4000/api/health',
    'http://34.202.215.209:4000/api/proposals/ai-status',
    'http://34.202.215.209:4000/api/learning/data',
  ];

  // Timers for periodic checks
  Timer? _healthCheckTimer;
  Timer? _statusUpdateTimer;

  // Stream controllers for real-time updates
  final StreamController<Map<String, dynamic>> _statusUpdateController =
      StreamController<Map<String, dynamic>>.broadcast();
  final StreamController<String> _errorController =
      StreamController<String>.broadcast();

  // Getters
  SystemHealth get systemHealth => _systemHealth;
  BackendStatus get backendStatus => _backendStatus;
  AILearningStatus get aiLearningStatus => _aiLearningStatus;
  NotificationStatus get notificationStatus => _notificationStatus;
  Map<String, dynamic> get statusDetails => Map.unmodifiable(_statusDetails);
  List<Map<String, dynamic>> get statusHistory =>
      List.unmodifiable(_statusHistory);
  List<Map<String, dynamic>> get errorLog => List.unmodifiable(_errorLog);

  // Streams
  Stream<Map<String, dynamic>> get statusUpdateStream =>
      _statusUpdateController.stream;
  Stream<String> get errorStream => _errorController.stream;

  // Status indicators for UI
  bool get isSystemHealthy => _systemHealth == SystemHealth.healthy;
  bool get isBackendConnected => _backendStatus == BackendStatus.connected;
  bool get isAILearningActive => _aiLearningStatus == AILearningStatus.active;
  bool get hasErrors => _errorLog.isNotEmpty;

  // Status icons and colors
  IconData get statusIcon {
    switch (_systemHealth) {
      case SystemHealth.healthy:
        return Icons.check_circle;
      case SystemHealth.warning:
        return Icons.warning;
      case SystemHealth.critical:
        return Icons.error;
      case SystemHealth.offline:
        return Icons.cloud_off;
      default:
        return Icons.help;
    }
  }

  Color get statusColor {
    switch (_systemHealth) {
      case SystemHealth.healthy:
        return Colors.green;
      case SystemHealth.warning:
        return Colors.orange;
      case SystemHealth.critical:
        return Colors.red;
      case SystemHealth.offline:
        return Colors.grey;
      default:
        return Colors.grey;
    }
  }

  String get statusMessage {
    if (_systemHealth == SystemHealth.offline) {
      return 'System Offline';
    } else if (_backendStatus == BackendStatus.disconnected) {
      return 'Backend Disconnected';
    } else if (_aiLearningStatus == AILearningStatus.error) {
      return 'AI Learning Error';
    } else if (_systemHealth == SystemHealth.healthy) {
      return 'System Healthy';
    } else {
      return 'System Warning';
    }
  }

  SystemStatusProvider() {
    _initialize();
  }

  /// Initialize the system status provider
  Future<void> _initialize() async {
    print('[SYSTEM_STATUS_PROVIDER] 🔧 Initializing system status provider...');

    await _loadStatusData();

    // Start periodic health checks immediately, but don't block on initial check
    _startPeriodicHealthChecks();
    _startStatusUpdates();

    // Perform initial health check in background (non-blocking) only if enabled
    if (_enableHealthChecks) {
      _performInitialHealthCheck().catchError((e) {
        print(
          '[SYSTEM_STATUS_PROVIDER] ⚠️ Initial health check failed (non-critical): $e',
        );
      });
    }

    print('[SYSTEM_STATUS_PROVIDER] ✅ System status provider initialized');
  }

  /// Load status data from local storage
  Future<void> _loadStatusData() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final statusJson = prefs.getString(_statusStorageKey);

      if (statusJson != null) {
        final data = jsonDecode(statusJson) as Map<String, dynamic>;
        _statusHistory = List<Map<String, dynamic>>.from(data['history'] ?? []);
        _errorLog = List<Map<String, dynamic>>.from(data['errors'] ?? []);
        print(
          '[SYSTEM_STATUS_PROVIDER] 📚 Loaded status history: ${_statusHistory.length} entries',
        );
      }
    } catch (e) {
      print('[SYSTEM_STATUS_PROVIDER] ❌ Error loading status data: $e');
    }
  }

  /// Save status data to local storage
  Future<void> _saveStatusData() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final data = {
        'history': _statusHistory,
        'errors': _errorLog,
        'lastUpdated': DateTime.now().toIso8601String(),
      };
      await prefs.setString(_statusStorageKey, jsonEncode(data));
    } catch (e) {
      print('[SYSTEM_STATUS_PROVIDER] ❌ Error saving status data: $e');
    }
  }

  /// Perform initial health check
  Future<void> _performInitialHealthCheck() async {
    print('[SYSTEM_STATUS_PROVIDER] 🔍 Performing initial health check...');
    await _checkBackendHealth();
    await _checkAILearningStatus();
    await _checkNotificationStatus();
    _updateSystemHealth();
    notifyListeners();
  }

  /// Start periodic health checks
  void _startPeriodicHealthChecks() {
    if (!_enableHealthChecks) {
      return;
    }

    _healthCheckTimer?.cancel();
    _healthCheckTimer = Timer.periodic(_healthCheckInterval, (_) {
      _performHealthCheck().catchError((e) {
        // Silent fail - don't log periodic health check errors
      });
    });
    print(
      '[SYSTEM_STATUS_PROVIDER] 🔄 Health checks enabled (every ${_healthCheckInterval.inHours} hour(s))',
    );
  }

  /// Start status updates
  void _startStatusUpdates() {
    _statusUpdateTimer?.cancel();
    _statusUpdateTimer = Timer.periodic(const Duration(seconds: 5), (_) {
      _updateStatusDetails();
    });
  }

  /// Perform comprehensive health check - lightweight and quiet
  Future<void> _performHealthCheck() async {
    try {
      await _checkBackendHealth();
      await _checkAILearningStatus();
      await _checkNotificationStatus();
      _updateSystemHealth();

      // Add to history
      _addStatusHistory();

      // Notify listeners
      notifyListeners();

      // Send status update
      _statusUpdateController.add({
        'timestamp': DateTime.now().toIso8601String(),
        'systemHealth': _systemHealth.toString(),
        'backendStatus': _backendStatus.toString(),
        'aiLearningStatus': _aiLearningStatus.toString(),
        'notificationStatus': _notificationStatus.toString(),
      });
    } catch (e) {
      // Silent fail - don't log health check errors
    }
  }

  /// Check backend health - lightweight ping check
  Future<void> _checkBackendHealth() async {
    try {
      bool anyEndpointWorking = false;
      int workingEndpoints = 0;

      for (String endpoint in _healthCheckEndpoints) {
        try {
          final response = await http
              .get(
                Uri.parse(endpoint),
                headers: {
                  'Content-Type': 'application/json',
                  'User-Agent': 'LVL_UP_Flutter_App',
                },
              )
              .timeout(_healthCheckTimeout);

          if (response.statusCode == 200) {
            anyEndpointWorking = true;
            workingEndpoints++;
          }
        } catch (e) {
          // Silent fail - don't log every ping failure
        }
      }

      if (anyEndpointWorking) {
        _backendStatus = BackendStatus.connected;
        _statusDetails['backend'] = {
          'status': 'connected',
          'workingEndpoints': workingEndpoints,
          'totalEndpoints': _healthCheckEndpoints.length,
          'lastCheck': DateTime.now().toIso8601String(),
        };
      } else {
        _backendStatus = BackendStatus.disconnected;
        _statusDetails['backend'] = {
          'status': 'disconnected',
          'lastCheck': DateTime.now().toIso8601String(),
        };
      }
    } catch (e) {
      _backendStatus = BackendStatus.error;
      _statusDetails['backend'] = {
        'status': 'error',
        'lastCheck': DateTime.now().toIso8601String(),
      };
    }
  }

  /// Check AI learning status - lightweight ping check
  Future<void> _checkAILearningStatus() async {
    try {
      final response = await http
          .get(
            Uri.parse('http://34.202.215.209:4000/api/proposals/ai-status'),
            headers: {
              'Content-Type': 'application/json',
              'User-Agent': 'LVL_UP_Flutter_App',
            },
          )
          .timeout(_healthCheckTimeout);

      if (response.statusCode == 200) {
        _aiLearningStatus = AILearningStatus.active;
        _statusDetails['aiLearning'] = {
          'status': 'active',
          'lastCheck': DateTime.now().toIso8601String(),
        };
      } else {
        _aiLearningStatus = AILearningStatus.idle;
        _statusDetails['aiLearning'] = {
          'status': 'idle',
          'lastCheck': DateTime.now().toIso8601String(),
        };
      }
    } catch (e) {
      _aiLearningStatus = AILearningStatus.idle;
      _statusDetails['aiLearning'] = {
        'status': 'idle',
        'lastCheck': DateTime.now().toIso8601String(),
      };
    }
  }

  /// Check notification status
  Future<void> _checkNotificationStatus() async {
    try {
      // Check if notification service is available
      final notificationStatus = 'Available'; // Simplified check
      _notificationStatus = notificationStatus as NotificationStatus;
      notifyListeners();
    } catch (e) {
      print('[SYSTEM_STATUS_PROVIDER] Error checking notification status: $e');
      _notificationStatus = 'Error' as NotificationStatus;
      notifyListeners();
    }
  }

  /// Update system health based on all statuses
  void _updateSystemHealth() {
    // If all elements are connected and live, set healthy
    if (_backendStatus == BackendStatus.connected &&
        _aiLearningStatus == AILearningStatus.active &&
        _notificationStatus == NotificationStatus.enabled) {
      _systemHealth = SystemHealth.healthy;
    } else if (_backendStatus == BackendStatus.disconnected ||
        _aiLearningStatus == AILearningStatus.error ||
        _notificationStatus == NotificationStatus.error) {
      _systemHealth = SystemHealth.critical;
    } else if (_backendStatus == BackendStatus.unknown ||
        _aiLearningStatus == AILearningStatus.idle) {
      _systemHealth = SystemHealth.warning;
    } else {
      _systemHealth = SystemHealth.offline;
    }
  }

  /// Update status details
  void _updateStatusDetails() {
    _statusDetails['system'] = {
      'health': _systemHealth.toString(),
      'lastUpdate': DateTime.now().toIso8601String(),
      'uptime': DateTime.now().difference(DateTime.now()).inSeconds,
    };
  }

  /// Add status to history
  void _addStatusHistory() {
    final statusEntry = {
      'timestamp': DateTime.now().toIso8601String(),
      'systemHealth': _systemHealth.toString(),
      'backendStatus': _backendStatus.toString(),
      'aiLearningStatus': _aiLearningStatus.toString(),
      'notificationStatus': _notificationStatus.toString(),
    };

    _statusHistory.add(statusEntry);

    // Keep only last 100 entries
    if (_statusHistory.length > 100) {
      _statusHistory = _statusHistory.take(100).toList();
    }

    _saveStatusData();
  }

  /// Add error to log
  void _addError(String title, String message) {
    final errorEntry = {
      'timestamp': DateTime.now().toIso8601String(),
      'title': title,
      'message': message,
      'severity': 'error',
    };

    _errorLog.add(errorEntry);

    // Keep only last 50 errors
    if (_errorLog.length > 50) {
      _errorLog = _errorLog.take(50).toList();
    }

    // Send error notification
    _errorController.add('$title: $message');

    // Show notification
    NotificationService.instance.showNotification(
      aiSource: 'System',
      message: '$title: $message',
      iconChar: '⚠️',
    );

    _saveStatusData();
  }

  /// Manual health check (public method)
  Future<void> performHealthCheck() async {
    await _performHealthCheck();
  }

  /// Reset system (safety mechanism)
  Future<void> resetSystem() async {
    print('[SYSTEM_STATUS_PROVIDER] 🔄 Resetting system...');

    // Clear error log
    _errorLog.clear();

    // Reset statuses
    _systemHealth = SystemHealth.unknown;
    _backendStatus = BackendStatus.unknown;
    _aiLearningStatus = AILearningStatus.idle;
    _notificationStatus = NotificationStatus.enabled;

    // Perform fresh health check
    await _performInitialHealthCheck();

    // Show reset notification
    NotificationService.instance.showNotification(
      aiSource: 'System',
      message: 'System has been reset and is performing health checks',
      iconChar: '🔄',
    );

    notifyListeners();
  }

  /// Clear error log
  void clearErrorLog() {
    _errorLog.clear();
    _saveStatusData();
    notifyListeners();
  }

  /// Get system summary
  Map<String, dynamic> getSystemSummary() {
    return {
      'systemHealth': _systemHealth.toString(),
      'backendStatus': _backendStatus.toString(),
      'aiLearningStatus': _aiLearningStatus.toString(),
      'notificationStatus': _notificationStatus.toString(),
      'errorCount': _errorLog.length,
      'lastCheck': _statusDetails['system']?['lastUpdate'] ?? 'Never',
    };
  }

  @override
  void dispose() {
    _healthCheckTimer?.cancel();
    _statusUpdateTimer?.cancel();
    _statusUpdateController.close();
    _errorController.close();
    super.dispose();
  }
}
