import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/conquest_app.dart';
import '../services/conquest_ai_service.dart';
import 'dart:async';
import 'package:http/http.dart' as http;
import 'dart:convert';
import '../services/network_config.dart';

/// Conquest AI Provider
/// Manages state for the Conquest AI app building feature
class ConquestAIProvider extends ChangeNotifier {
  final ConquestAIService _conquestService = ConquestAIService();

  List<ConquestApp> _currentApps = [];
  List<ConquestApp> _completedApps = [];
  List<ConquestApp> _deployments = []; // Add deployments list
  Map<String, dynamic> _conquestStatus = {};
  bool _isLoading = false;
  String? _error;
  List<Map<String, dynamic>> _debugLogs = [];
  List<Map<String, dynamic>> _errorLearnings = [];

  // Getters
  List<ConquestApp> get currentApps => _currentApps;
  List<ConquestApp> get completedApps => _completedApps;
  List<ConquestApp> get deployments => _deployments; // Add deployments getter
  Map<String, dynamic> get conquestStatus => _conquestStatus;
  bool get isLoading => _isLoading;
  String? get error => _error;
  List<Map<String, dynamic>> get debugLogs => _debugLogs;
  bool get isConquestActive => _conquestStatus['isActive'] ?? false;
  List<Map<String, dynamic>> get errorLearnings => _errorLearnings;

  /// Get the current app in progress (first one, if any)
  ConquestApp? get currentApp =>
      getInProgressApps.isNotEmpty ? getInProgressApps.first : null;

  /// Get progress logs for user display (filtered from debug logs)
  List<String> get progressLogs {
    return _debugLogs
        .where(
          (log) =>
              log['type'] == 'progress' ||
              log['message']?.toString().contains('progress') == true,
        )
        .map((log) => log['message']?.toString() ?? 'Unknown progress')
        .toList();
  }

  /// Get notifications for user display
  List<String> get notifications {
    return _debugLogs
        .where(
          (log) =>
              log['type'] == 'notification' ||
              log['message']?.toString().contains('notification') == true,
        )
        .map((log) => log['message']?.toString() ?? 'Unknown notification')
        .toList();
  }

  /// Get guardrails and health information
  Map<String, dynamic> get guardrails {
    return {
      'healthChecks': {
        'backend_connected':
            _conquestStatus['healthChecks']?['backend_connected'] ?? false,
        'learning_active':
            _conquestStatus['healthChecks']?['learning_active'] ?? false,
        'git_available':
            _conquestStatus['healthChecks']?['git_available'] ?? false,
        'tests_running':
            _conquestStatus['healthChecks']?['tests_running'] ?? false,
      },
      'maxBuildTime': _conquestStatus['maxBuildTime'] ?? 300,
      'maxRetries': _conquestStatus['maxRetries'] ?? 3,
    };
  }

  /// Initialize the Conquest AI provider
  Future<void> initialize() async {
    print('[CONQUEST_AI_PROVIDER] 🐉 Initializing Conquest AI provider...');
    _setLoading(true);

    try {
      await _conquestService.initialize();

      // Listen to streams
      _conquestService.appsUpdateStream.listen((apps) {
        _currentApps = apps;
        notifyListeners();
      });

      _conquestService.conquestUpdateStream.listen((status) {
        _conquestStatus = status;
        notifyListeners();
      });

      _conquestService.debugOutputStream.listen((logEntry) {
        _debugLogs.add(logEntry);
        // Keep only last 50 debug logs
        if (_debugLogs.length > 50) {
          _debugLogs = _debugLogs.take(50).toList();
        }
        notifyListeners();
      });

      // Load initial data
      await _loadInitialData();

      // Start periodic tasks
      _startPeriodicTasks();

      await fetchErrorLearnings();

      _setError(null);
      print('[CONQUEST_AI_PROVIDER] ✅ Conquest AI provider initialized');
    } catch (e) {
      _setError('Failed to initialize Conquest AI: $e');
      print('[CONQUEST_AI_PROVIDER] ❌ Error initializing: $e');
    } finally {
      _setLoading(false);
    }
  }

  /// Start periodic tasks for Conquest AI
  void _startPeriodicTasks() {
    // Learn from other AIs every 5 minutes
    Timer.periodic(const Duration(minutes: 5), (timer) async {
      try {
        await _conquestService.learnFromOtherAIs();
        print('[CONQUEST_AI_PROVIDER] 🔄 Periodic learning completed');
      } catch (e) {
        print('[CONQUEST_AI_PROVIDER] ❌ Periodic learning error: $e');
      }
    });

    // Check operational hours every minute
    Timer.periodic(const Duration(minutes: 1), (timer) async {
      try {
        final isOperational = await _conquestService.checkOperationalHours();
        print(
          '[CONQUEST_AI_PROVIDER] 🔄 Operational hours check completed - isOperational: $isOperational',
        );

        // Update the status to reflect current operational state
        _conquestStatus = _conquestService.getConquestStatus();
        notifyListeners();
      } catch (e) {
        print('[CONQUEST_AI_PROVIDER] ❌ Operational hours check error: $e');
      }
    });

    // Poll progress logs every 5 seconds (non-blocking)
    Timer.periodic(const Duration(seconds: 5), (timer) async {
      try {
        await _conquestService.fetchProgressLogsFromBackend();
      } catch (e) {
        print(
          '[CONQUEST_AI_PROVIDER] ℹ️ Progress log polling failed (non-critical): $e',
        );
      }
    });

    // Refresh deployments every 30 seconds
    Timer.periodic(const Duration(seconds: 30), (timer) async {
      try {
        await fetchDeployments();
      } catch (e) {
        print(
          '[CONQUEST_AI_PROVIDER] ℹ️ Deployment refresh failed (non-critical): $e',
        );
      }
    });

    print('[CONQUEST_AI_PROVIDER] 🔄 Periodic tasks started');
  }

  /// Load initial data
  Future<void> _loadInitialData() async {
    try {
      _currentApps = _conquestService.getCurrentApps();
      _completedApps = _conquestService.getCompletedApps();
      _conquestStatus = _conquestService.getConquestStatus();

      // Fetch deployments from backend
      await fetchDeployments();

      notifyListeners();
    } catch (e) {
      print('[CONQUEST_AI_PROVIDER] ❌ Error loading initial data: $e');
      // Reset to empty lists if there's an error
      _currentApps = [];
      _completedApps = [];
      _deployments = [];
      _conquestStatus = {
        'isActive': false,
        'operationalHours': {'start': '05:00', 'end': '23:30'},
        'totalAppsBuilt': 0,
        'successRate': 0.0,
        'lastActive': null,
      };
      notifyListeners();
    }
  }

  /// Create a new app suggestion
  Future<ConquestApp?> createAppSuggestion({
    required String name,
    required String description,
    required String keywords,
  }) async {
    print('[CONQUEST_AI_PROVIDER] 🚀 Creating app suggestion: $name');
    _setLoading(true);
    _setError(null);

    try {
      final app = await _conquestService.createAppSuggestion(
        name: name,
        description: description,
        keywords: keywords,
      );

      print('[CONQUEST_AI_PROVIDER] ✅ App suggestion created: ${app.name}');
      return app;
    } catch (e) {
      _setError('Failed to create app suggestion: $e');
      print('[CONQUEST_AI_PROVIDER] ❌ Error creating app suggestion: $e');
      return null;
    } finally {
      _setLoading(false);
    }
  }

  /// Get app by ID
  ConquestApp? getAppById(String id) {
    final currentApp = _currentApps.where((app) => app.id == id).firstOrNull;
    if (currentApp != null) return currentApp;

    final completedApp =
        _completedApps.where((app) => app.id == id).firstOrNull;
    return completedApp;
  }

  /// Get apps by status
  List<ConquestApp> getAppsByStatus(String status) {
    return _deployments.where((app) => app.status == status).toList();
  }

  /// Get apps in progress
  List<ConquestApp> get getInProgressApps {
    return getAppsByStatus('in_progress');
  }

  /// Get pending apps
  List<ConquestApp> get getPendingApps {
    return getAppsByStatus('pending');
  }

  /// Get completed apps
  List<ConquestApp> get getCompletedApps {
    return getAppsByStatus('completed');
  }

  /// Get failed apps
  List<ConquestApp> get getFailedApps {
    return getAppsByStatus('failed');
  }

  /// Get tested apps (apps with test status)
  List<ConquestApp> get getTestedApps {
    return _deployments
        .where((app) => app.testStatus != null && app.testStatus!.isNotEmpty)
        .toList();
  }

  /// Get apps that passed tests
  List<ConquestApp> get getTestedPassedApps {
    return _deployments
        .where(
          (app) => app.testStatus == 'passed' || app.testStatus == 'success',
        )
        .toList();
  }

  /// Get apps that failed tests
  List<ConquestApp> get getTestedFailedApps {
    return _deployments
        .where(
          (app) => app.testStatus == 'failed' || app.testStatus == 'failure',
        )
        .toList();
  }

  /// Get total apps count
  int get totalAppsCount {
    return _deployments.length;
  }

  /// Get success rate
  double get successRate {
    final totalCompleted = getCompletedApps.length;
    final totalFailed = getFailedApps.length;
    final total = totalCompleted + totalFailed;

    if (total == 0) return 0.0;
    return totalCompleted / total;
  }

  /// Get test success rate
  double get testSuccessRate {
    final totalTested = getTestedApps.length;
    final totalTestedPassed = getTestedPassedApps.length;

    if (totalTested == 0) return 0.0;
    return totalTestedPassed / totalTested;
  }

  /// Get comprehensive statistics
  Map<String, dynamic> get comprehensiveStats {
    return {
      'totalApps': totalAppsCount,
      'pendingApps': getPendingApps.length,
      'completedApps': getCompletedApps.length,
      'failedApps': getFailedApps.length,
      'inProgressApps': getInProgressApps.length,
      'testedApps': getTestedApps.length,
      'testedPassedApps': getTestedPassedApps.length,
      'testedFailedApps': getTestedFailedApps.length,
      'testingApps':
          _deployments
              .where((app) => app.status.toLowerCase() == 'testing')
              .length,
      'successRate': successRate,
      'testSuccessRate': testSuccessRate,
      'averageBuildTime': averageBuildTime.inMinutes,
      'lastUpdated': DateTime.now().toIso8601String(),
    };
  }

  /// Enhanced statistics including learning data and validation progress
  Map<String, dynamic>? _enhancedStats;
  Map<String, dynamic>? get enhancedStats => _enhancedStats;

  /// Fetch enhanced statistics from backend
  Future<void> fetchEnhancedStatistics() async {
    try {
      final result = await _conquestService.getEnhancedStatistics();
      if (result['status'] == 'success') {
        _enhancedStats = result['statistics'];
        notifyListeners();
      } else {
        print(
          '[CONQUEST_AI_PROVIDER] ❌ Failed to fetch enhanced statistics: ${result['message']}',
        );
      }
    } catch (e) {
      print('[CONQUEST_AI_PROVIDER] ❌ Error fetching enhanced statistics: $e');
    }
  }

  /// Get average build time
  Duration get averageBuildTime {
    final completedApps = getCompletedApps;
    if (completedApps.isEmpty) return Duration.zero;

    final totalDuration = completedApps.fold<Duration>(Duration.zero, (
      total,
      app,
    ) {
      if (app.updatedAt != null && app.status == 'completed') {
        return total + app.updatedAt!.difference(app.createdAt);
      }
      return total;
    });

    return Duration(
      milliseconds: totalDuration.inMilliseconds ~/ completedApps.length,
    );
  }

  /// Refresh Conquest AI status
  Future<void> refreshStatus() async {
    _setLoading(true);

    try {
      await _loadInitialData();
      _setError(null);
    } catch (e) {
      _setError('Failed to refresh status: $e');
    } finally {
      _setLoading(false);
    }
  }

  /// Clear debug logs
  void clearDebugLogs() {
    _debugLogs.clear();
    notifyListeners();
  }

  /// Export Conquest AI data
  Future<Map<String, dynamic>> exportData() async {
    return {
      'currentApps': _currentApps.map((app) => app.toJson()).toList(),
      'completedApps': _completedApps.map((app) => app.toJson()).toList(),
      'conquestStatus': _conquestStatus,
      'debugLogs': _debugLogs,
      'exportedAt': DateTime.now().toIso8601String(),
    };
  }

  /// Import Conquest AI data
  Future<void> importData(Map<String, dynamic> data) async {
    _setLoading(true);

    try {
      if (data['currentApps'] != null) {
        _currentApps =
            (data['currentApps'] as List)
                .map((appJson) => ConquestApp.fromJson(appJson))
                .toList();
      }

      if (data['completedApps'] != null) {
        _completedApps =
            (data['completedApps'] as List)
                .map((appJson) => ConquestApp.fromJson(appJson))
                .toList();
      }

      if (data['conquestStatus'] != null) {
        _conquestStatus = Map<String, dynamic>.from(data['conquestStatus']);
      }

      if (data['debugLogs'] != null) {
        _debugLogs =
            (data['debugLogs'] as List)
                .map((log) => Map<String, dynamic>.from(log))
                .toList();
      }

      notifyListeners();
      _setError(null);
    } catch (e) {
      _setError('Failed to import data: $e');
    } finally {
      _setLoading(false);
    }
  }

  /// Set loading state
  void _setLoading(bool loading) {
    _isLoading = loading;
    notifyListeners();
  }

  /// Set error state
  void _setError(String? error) {
    _error = error;
    notifyListeners();
  }

  /// Clear error
  void clearError() {
    _setError(null);
  }

  /// Resume any interrupted app builds
  Future<void> resumeInterruptedBuilds() async {
    print('[CONQUEST_AI_PROVIDER] 🔄 Checking for interrupted builds...');

    try {
      final inProgressApps = getInProgressApps;

      if (inProgressApps.isNotEmpty) {
        print(
          '[CONQUEST_AI_PROVIDER] 🔄 Found ${inProgressApps.length} interrupted builds, resuming...',
        );

        for (final app in inProgressApps) {
          print('[CONQUEST_AI_PROVIDER] 🔄 Resuming build for: ${app.name}');
          // The service will handle the actual resumption logic
          // For now, we just log that we found interrupted builds
        }

        // Notify listeners that we're resuming builds
        notifyListeners();
      } else {
        print('[CONQUEST_AI_PROVIDER] ✅ No interrupted builds found');
      }
    } catch (e) {
      print('[CONQUEST_AI_PROVIDER] ❌ Error resuming interrupted builds: $e');
      _setError('Failed to resume interrupted builds: $e');
    }
  }

  /// Force refresh operational hours from backend or reset to defaults
  Future<void> forceRefreshOperationalHours() async {
    print('[CONQUEST_AI_PROVIDER] 🔄 Forcing refresh of operational hours...');

    try {
      _setLoading(true);

      // Force refresh operational hours in the service
      await _conquestService.forceRefreshOperationalHours();

      // Reload the conquest status to get updated operational hours
      await _loadInitialData();

      print('[CONQUEST_AI_PROVIDER] ✅ Operational hours refreshed');
      _setError(null);
    } catch (e) {
      print('[CONQUEST_AI_PROVIDER] ❌ Error refreshing operational hours: $e');
      _setError('Failed to refresh operational hours: $e');
    } finally {
      _setLoading(false);
    }
  }

  /// Clear cached data and force refresh (for debugging)
  Future<void> clearCacheAndRefresh() async {
    print('[CONQUEST_AI_PROVIDER] 🧹 Clearing cache and forcing refresh...');

    try {
      _setLoading(true);

      // Clear SharedPreferences cache
      final prefs = await SharedPreferences.getInstance();
      await prefs.remove('conquest_ai_data');

      // Force refresh operational hours in the service
      await _conquestService.forceRefreshOperationalHours();

      // Reload the conquest status to get updated operational hours
      await _loadInitialData();

      print(
        '[CONQUEST_AI_PROVIDER] ✅ Cache cleared and operational hours refreshed',
      );
      _setError(null);
    } catch (e) {
      print('[CONQUEST_AI_PROVIDER] ❌ Error clearing cache: $e');
      _setError('Failed to clear cache: $e');
    } finally {
      _setLoading(false);
    }
  }

  /// Clear notifications
  void clearNotifications() {
    print('[CONQUEST_AI_PROVIDER] 🧹 Clearing notifications...');

    // Remove notification-type logs from debug logs
    _debugLogs.removeWhere(
      (log) =>
          log['type'] == 'notification' ||
          log['message']?.toString().contains('notification') == true,
    );

    notifyListeners();
    print('[CONQUEST_AI_PROVIDER] ✅ Notifications cleared');
  }

  /// Force Conquest AI to work on a specific app
  Future<void> forceConquestWork(String appId) async {
    print(
      '[CONQUEST_AI_PROVIDER] 🚀 Forcing Conquest AI to work on app: $appId',
    );
    try {
      _setLoading(true);
      final response = await http.post(
        Uri.parse('${NetworkConfig.backendUrl}/api/conquest/force-work'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'appId': appId}),
      );
      if (response.statusCode == 200) {
        print('[CONQUEST_AI_PROVIDER] ✅ Retry triggered for app: $appId');
        await refreshStatus();
      } else {
        print('[CONQUEST_AI_PROVIDER] ❌ Retry failed: ${response.body}');
        _setError('Retry failed: ${response.body}');
      }
    } catch (e) {
      print('[CONQUEST_AI_PROVIDER] ❌ Error forcing Conquest work: $e');
      _setError('Failed to force Conquest work: $e');
    } finally {
      _setLoading(false);
    }
  }

  /// Clear progress logs
  void clearProgressLogs() {
    print('[CONQUEST_AI_PROVIDER] 🧹 Clearing progress logs...');

    // Remove progress-type logs from debug logs
    _debugLogs.removeWhere(
      (log) =>
          log['type'] == 'progress' ||
          log['message']?.toString().contains('progress') == true,
    );

    notifyListeners();
    print('[CONQUEST_AI_PROVIDER] ✅ Progress logs cleared');
  }

  /// Get recent apps with optional limit
  List<ConquestApp> getRecentApps({int limit = 10}) {
    final allApps = [..._currentApps, ..._completedApps];

    // Sort by creation date (newest first)
    allApps.sort((a, b) => b.createdAt.compareTo(a.createdAt));

    // Return limited number of apps
    return allApps.take(limit).toList();
  }

  /// Submit an app request to Conquest AI
  Future<bool> submitAppRequest({
    required String name,
    required String description,
    required List<String> keywords,
    String operationType = 'create_new',
    String? existingRepo,
    String? improvementFocus,
  }) async {
    print(
      '[CONQUEST_AI_PROVIDER] 📝 Submitting app request: $name (type: $operationType)',
    );

    try {
      if (operationType == 'create_new') {
        final app = await createAppSuggestion(
          name: name,
          description: description,
          keywords: keywords.join(', '),
        );

        if (app != null) {
          print(
            '[CONQUEST_AI_PROVIDER] ✅ New app request submitted successfully: ${app.name}',
          );
          return true;
        } else {
          print(
            '[CONQUEST_AI_PROVIDER] ❌ Failed to submit new app request: $name',
          );
          return false;
        }
      } else {
        // Improve existing app
        final success = await _improveExistingApp(
          name: name,
          description: description,
          keywords: keywords,
          existingRepo: existingRepo!,
          improvementFocus: improvementFocus!,
        );

        if (success) {
          print(
            '[CONQUEST_AI_PROVIDER] ✅ App improvement request submitted successfully: $name',
          );
          return true;
        } else {
          print(
            '[CONQUEST_AI_PROVIDER] ❌ Failed to submit app improvement request: $name',
          );
          return false;
        }
      }
    } catch (e) {
      print('[CONQUEST_AI_PROVIDER] ❌ Error submitting app request: $e');
      _setError('Failed to submit app request: $e');
      return false;
    }
  }

  /// Improve an existing app
  Future<bool> _improveExistingApp({
    required String name,
    required String description,
    required List<String> keywords,
    required String existingRepo,
    required String improvementFocus,
  }) async {
    print('[CONQUEST_AI_PROVIDER] 🔧 Improving existing app: $name');

    try {
      final response = await http.post(
        Uri.parse('${NetworkConfig.backendUrl}/api/conquest/improve-app'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'name': name,
          'description': description,
          'keywords': keywords,
          'operation_type': 'improve_existing',
          'existing_repo': existingRepo,
          'improvement_focus': improvementFocus,
        }),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        print(
          '[CONQUEST_AI_PROVIDER] ✅ App improvement started: ${data['message']}',
        );
        return true;
      } else {
        print(
          '[CONQUEST_AI_PROVIDER] ❌ App improvement failed: ${response.body}',
        );
        _setError('App improvement failed: ${response.body}');
        return false;
      }
    } catch (e) {
      print('[CONQUEST_AI_PROVIDER] ❌ Error improving app: $e');
      _setError('Failed to improve app: $e');
      return false;
    }
  }

  /// Dispose resources
  @override
  void dispose() {
    _conquestService.dispose();
    super.dispose();
  }

  Future<void> fetchErrorLearnings() async {
    try {
      final response = await http
          .get(
            Uri.parse(
              '${NetworkConfig.backendUrl}/api/conquest/error-learnings',
            ),
            headers: {'Content-Type': 'application/json'},
          )
          .timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['status'] == 'success' && data['learnings'] != null) {
          _errorLearnings = List<Map<String, dynamic>>.from(data['learnings']);
          print(
            '[CONQUEST_AI_PROVIDER] ✅ Fetched ${_errorLearnings.length} error learnings',
          );
        } else {
          print('[CONQUEST_AI_PROVIDER] ⚠️ No error learnings found');
          _errorLearnings = [];
        }
        notifyListeners();
      } else {
        print(
          '[CONQUEST_AI_PROVIDER] ❌ Failed to fetch error learnings: ${response.statusCode} - ${response.body}',
        );
        _errorLearnings = [];
        notifyListeners();
      }
    } catch (e) {
      print('[CONQUEST_AI_PROVIDER] ❌ Error fetching error learnings: $e');
      _errorLearnings = [];
      notifyListeners();
    }
  }

  List<ConquestApp> getRecentTemplates({int limit = 5}) {
    return _currentApps
        .where((app) => app.status == 'template_ready')
        .take(limit)
        .toList();
  }

  void openTemplate(ConquestApp template) {
    // Implement navigation or logic to open/view the template
    // For now, just notify listeners
    notifyListeners();
  }

  Future fetchMainCode(String id) async {}

  /// Fetch deployments from the backend
  Future<void> fetchDeployments() async {
    print('[CONQUEST_AI_PROVIDER] 🔍 Fetching deployments from backend...');

    try {
      final response = await http
          .get(
            Uri.parse('${NetworkConfig.backendUrl}/api/conquest/deployments'),
            headers: {'Content-Type': 'application/json'},
          )
          .timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        final deploymentsData = data['deployments'] ?? [];

        _deployments =
            deploymentsData
                .map<ConquestApp?>((json) {
                  try {
                    return ConquestApp.fromJson(json);
                  } catch (e) {
                    print(
                      '[CONQUEST_AI_PROVIDER] ❌ Error parsing deployment: $e',
                    );
                    return null;
                  }
                })
                .where((app) => app != null)
                .cast<ConquestApp>()
                .toList();

        // Sort by creation date (newest first)
        _deployments.sort((a, b) => b.createdAt.compareTo(a.createdAt));

        print(
          '[CONQUEST_AI_PROVIDER] ✅ Fetched ${_deployments.length} deployments',
        );
        _setError(null); // Clear any previous errors
        notifyListeners();
      } else {
        print(
          '[CONQUEST_AI_PROVIDER] ❌ Failed to fetch deployments: ${response.statusCode} - ${response.body}',
        );
        _setError('Failed to fetch deployments: ${response.statusCode}');
        _deployments = [];
        notifyListeners();
      }
    } catch (e) {
      print('[CONQUEST_AI_PROVIDER] ❌ Error fetching deployments: $e');
      _setError('Failed to fetch deployments: $e');
      _deployments = [];
      notifyListeners();
    }
  }
}
