import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'dart:async';

/// AI Growth Analytics Provider
/// Manages AI growth scores, failures, successes, and learning insights
class AIGrowthAnalyticsProvider with ChangeNotifier {
  // Data storage
  Map<String, dynamic> _growthData = {};
  Map<String, dynamic> _aiStatus = {};
  List<Map<String, dynamic>> _recentFailures = [];
  List<Map<String, dynamic>> _recentSuccesses = [];
  List<Map<String, dynamic>> _learningInsights = [];
  Map<String, dynamic> _systemOverview = {};

  // State management
  bool _isLoading = false;
  String? _error;
  Timer? _pollingTimer;

  // Backend URL
  static const String backendUrl =
      'http://ec2-34-202-215-209.compute-1.amazonaws.com:4000';

  // Getters
  Map<String, dynamic> get growthData => _growthData;
  Map<String, dynamic> get aiStatus => _aiStatus;
  List<Map<String, dynamic>> get recentFailures => _recentFailures;
  List<Map<String, dynamic>> get recentSuccesses => _recentSuccesses;
  List<Map<String, dynamic>> get learningInsights => _learningInsights;
  Map<String, dynamic> get systemOverview => _systemOverview;
  bool get isLoading => _isLoading;
  String? get error => _error;

  /// Initialize the provider and start polling
  void initialize() {
    _loadAllData();
    _startPolling();
  }

  /// Load all analytics data
  Future<void> _loadAllData() async {
    _setLoading(true);
    _clearError();

    try {
      await Future.wait([
        _loadGrowthData(),
        _loadAIStatus(),
        _loadRecentActivity(),
        _loadLearningInsights(),
      ]);

      _updateSystemOverview();
    } catch (e) {
      _setError('Failed to load analytics data: $e');
    } finally {
      _setLoading(false);
    }
  }

  /// Load AI growth data
  Future<void> _loadGrowthData() async {
    try {
      final response = await http.get(
        Uri.parse('$backendUrl/api/growth/insights'),
        headers: {'Content-Type': 'application/json'},
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        _growthData = data;
        notifyListeners();
      } else {
        throw Exception('Failed to load growth data: ${response.statusCode}');
      }
    } catch (e) {
      print('Error loading growth data: $e');
      rethrow;
    }
  }

  /// Load AI agent status
  Future<void> _loadAIStatus() async {
    try {
      final response = await http.get(
        Uri.parse('$backendUrl/api/agents/status'),
        headers: {'Content-Type': 'application/json'},
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        _aiStatus = data;
        notifyListeners();
      } else {
        throw Exception('Failed to load AI status: ${response.statusCode}');
      }
    } catch (e) {
      print('Error loading AI status: $e');
      rethrow;
    }
  }

  /// Load recent activity (failures and successes)
  Future<void> _loadRecentActivity() async {
    try {
      final response = await http.get(
        Uri.parse('$backendUrl/api/learning/data'),
        headers: {'Content-Type': 'application/json'},
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        _processActivityData(data);
      } else {
        throw Exception(
          'Failed to load recent activity: ${response.statusCode}',
        );
      }
    } catch (e) {
      print('Error loading recent activity: $e');
      rethrow;
    }
  }

  /// Load learning insights for all AI types
  Future<void> _loadLearningInsights() async {
    try {
      final aiTypes = ['Imperium', 'Guardian', 'Sandbox', 'Conquest'];
      final insights = <Map<String, dynamic>>[];

      for (final aiType in aiTypes) {
        try {
          final response = await http.get(
            Uri.parse('$backendUrl/api/learning/insights/$aiType'),
            headers: {'Content-Type': 'application/json'},
          );

          if (response.statusCode == 200) {
            final data = jsonDecode(response.body);
            insights.add({'ai_type': aiType, 'insights': data});
          }
        } catch (e) {
          print('Error loading insights for $aiType: $e');
          // Add empty insights for failed AI types
          insights.add({
            'ai_type': aiType,
            'insights': {'recommendations': []},
          });
        }
      }

      _learningInsights = insights;
      notifyListeners();
    } catch (e) {
      print('Error loading learning insights: $e');
      rethrow;
    }
  }

  /// Process activity data to extract failures and successes
  void _processActivityData(Map<String, dynamic> data) {
    final failures = <Map<String, dynamic>>[];
    final successes = <Map<String, dynamic>>[];

    for (final aiType in data.keys) {
      final aiData = data[aiType] as Map<String, dynamic>;
      final userFeedback = aiData['userFeedback'] as List? ?? [];
      final backendTests = aiData['backendTestResults'] as List? ?? [];

      // Process user feedback
      for (final feedback in userFeedback) {
        if (feedback['accepted'] == false) {
          failures.add({
            'ai_type': aiType,
            'type': 'user_rejection',
            'message': feedback['feedback'] ?? 'Proposal rejected',
            'timestamp': feedback['timestamp'],
            'confidence': feedback['confidence'] ?? 0.0,
          });
        } else if (feedback['accepted'] == true) {
          successes.add({
            'ai_type': aiType,
            'type': 'user_acceptance',
            'message': feedback['feedback'] ?? 'Proposal accepted',
            'timestamp': feedback['timestamp'],
            'confidence': feedback['confidence'] ?? 0.0,
          });
        }
      }

      // Process backend tests
      for (final test in backendTests) {
        if (test['result'] == 'fail') {
          failures.add({
            'ai_type': aiType,
            'type': 'backend_failure',
            'message': test['error'] ?? 'Backend test failed',
            'timestamp': test['timestamp'],
            'confidence': test['confidence'] ?? 0.0,
          });
        } else if (test['result'] == 'pass') {
          successes.add({
            'ai_type': aiType,
            'type': 'backend_success',
            'message': test['message'] ?? 'Backend test passed',
            'timestamp': test['timestamp'],
            'confidence': test['confidence'] ?? 0.0,
          });
        }
      }
    }

    // Sort by timestamp (most recent first)
    failures.sort((a, b) => b['timestamp'].compareTo(a['timestamp']));
    successes.sort((a, b) => b['timestamp'].compareTo(a['timestamp']));

    _recentFailures = failures.take(10).toList();
    _recentSuccesses = successes.take(10).toList();
    notifyListeners();
  }

  /// Update system overview from growth data
  void _updateSystemOverview() {
    final overallGrowth =
        _growthData['overall_growth'] as Map<String, dynamic>? ?? {};

    _systemOverview = {
      'system_maturity': overallGrowth['system_maturity'] ?? 'unknown',
      'average_growth_score':
          (overallGrowth['average_growth_score'] ?? 0.0) * 100,
      'total_learning_entries': overallGrowth['total_learning_entries'] ?? 0,
      'total_expansion_opportunities':
          overallGrowth['total_expansion_opportunities'] ?? 0,
      'autonomous_cycle_running':
          _aiStatus['autonomous_cycle_running'] ?? false,
    };

    notifyListeners();
  }

  /// Get growth data for a specific AI type
  Map<String, dynamic> getGrowthDataForAI(String aiType) {
    final aiGrowthInsights =
        _growthData['ai_growth_insights'] as Map<String, dynamic>? ?? {};
    return aiGrowthInsights[aiType] ?? {};
  }

  /// Get AI agent status for a specific AI type
  Map<String, dynamic> getAIStatusForAI(String aiType) {
    final agents = _aiStatus['agents'] as Map<String, dynamic>? ?? {};
    return agents[aiType] ?? {};
  }

  /// Get learning insights for a specific AI type
  Map<String, dynamic> getLearningInsightsForAI(String aiType) {
    final insight = _learningInsights.firstWhere(
      (insight) => insight['ai_type'] == aiType,
      orElse: () => {'ai_type': aiType, 'insights': {}},
    );
    return insight['insights'] as Map<String, dynamic>;
  }

  /// Get recent failures for a specific AI type
  List<Map<String, dynamic>> getFailuresForAI(String aiType) {
    return _recentFailures
        .where((failure) => failure['ai_type'] == aiType)
        .toList();
  }

  /// Get recent successes for a specific AI type
  List<Map<String, dynamic>> getSuccessesForAI(String aiType) {
    return _recentSuccesses
        .where((success) => success['ai_type'] == aiType)
        .toList();
  }

  /// Get growth score for a specific AI type
  double getGrowthScoreForAI(String aiType) {
    final growthData = getGrowthDataForAI(aiType);
    final growthPotential =
        growthData['growth_potential'] as Map<String, dynamic>? ?? {};
    return (growthPotential['growth_score'] ?? 0.0) * 100;
  }

  /// Get growth stage for a specific AI type
  String getGrowthStageForAI(String aiType) {
    final growthData = getGrowthDataForAI(aiType);
    final growthPotential =
        growthData['growth_potential'] as Map<String, dynamic>? ?? {};
    return growthPotential['growth_stage'] ?? 'unknown';
  }

  /// Get performance metrics for a specific AI type
  Map<String, double> getPerformanceMetricsForAI(String aiType) {
    final growthData = getGrowthDataForAI(aiType);
    final currentPerformance =
        growthData['current_performance'] as Map<String, dynamic>? ?? {};

    return {
      'avg_confidence': (currentPerformance['avg_confidence'] ?? 0.0) * 100,
      'approval_rate': (currentPerformance['approval_rate'] ?? 0.0) * 100,
      'total_learning': (currentPerformance['total_learning'] ?? 0).toDouble(),
      'total_proposals':
          (currentPerformance['total_proposals'] ?? 0).toDouble(),
    };
  }

  /// Get expansion opportunities for a specific AI type
  List<Map<String, dynamic>> getExpansionOpportunitiesForAI(String aiType) {
    final growthData = getGrowthDataForAI(aiType);
    final opportunities = growthData['expansion_opportunities'] as List? ?? [];
    return opportunities.cast<Map<String, dynamic>>();
  }

  /// Get growth recommendations for a specific AI type
  List<Map<String, dynamic>> getGrowthRecommendationsForAI(String aiType) {
    final growthData = getGrowthDataForAI(aiType);
    final recommendations = growthData['growth_recommendations'] as List? ?? [];
    return recommendations.cast<Map<String, dynamic>>();
  }

  /// Get overall system statistics
  Map<String, dynamic> getSystemStatistics() {
    final aiTypes = ['Imperium', 'Guardian', 'Sandbox', 'Conquest'];
    final stats = <String, dynamic>{
      'total_ai_types': aiTypes.length,
      'active_ai_types': 0,
      'total_failures': _recentFailures.length,
      'total_successes': _recentSuccesses.length,
      'average_growth_score': 0.0,
      'system_maturity': _systemOverview['system_maturity'] ?? 'unknown',
    };

    double totalGrowthScore = 0.0;
    int activeAIs = 0;

    for (final aiType in aiTypes) {
      final status = getAIStatusForAI(aiType);
      if (status['status'] == 'healthy') {
        activeAIs++;
      }
      totalGrowthScore += getGrowthScoreForAI(aiType);
    }

    stats['active_ai_types'] = activeAIs;
    stats['average_growth_score'] = totalGrowthScore / aiTypes.length;

    return stats;
  }

  /// Refresh all data
  Future<void> refresh() async {
    await _loadAllData();
  }

  /// Start polling for updates
  void _startPolling() {
    _pollingTimer?.cancel();
    _pollingTimer = Timer.periodic(const Duration(seconds: 30), (timer) {
      _loadAllData();
    });
  }

  /// Stop polling
  void stopPolling() {
    _pollingTimer?.cancel();
  }

  /// Set loading state
  void _setLoading(bool loading) {
    _isLoading = loading;
    notifyListeners();
  }

  /// Set error state
  void _setError(String error) {
    _error = error;
    notifyListeners();
  }

  /// Clear error state
  void _clearError() {
    _error = null;
    notifyListeners();
  }

  @override
  void dispose() {
    _pollingTimer?.cancel();
    super.dispose();
  }
}
