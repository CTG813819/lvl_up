import 'package:flutter/foundation.dart';
import 'package:the_codex/main.dart';
import 'package:the_codex/providers/ai_learning_provider.dart';
import '../models/oath_paper.dart';
import 'proposal_provider.dart';
import 'dart:async';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;

class OathPapersProvider extends ChangeNotifier {
  final List<OathPaper> _oathPapers = [];
  final List<OathPaper> _pendingOathPapers = [];
  static const int _maxPendingUploads = 5;
  Timer? _operationalHoursTimer;

  List<OathPaper> get allOathPapers => List.unmodifiable(_oathPapers);
  List<OathPaper> get pendingOathPapers =>
      List.unmodifiable(_pendingOathPapers);
  int get pendingCount => _pendingOathPapers.length;
  bool get hasPendingUploads => _pendingOathPapers.isNotEmpty;
  bool get canAddPending => _pendingOathPapers.length < _maxPendingUploads;

  OathPapersProvider() {
    _loadPendingOathPapers();
    _startOperationalHoursTimer();
  }

  void _startOperationalHoursTimer() {
    _operationalHoursTimer?.cancel();
    _operationalHoursTimer = Timer.periodic(const Duration(minutes: 1), (
      timer,
    ) {
      _checkOperationalHours();
    });
  }

  void _checkOperationalHours() {
    final now = DateTime.now();
    final isWithinHours = now.hour >= 5 && now.hour < 21;

    // If we just entered operational hours (5:00 AM) and have pending papers
    if (isWithinHours &&
        now.hour == 5 &&
        now.minute < 5 &&
        _pendingOathPapers.isNotEmpty) {
      print(
        '[OATH_PAPERS_PROVIDER] 🌅 Operational hours started - processing pending oath papers',
      );
      processAllPendingOathPapers();
    }
  }

  @override
  void dispose() {
    _operationalHoursTimer?.cancel();
    super.dispose();
  }

  Future<void> _savePendingOathPapers() async {
    final prefs = await SharedPreferences.getInstance();
    final List<String> pendingJson =
        _pendingOathPapers.map((e) => jsonEncode(e.toJson())).toList();
    await prefs.setStringList('pendingOathPapers', pendingJson);
  }

  Future<void> _loadPendingOathPapers() async {
    final prefs = await SharedPreferences.getInstance();
    final List<String>? pendingJson = prefs.getStringList('pendingOathPapers');
    if (pendingJson != null) {
      _pendingOathPapers.clear();
      for (final jsonStr in pendingJson) {
        try {
          final map = jsonDecode(jsonStr);
          _pendingOathPapers.add(OathPaper.fromJson(map));
        } catch (e) {
          print('[OATH_PAPERS_PROVIDER] Error loading pending oath paper: $e');
        }
      }
      notifyListeners();
    }
  }

  // Add a new oath paper (can be pending if outside operational hours)
  Future<bool> addOathPaper({
    required String subject,
    required List<String> tags,
    String? description,
    String? code,
    String? targetAI,
    Map<String, double>? aiWeights,
  }) async {
    final now = DateTime.now();
    final isWithinHours = now.hour >= 5 && now.hour < 21;

    // If outside operational hours, add to pending (if space available)
    if (!isWithinHours) {
      if (!canAddPending) {
        print(
          '[OATH_PAPERS_PROVIDER] ❌ Cannot add pending upload - maximum of $_maxPendingUploads reached',
        );
        return false;
      }

      final pendingOathPaper = OathPaper(
        id: 'pending-${DateTime.now().millisecondsSinceEpoch}',
        subject: subject,
        tags: tags,
        description: description,
        code: code,
        timestamp: now,
        status: OathPaperStatus.pending,
        targetAI: targetAI,
        aiWeights: aiWeights ?? OathPaper.getDefaultWeights(),
      );

      _pendingOathPapers.add(pendingOathPaper);
      _oathPapers.add(pendingOathPaper);
      await _savePendingOathPapers();
      notifyListeners();

      print(
        '[OATH_PAPERS_PROVIDER] 📜 Added pending oath paper: $subject (${_pendingOathPapers.length}/$_maxPendingUploads)',
      );
      return true;
    }

    // Within operational hours - process immediately
    return await _processOathPaper(
      subject: subject,
      tags: tags,
      description: description,
      code: code,
      targetAI: targetAI,
      aiWeights: aiWeights,
    );
  }

  // Process a pending oath paper
  Future<bool> processPendingOathPaper(String id) async {
    final pendingIndex = _pendingOathPapers.indexWhere(
      (paper) => paper.id == id,
    );
    if (pendingIndex == -1) {
      print('[OATH_PAPERS_PROVIDER] ❌ Pending oath paper not found: $id');
      return false;
    }

    final pendingPaper = _pendingOathPapers[pendingIndex];

    // Check if it's within operational hours
    if (!pendingPaper.isReadyForProcessing) {
      print(
        '[OATH_PAPERS_PROVIDER] ⏰ Cannot process - outside operational hours',
      );
      return false;
    }

    // Remove from pending and process
    _pendingOathPapers.removeAt(pendingIndex);
    await _savePendingOathPapers();

    return await _processOathPaper(
      subject: pendingPaper.subject,
      tags: pendingPaper.tags,
      description: pendingPaper.description,
      code: pendingPaper.code,
      targetAI: pendingPaper.targetAI,
      aiWeights: pendingPaper.aiWeights,
      existingId: pendingPaper.id,
    );
  }

  // Process all pending oath papers (called when entering operational hours)
  Future<void> processAllPendingOathPapers() async {
    if (_pendingOathPapers.isEmpty) return;

    print(
      '[OATH_PAPERS_PROVIDER] 🔄 Processing ${_pendingOathPapers.length} pending oath papers...',
    );

    final papersToProcess = List<OathPaper>.from(_pendingOathPapers);

    for (final paper in papersToProcess) {
      await processPendingOathPaper(paper.id);
      // Add delay between processing to avoid overwhelming the system
      await Future.delayed(const Duration(seconds: 2));
    }
    await _savePendingOathPapers();
  }

  // Internal method to process an oath paper
  Future<bool> _processOathPaper({
    required String subject,
    required List<String> tags,
    String? description,
    String? code,
    String? targetAI,
    Map<String, double>? aiWeights,
    String? existingId,
  }) async {
    final id = existingId ?? 'oath-${DateTime.now().millisecondsSinceEpoch}';

    // Update status to processing
    final processingPaper = OathPaper(
      id: id,
      subject: subject,
      tags: tags,
      description: description,
      code: code,
      timestamp: DateTime.now(),
      status: OathPaperStatus.processing,
      targetAI: targetAI,
      aiWeights: aiWeights ?? OathPaper.getDefaultWeights(),
    );

    // Add or update in the main list
    final existingIndex = _oathPapers.indexWhere((paper) => paper.id == id);
    if (existingIndex != -1) {
      _oathPapers[existingIndex] = processingPaper;
    } else {
      _oathPapers.add(processingPaper);
    }
    notifyListeners();

    print('[OATH_PAPERS_PROVIDER] 🔄 Processing oath paper: $subject');
    print('[OATH_PAPERS_PROVIDER] Target AI: ${targetAI ?? "All AIs"}');
    print('[OATH_PAPERS_PROVIDER] AI Weights: $aiWeights');

    try {
      // Send to backend for AI learning
      final success = await _sendToBackend(processingPaper);

      if (success) {
        // Update status to completed
        final completedPaper = OathPaper(
          id: id,
          subject: subject,
          tags: tags,
          description: description,
          code: code,
          timestamp: processingPaper.timestamp,
          status: OathPaperStatus.completed,
          targetAI: targetAI,
          aiWeights: aiWeights ?? OathPaper.getDefaultWeights(),
          processingResult:
              'Successfully processed and sent to AIs for learning',
          processedAt: DateTime.now(),
        );

        final completedIndex = _oathPapers.indexWhere(
          (paper) => paper.id == id,
        );
        if (completedIndex != -1) {
          _oathPapers[completedIndex] = completedPaper;
        }

        print(
          '[OATH_PAPERS_PROVIDER] ✅ Oath paper processed successfully: $subject',
        );
      } else {
        // Update status to failed
        final failedPaper = OathPaper(
          id: id,
          subject: subject,
          tags: tags,
          description: description,
          code: code,
          timestamp: processingPaper.timestamp,
          status: OathPaperStatus.failed,
          targetAI: targetAI,
          aiWeights: aiWeights ?? OathPaper.getDefaultWeights(),
          processingResult: 'Failed to process - backend error',
          processedAt: DateTime.now(),
        );

        final failedIndex = _oathPapers.indexWhere((paper) => paper.id == id);
        if (failedIndex != -1) {
          _oathPapers[failedIndex] = failedPaper;
        }

        print(
          '[OATH_PAPERS_PROVIDER] ❌ Oath paper processing failed: $subject',
        );
      }

      notifyListeners();
      return success;
    } catch (e) {
      print('[OATH_PAPERS_PROVIDER] ❌ Error processing oath paper: $e');

      // Update status to failed
      final failedPaper = OathPaper(
        id: id,
        subject: subject,
        tags: tags,
        description: description,
        code: code,
        timestamp: processingPaper.timestamp,
        status: OathPaperStatus.failed,
        targetAI: targetAI,
        aiWeights: aiWeights ?? OathPaper.getDefaultWeights(),
        processingResult: 'Error: $e',
        processedAt: DateTime.now(),
      );

      final failedIndex = _oathPapers.indexWhere((paper) => paper.id == id);
      if (failedIndex != -1) {
        _oathPapers[failedIndex] = failedPaper;
      }

      notifyListeners();
      return false;
    }
  }

  // Send oath paper to backend
  Future<bool> _sendToBackend(OathPaper paper) async {
    try {
      final oathPaperData = {
        'subject': paper.subject,
        'tags': paper.tags,
        'description': paper.description,
        'code': paper.code,
        'targetAI': paper.targetAI,
        'aiWeights': paper.aiWeights,
        'timestamp': paper.timestamp.toIso8601String(),
        'learningMode': 'enhanced',
        'extractKeywords': true,
        'internetSearch': true,
        'gitIntegration': true,
      };

      // Use the existing proposal provider to send to backend
      final success = await ProposalProvider().sendOathPaperToAI(oathPaperData);

      if (success) {
        // Also trigger local learning service for enhanced processing
        try {
          final aiLearningProvider =
              navigatorKey.currentContext != null
                  ? Provider.of<AILearningProvider>(
                    navigatorKey.currentContext!,
                    listen: false,
                  )
                  : null;

          if (aiLearningProvider != null) {
            await aiLearningProvider.learnFromOathPaper(oathPaperData);
            print('[OATH_PAPERS_PROVIDER] ✅ Enhanced local learning completed');
          }
        } catch (e) {
          print('[OATH_PAPERS_PROVIDER] ⚠️ Local learning failed: $e');
          // Don't fail the entire process if local learning fails
        }
      }

      return success;
    } catch (e) {
      print('[OATH_PAPERS_PROVIDER] ❌ Error sending to backend: $e');
      return false;
    }
  }

  // Remove a pending oath paper
  void removePendingOathPaper(String id) {
    _pendingOathPapers.removeWhere((paper) => paper.id == id);
    _savePendingOathPapers();
    notifyListeners();
    print('[OATH_PAPERS_PROVIDER] 🗑️ Removed pending oath paper: $id');
  }

  // Get oath papers by status
  List<OathPaper> getOathPapersByStatus(OathPaperStatus status) {
    return _oathPapers.where((paper) => paper.status == status).toList();
  }

  // Get oath papers for a specific AI
  List<OathPaper> getOathPapersForAI(String aiType) {
    return _oathPapers
        .where((paper) => paper.targetAI == null || paper.targetAI == aiType)
        .toList();
  }

  // Clear all completed/failed papers (keep pending)
  void clearCompletedPapers() {
    _oathPapers.removeWhere(
      (paper) =>
          paper.status == OathPaperStatus.completed ||
          paper.status == OathPaperStatus.failed,
    );
    notifyListeners();
    print('[OATH_PAPERS_PROVIDER] 🧹 Cleared completed/failed papers');
  }

  // Get AI insights for oath papers
  Future<Map<String, dynamic>> getAIInsights() async {
    try {
      final response = await http.get(
        Uri.parse('http://34.202.215.209:4000/api/oath-papers/ai-insights'),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return data;
      } else {
        print(
          '[OATH_PAPERS_PROVIDER] ❌ Failed to get AI insights: ${response.body}',
        );
        return {
          'insights': [],
          'total_papers': 0,
          'average_learning_value': 0,
          'recommendations': [],
        };
      }
    } catch (e) {
      print('[OATH_PAPERS_PROVIDER] ❌ Error getting AI insights: $e');
      return {
        'insights': [],
        'total_papers': 0,
        'average_learning_value': 0,
        'recommendations': [],
      };
    }
  }

  // Trigger learning from oath papers
  Future<bool> triggerLearning() async {
    try {
      final response = await http.post(
        Uri.parse('http://34.202.215.209:4000/api/oath-papers/learn'),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        print(
          '[OATH_PAPERS_PROVIDER] ✅ Learning triggered: ${data['message']}',
        );
        return true;
      } else {
        print(
          '[OATH_PAPERS_PROVIDER] ❌ Failed to trigger learning: ${response.body}',
        );
        return false;
      }
    } catch (e) {
      print('[OATH_PAPERS_PROVIDER] ❌ Error triggering learning: $e');
      return false;
    }
  }

  // Get oath paper categories with AI analysis
  Future<Map<String, dynamic>> getCategoriesWithAI() async {
    try {
      final response = await http.get(
        Uri.parse('http://34.202.215.209:4000/api/oath-papers/categories'),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return data;
      } else {
        print(
          '[OATH_PAPERS_PROVIDER] ❌ Failed to get categories: ${response.body}',
        );
        return {'categories': [], 'total_categories': 0};
      }
    } catch (e) {
      print('[OATH_PAPERS_PROVIDER] ❌ Error getting categories: $e');
      return {'categories': [], 'total_categories': 0};
    }
  }
}
