import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:the_codex/providers/system_status_provider.dart';
import 'providers/system_status_provider.dart';
import 'widgets/system_status_indicator.dart';
import 'widgets/code_visualization_terminal.dart';

/// Test screen for system status features
class SystemStatusTestScreen extends StatefulWidget {
  const SystemStatusTestScreen({Key? key}) : super(key: key);

  @override
  State<SystemStatusTestScreen> createState() => _SystemStatusTestScreenState();
}

class _SystemStatusTestScreenState extends State<SystemStatusTestScreen> {
  bool _showTerminal = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('System Status Test'),
        actions: [
          // System Status Indicator in App Bar
          Consumer<SystemStatusProvider>(
            builder: (context, statusProvider, child) {
              return SystemStatusIndicator(
                showText: true,
                size: 24,
              );
            },
          ),
          const SizedBox(width: 16),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // System Status Overview
            Consumer<SystemStatusProvider>(
              builder: (context, statusProvider, child) {
                return Card(
                  child: Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Icon(
                              statusProvider.statusIcon,
                              color: statusProvider.statusColor,
                              size: 32,
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    'System Status',
                                    style: Theme.of(context).textTheme.headlineSmall,
                                  ),
                                  Text(
                                    statusProvider.statusMessage,
                                    style: TextStyle(
                                      color: statusProvider.statusColor,
                                      fontWeight: FontWeight.w500,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 16),
                        
                        // Status Details
                        _buildStatusRow('Backend', statusProvider.isBackendConnected),
                        _buildStatusRow('AI Learning', statusProvider.isAILearningActive),
                        _buildStatusRow('Notifications', statusProvider.notificationStatus.toString().contains('enabled')),
                        _buildStatusRow('Errors', statusProvider.hasErrors),
                        
                        const SizedBox(height: 16),
                        
                        // Action Buttons
                        Row(
                          children: [
                            Expanded(
                              child: ElevatedButton.icon(
                                onPressed: () => statusProvider.performHealthCheck(),
                                icon: const Icon(Icons.refresh),
                                label: const Text('Refresh Status'),
                              ),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: ElevatedButton.icon(
                                onPressed: () => _showResetConfirmation(context, statusProvider),
                                icon: const Icon(Icons.restart_alt),
                                label: const Text('Reset System'),
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: Colors.orange,
                                  foregroundColor: Colors.white,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
            
            const SizedBox(height: 16),
            
            // Terminal Toggle
            ElevatedButton.icon(
              onPressed: () {
                setState(() {
                  _showTerminal = !_showTerminal;
                });
              },
              icon: Icon(_showTerminal ? Icons.close : Icons.terminal),
              label: Text(_showTerminal ? 'Hide Terminal' : 'Show Terminal'),
            ),
            
            const SizedBox(height: 16),
            
            // Terminal
            if (_showTerminal)
              Expanded(
                child: CodeVisualizationTerminal(
                  isVisible: true,
                  onClose: () {
                    setState(() {
                      _showTerminal = false;
                    });
                  },
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildStatusRow(String label, bool isHealthy) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4.0),
      child: Row(
        children: [
          Container(
            width: 8,
            height: 8,
            decoration: BoxDecoration(
              color: isHealthy ? Colors.green : Colors.red,
              shape: BoxShape.circle,
            ),
          ),
          const SizedBox(width: 12),
          Text(
            label,
            style: const TextStyle(fontWeight: FontWeight.w500),
          ),
          const Spacer(),
          Text(
            isHealthy ? 'Healthy' : 'Issues',
            style: TextStyle(
              color: isHealthy ? Colors.green : Colors.red,
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }

  void _showResetConfirmation(BuildContext context, SystemStatusProvider statusProvider) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Reset System'),
        content: const Text(
          'This will reset the system status and perform fresh health checks. '
          'Are you sure you want to continue?',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.of(context).pop();
              statusProvider.resetSystem();
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.orange,
              foregroundColor: Colors.white,
            ),
            child: const Text('Reset'),
          ),
        ],
      ),
    );
  }
} 