import 'package:flutter/foundation.dart';
import 'dart:io';
import '../services/network_config.dart';

/// Android-specific configuration for the LVL UP app
class AndroidConfig {
  // Android-specific settings
  static const bool isAndroidOptimized = true;
  static const int maxBackgroundTasks = 3;
  static const Duration backgroundTaskTimeout = Duration(minutes: 10);

  // Android notification settings
  static const String notificationChannelId = 'ai_notifications';
  static const String notificationChannelName = 'AI Notifications';
  static const String notificationChannelDescription =
      'Notifications from autonomous AIs';

  // Android performance settings
  static const bool enableHardwareAcceleration = true;
  static const bool enableBackgroundProcessing = true;
  static const int maxMemoryUsageMB = 512;

  // Android network settings
  static const Duration networkTimeout = Duration(seconds: 30);
  static const int maxRetries = 3;
  static const Duration retryDelay = Duration(seconds: 2);

  // Android AI settings
  static const bool enableAutonomousAI = true;
  static const Duration aiCycleInterval = Duration(seconds: 30);
  static const Duration aiHealthCheckInterval = Duration(minutes: 2);
  static const Duration aiLearningInterval = Duration(minutes: 5);

  /// Check if running on Android
  static bool get isAndroid => Platform.isAndroid;

  /// Get Android-specific backend URLs
  static List<String> get androidBackendUrls => NetworkConfig.allBackendUrls;

  /// Get optimal AI cycle intervals for Android
  static Map<String, Duration> get aiCycleIntervals => {
    'Imperium': const Duration(seconds: 45), // Meta-AI - less frequent
    'Guardian': const Duration(seconds: 30), // Security - frequent
    'Conquest': const Duration(minutes: 2), // Builder - less frequent
    'Sandbox': const Duration(seconds: 60), // Experimental - moderate
  };

  /// Get AI operational hours for Android
  static Map<String, String> get aiOperationalHours => {
    'Imperium': 'always', // 24/7 operation
    'Guardian': 'always', // 24/7 security
    'Conquest': 'business', // 5 AM - 11:30 PM
    'Sandbox': 'always', // 24/7 experimentation
  };

  /// Get AI priority levels for Android
  static Map<String, String> get aiPriorities => {
    'Imperium': 'high', // Important but not critical
    'Guardian': 'critical', // Security is critical
    'Conquest': 'medium', // App building is medium priority
    'Sandbox': 'low', // Experimentation is low priority
  };

  /// Get Android-specific notification settings
  static Map<String, dynamic> get notificationSettings => {
    'channelId': notificationChannelId,
    'channelName': notificationChannelName,
    'channelDescription': notificationChannelDescription,
    'importance': 'high',
    'priority': 'high',
    'icon': '@drawable/notification_icon',
  };

  /// Get Android performance optimization settings
  static Map<String, dynamic> get performanceSettings => {
    'enableHardwareAcceleration': enableHardwareAcceleration,
    'enableBackgroundProcessing': enableBackgroundProcessing,
    'maxMemoryUsageMB': maxMemoryUsageMB,
    'maxBackgroundTasks': maxBackgroundTasks,
    'backgroundTaskTimeout': backgroundTaskTimeout.inSeconds,
  };

  /// Get Android AI orchestration settings
  static Map<String, dynamic> get aiOrchestrationSettings => {
    'enableAutonomousAI': enableAutonomousAI,
    'aiCycleInterval': aiCycleInterval.inSeconds,
    'aiHealthCheckInterval': aiHealthCheckInterval.inMinutes,
    'aiLearningInterval': aiLearningInterval.inMinutes,
    'maxRetries': maxRetries,
    'retryDelay': retryDelay.inSeconds,
  };

  /// Validate Android configuration
  static bool validateConfiguration() {
    if (!isAndroid) {
      print('[ANDROID_CONFIG] ⚠️ Not running on Android platform');
      return false;
    }

    // Validate AI cycle intervals
    for (final entry in aiCycleIntervals.entries) {
      if (entry.value.inSeconds < 10) {
        print(
          '[ANDROID_CONFIG] ❌ AI cycle interval too short for ${entry.key}',
        );
        return false;
      }
    }

    // Validate backend URLs
    if (androidBackendUrls.isEmpty) {
      print('[ANDROID_CONFIG] ❌ No backend URLs configured');
      return false;
    }

    print('[ANDROID_CONFIG] ✅ Android configuration validated');
    return true;
  }

  /// Get Android-specific error messages
  static Map<String, String> get errorMessages => {
    'network_timeout':
        'Network request timed out. Please check your connection.',
    'backend_unavailable':
        'Backend server is unavailable. AIs will operate in limited mode.',
    'ai_initialization_failed':
        'AI initialization failed. Some features may be unavailable.',
    'memory_limit_exceeded': 'Memory limit exceeded. Some AIs may be paused.',
    'background_task_failed':
        'Background task failed. AIs may not run optimally.',
  };

  /// Get Android-specific success messages
  static Map<String, String> get successMessages => {
    'ai_initialized': 'All AIs initialized successfully',
    'backend_connected': 'Connected to backend server',
    'ai_cycle_completed': 'AI cycle completed successfully',
    'learning_completed': 'AI learning cycle completed',
    'health_check_passed': 'All AIs are healthy',
  };
}
