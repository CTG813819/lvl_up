import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:ui';
import 'services/mission_sync_service.dart';

class GuardianService {
  static final GuardianService _instance = GuardianService._internal();
  factory GuardianService() => _instance;
  GuardianService._internal();

  static BuildContext? _rootContext;

  static void initialize(BuildContext context) {
    _rootContext = context;
    FlutterError.onError = (FlutterErrorDetails details) async {
      FlutterError.presentError(details);
      await _instance._logError(
        details.exceptionAsString(),
        details.stack?.toString(),
      );
      _instance._showUserNotification(
        'A UI error occurred. Guardian is monitoring.',
      );
    };
    PlatformDispatcher.instance.onError = (error, stack) {
      _instance._logError(error.toString(), stack.toString());
      _instance._showUserNotification(
        'A platform error occurred. Guardian is monitoring.',
      );
      return true;
    };
  }

  Future<void> _logError(String error, String? stack) async {
    try {
      await http.post(
        Uri.parse(
          'http://ec2-34-202-215-209.compute-1.amazonaws.com:4000/api/codex/log',
        ),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'type': 'guardian_ui_error',
          'summary': 'Frontend UI error detected',
          'details': {'error': error, 'stack': stack},
          'all_ok': false,
        }),
      );
    } catch (_) {}
  }

  void _showUserNotification(String message) {
    if (_rootContext == null) return;
    ScaffoldMessenger.of(_rootContext!).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            Icon(Icons.shield, color: Colors.white),
            const SizedBox(width: 8),
            Expanded(child: Text(message)),
          ],
        ),
        backgroundColor: Colors.red,
        duration: const Duration(seconds: 5),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  static Future<void> logCustomGuardianEvent(
    String summary, {
    Map<String, dynamic>? details,
    bool allOk = true,
  }) async {
    try {
      await http.post(
        Uri.parse(
          'http://ec2-34-202-215-209.compute-1.amazonaws.com:4000/api/codex/log',
        ),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'type': 'guardian_custom',
          'summary': summary,
          'details': details,
          'all_ok': allOk,
        }),
      );
    } catch (_) {}
  }

  // --- Backend API Calls for Diagnostics, Learning, Monitoring ---

  static const String _base =
      'http://ec2-34-202-215-209.compute-1.amazonaws.com:4000';

  static Future<Map<String, dynamic>?> getGuardianOverview() async {
    try {
      final res = await http.get(Uri.parse('$_base/api/guardian/'));
      if (res.statusCode == 200) return jsonDecode(res.body);
    } catch (_) {}
    return null;
  }

  static Future<Map<String, dynamic>?> getSecurityStatus() async {
    try {
      final res = await http.get(
        Uri.parse('$_base/api/guardian/security-status'),
      );
      if (res.statusCode == 200) return jsonDecode(res.body);
    } catch (_) {}
    return null;
  }

  static Future<Map<String, dynamic>?> getCodeReviewStatus() async {
    try {
      final res = await http.get(Uri.parse('$_base/api/guardian/code-review'));
      if (res.statusCode == 200) return jsonDecode(res.body);
    } catch (_) {}
    return null;
  }

  static Future<Map<String, dynamic>?> getThreatDetection() async {
    try {
      final res = await http.get(
        Uri.parse('$_base/api/guardian/threat-detection'),
      );
      if (res.statusCode == 200) return jsonDecode(res.body);
    } catch (_) {}
    return null;
  }

  static Future<Map<String, dynamic>?> getVulnerabilityScan() async {
    try {
      final res = await http.get(
        Uri.parse('$_base/api/guardian/vulnerability-scan'),
      );
      if (res.statusCode == 200) return jsonDecode(res.body);
    } catch (_) {}
    return null;
  }

  static Future<Map<String, dynamic>?> getGuardianLearnings() async {
    try {
      final res = await http.get(
        Uri.parse('$_base/api/conquest/ai/guardian/learnings'),
      );
      if (res.statusCode == 200) return jsonDecode(res.body);
    } catch (_) {}
    return null;
  }

  static Future<Map<String, dynamic>?> getImperiumMonitoring() async {
    try {
      final res = await http.get(Uri.parse('$_base/api/imperium/monitoring'));
      if (res.statusCode == 200) return jsonDecode(res.body);
    } catch (_) {}
    return null;
  }

  static Future<Map<String, dynamic>?> getImperiumImprovements() async {
    try {
      final res = await http.get(Uri.parse('$_base/api/imperium/improvements'));
      if (res.statusCode == 200) return jsonDecode(res.body);
    } catch (_) {}
    return null;
  }

  static Future<Map<String, dynamic>?> getImperiumIssues() async {
    try {
      final res = await http.get(Uri.parse('$_base/api/imperium/issues'));
      if (res.statusCode == 200) return jsonDecode(res.body);
    } catch (_) {}
    return null;
  }

  static Future<Map<String, dynamic>?> triggerImperiumScan() async {
    try {
      final res = await http.post(
        Uri.parse('$_base/api/imperium/trigger-scan'),
      );
      if (res.statusCode == 200) return jsonDecode(res.body);
    } catch (_) {}
    return null;
  }

  static Future<Map<String, dynamic>?> getImperiumStatus() async {
    try {
      final res = await http.get(Uri.parse('$_base/api/imperium/status'));
      if (res.statusCode == 200) return jsonDecode(res.body);
    } catch (_) {}
    return null;
  }

  static Future<Map<String, dynamic>?> getBackendHealth() async {
    try {
      final res = await http.get(Uri.parse('$_base/health'));
      if (res.statusCode == 200) return jsonDecode(res.body);
    } catch (_) {}
    return null;
  }

  static Future<Map<String, dynamic>?> getCodexChapters() async {
    try {
      final res = await http.get(Uri.parse('$_base/api/codex/'));
      if (res.statusCode == 200) return jsonDecode(res.body);
    } catch (_) {}
    return null;
  }

  // --- Guardian AI Health Check and Suggestion Management ---

  static Future<Map<String, dynamic>?> runHealthCheck() async {
    try {
      final res = await http.post(
        Uri.parse('$_base/api/guardian/health-check'),
      );
      if (res.statusCode == 200) return jsonDecode(res.body);
    } catch (_) {}
    return null;
  }

  static Future<Map<String, dynamic>?> getSuggestions({
    String status = 'pending',
    String? severity,
    String? issueType,
    int limit = 50,
    int offset = 0,
  }) async {
    try {
      final queryParams = <String, String>{
        'status': status,
        'limit': limit.toString(),
        'offset': offset.toString(),
      };

      if (severity != null) queryParams['severity'] = severity;
      if (issueType != null) queryParams['issue_type'] = issueType;

      final uri = Uri.parse(
        '$_base/api/guardian/suggestions',
      ).replace(queryParameters: queryParams);
      final res = await http.get(uri);
      if (res.statusCode == 200) return jsonDecode(res.body);
    } catch (_) {}
    return null;
  }

  static Future<Map<String, dynamic>?> approveSuggestion(
    String suggestionId, {
    String? userFeedback,
    String approvedBy = 'user',
  }) async {
    try {
      final body = <String, dynamic>{'approved_by': approvedBy};
      if (userFeedback != null) body['user_feedback'] = userFeedback;

      final res = await http.post(
        Uri.parse('$_base/api/guardian/suggestions/$suggestionId/approve'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode(body),
      );
      if (res.statusCode == 200) return jsonDecode(res.body);
    } catch (_) {}
    return null;
  }

  static Future<Map<String, dynamic>?> rejectSuggestion(
    String suggestionId, {
    String? userFeedback,
    String rejectedBy = 'user',
  }) async {
    try {
      final body = <String, dynamic>{'rejected_by': rejectedBy};
      if (userFeedback != null) body['user_feedback'] = userFeedback;

      final res = await http.post(
        Uri.parse('$_base/api/guardian/suggestions/$suggestionId/reject'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode(body),
      );
      if (res.statusCode == 200) return jsonDecode(res.body);
    } catch (_) {}
    return null;
  }

  static Future<Map<String, dynamic>?> getSuggestionStatistics() async {
    try {
      final res = await http.get(
        Uri.parse('$_base/api/guardian/suggestions/statistics'),
      );
      if (res.statusCode == 200) return jsonDecode(res.body);
    } catch (_) {}
    return null;
  }

  static Future<Map<String, dynamic>?> getHealthStatus() async {
    try {
      final res = await http.get(
        Uri.parse('$_base/api/guardian/health-status'),
      );
      if (res.statusCode == 200) return jsonDecode(res.body);
    } catch (_) {}
    return null;
  }

  // --- Mission Sync and Health Check Methods ---

  static Future<Map<String, dynamic>?> syncMissionsToBackend() async {
    try {
      return await MissionSyncService.syncMissionsToBackend();
    } catch (_) {}
    return null;
  }

  static Future<Map<String, dynamic>?> getMissionStatistics() async {
    try {
      return await MissionSyncService.getMissionStatistics();
    } catch (_) {}
    return null;
  }

  static Future<Map<String, dynamic>?> runMissionHealthCheck() async {
    try {
      return await MissionSyncService.runMissionHealthCheck();
    } catch (_) {}
    return null;
  }

  static Future<Map<String, dynamic>?> getMissionsFromBackend({
    int limit = 100,
    int offset = 0,
    bool? completed,
  }) async {
    try {
      return await MissionSyncService.getMissionsFromBackend(
        limit: limit,
        offset: offset,
        completed: completed,
      );
    } catch (_) {}
    return null;
  }
}
