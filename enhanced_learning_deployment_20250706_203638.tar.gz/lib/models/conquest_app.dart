class ConquestApp {
  final String id;
  final String name;
  final String description;
  final List<String> keywords;
  final String appType;
  final List<String> features;
  final String status;
  final DateTime createdAt;
  final DateTime? updatedAt;
  final String? repositoryUrl;
  final String? apkUrl;
  final String? category;
  final String? operationType;
  final String? existingRepo;
  final String? improvementFocus;
  final String? buildLogs;
  final String? errorMessage;
  final double? confidence;
  final String? testStatus;
  final String? testOutput;
  final String? aiReasoning;
  final String? userFeedback;
  final String? userFeedbackReason;
  final String userKeywords;
  final double progress;
  final List<String> developmentLogs;
  final Map<String, dynamic> requirements;
  final List<String> errors;
  final List<Map<String, dynamic>> learnings;
  final DateTime? completedAt;
  final String? finalAppPath;
  final String? githubRepoUrl;
  final String? downloadUrl;

  ConquestApp({
    required this.id,
    required this.name,
    required this.description,
    required this.keywords,
    required this.appType,
    required this.features,
    required this.status,
    required this.createdAt,
    this.updatedAt,
    this.repositoryUrl,
    this.apkUrl,
    this.category,
    this.operationType,
    this.existingRepo,
    this.improvementFocus,
    this.buildLogs,
    this.errorMessage,
    this.confidence,
    this.testStatus,
    this.testOutput,
    this.aiReasoning,
    this.userFeedback,
    this.userFeedbackReason,
    required this.userKeywords,
    required this.progress,
    required this.developmentLogs,
    required this.requirements,
    required this.errors,
    required this.learnings,
    this.completedAt,
    this.finalAppPath,
    this.githubRepoUrl,
    this.downloadUrl,
  });

  factory ConquestApp.fromJson(Map<String, dynamic> json) {
    return ConquestApp(
      id: json['id'] ?? '',
      name: json['name'] ?? json['app_name'] ?? '',
      description: json['description'] ?? '',
      keywords: _parseKeywords(json['keywords']),
      appType: json['app_type'] ?? 'general',
      features: _parseFeatures(json['features']),
      status: json['status'] ?? 'pending',
      createdAt: DateTime.tryParse(json['created_at'] ?? '') ?? DateTime.now(),
      updatedAt:
          json['updated_at'] != null
              ? DateTime.tryParse(json['updated_at'])
              : null,
      repositoryUrl: json['repository_url'],
      apkUrl: json['apk_url'],
      category:
          json['category'] ??
          _determineCategory(
            json['app_type'] ?? 'general',
            _parseKeywords(json['keywords']),
          ),
      operationType: json['operation_type'],
      existingRepo: json['existing_repo'],
      improvementFocus: json['improvement_focus'],
      buildLogs: json['build_logs'],
      errorMessage: json['error_message'],
      confidence: json['confidence']?.toDouble(),
      testStatus: json['test_status'],
      testOutput: json['test_output'],
      aiReasoning: json['ai_reasoning'],
      userFeedback: json['user_feedback'],
      userFeedbackReason: json['user_feedback_reason'],
      userKeywords: json['user_keywords'] ?? '',
      progress: json['progress']?.toDouble() ?? 0.0,
      developmentLogs: _parseDevelopmentLogs(json['development_logs']),
      requirements: Map<String, dynamic>.from(json['requirements'] ?? {}),
      errors: _parseErrors(json['errors']),
      learnings: _parseLearnings(json['learnings']),
      completedAt:
          json['completed_at'] != null
              ? DateTime.tryParse(json['completed_at'])
              : null,
      finalAppPath: json['final_app_path'],
      githubRepoUrl: json['github_repo_url'],
      downloadUrl: json['download_url'],
    );
  }

  static List<String> _parseKeywords(dynamic keywords) {
    if (keywords == null) return [];
    if (keywords is List) {
      return keywords.map((e) => e.toString()).toList();
    }
    if (keywords is String) {
      return keywords
          .split(',')
          .map((e) => e.trim())
          .where((e) => e.isNotEmpty)
          .toList();
    }
    return [];
  }

  static List<String> _parseFeatures(dynamic features) {
    if (features == null) return [];
    if (features is List) {
      return features.map((e) => e.toString()).toList();
    }
    return [];
  }

  static List<String> _parseDevelopmentLogs(dynamic logs) {
    if (logs == null) return [];
    if (logs is List) {
      return logs.map((e) => e.toString()).toList();
    }
    return [];
  }

  static List<String> _parseErrors(dynamic errors) {
    if (errors == null) return [];
    if (errors is List) {
      return errors.map((e) => e.toString()).toList();
    }
    return [];
  }

  static List<Map<String, dynamic>> _parseLearnings(dynamic learnings) {
    if (learnings == null) return [];
    if (learnings is List) {
      return learnings.map((e) {
        if (e is Map<String, dynamic>) {
          return e;
        }
        return <String, dynamic>{'learning': e.toString()};
      }).toList();
    }
    return [];
  }

  static String _determineCategory(String appType, List<String> keywords) {
    final text = (appType + " " + keywords.join(" ")).toLowerCase();

    if (text.contains('game') ||
        text.contains('gaming') ||
        text.contains('play')) {
      return 'Games';
    } else if (text.contains('social') ||
        text.contains('chat') ||
        text.contains('message')) {
      return 'Social';
    } else if (text.contains('fitness') ||
        text.contains('workout') ||
        text.contains('health')) {
      return 'Health & Fitness';
    } else if (text.contains('productivity') ||
        text.contains('task') ||
        text.contains('todo')) {
      return 'Productivity';
    } else if (text.contains('education') ||
        text.contains('learn') ||
        text.contains('study')) {
      return 'Education';
    } else if (text.contains('finance') ||
        text.contains('money') ||
        text.contains('bank')) {
      return 'Finance';
    } else if (text.contains('entertainment') ||
        text.contains('music') ||
        text.contains('video')) {
      return 'Entertainment';
    } else {
      return 'General';
    }
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'description': description,
      'keywords': keywords,
      'app_type': appType,
      'features': features,
      'status': status,
      'created_at': createdAt.toIso8601String(),
      'updated_at': updatedAt?.toIso8601String(),
      'repository_url': repositoryUrl,
      'apk_url': apkUrl,
      'category': category,
      'operation_type': operationType,
      'existing_repo': existingRepo,
      'improvement_focus': improvementFocus,
      'build_logs': buildLogs,
      'error_message': errorMessage,
      'confidence': confidence,
      'test_status': testStatus,
      'test_output': testOutput,
      'ai_reasoning': aiReasoning,
      'user_feedback': userFeedback,
      'user_feedback_reason': userFeedbackReason,
      'user_keywords': userKeywords,
      'progress': progress,
      'development_logs': developmentLogs,
      'requirements': requirements,
      'errors': errors,
      'learnings': learnings,
      'completed_at': completedAt?.toIso8601String(),
      'final_app_path': finalAppPath,
      'github_repo_url': githubRepoUrl,
      'download_url': downloadUrl,
    };
  }

  ConquestApp copyWith({
    String? id,
    String? name,
    String? description,
    List<String>? keywords,
    String? appType,
    List<String>? features,
    String? status,
    DateTime? createdAt,
    DateTime? updatedAt,
    String? repositoryUrl,
    String? apkUrl,
    String? category,
    String? operationType,
    String? existingRepo,
    String? improvementFocus,
    String? buildLogs,
    String? errorMessage,
    double? confidence,
    String? testStatus,
    String? testOutput,
    String? aiReasoning,
    String? userFeedback,
    String? userFeedbackReason,
    String? userKeywords,
    double? progress,
    List<String>? developmentLogs,
    Map<String, dynamic>? requirements,
    List<String>? errors,
    List<Map<String, dynamic>>? learnings,
    DateTime? completedAt,
    String? finalAppPath,
    String? githubRepoUrl,
    String? downloadUrl,
  }) {
    return ConquestApp(
      id: id ?? this.id,
      name: name ?? this.name,
      description: description ?? this.description,
      keywords: keywords ?? this.keywords,
      appType: appType ?? this.appType,
      features: features ?? this.features,
      status: status ?? this.status,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      repositoryUrl: repositoryUrl ?? this.repositoryUrl,
      apkUrl: apkUrl ?? this.apkUrl,
      category: category ?? this.category,
      operationType: operationType ?? this.operationType,
      existingRepo: existingRepo ?? this.existingRepo,
      improvementFocus: improvementFocus ?? this.improvementFocus,
      buildLogs: buildLogs ?? this.buildLogs,
      errorMessage: errorMessage ?? this.errorMessage,
      confidence: confidence ?? this.confidence,
      testStatus: testStatus ?? this.testStatus,
      testOutput: testOutput ?? this.testOutput,
      aiReasoning: aiReasoning ?? this.aiReasoning,
      userFeedback: userFeedback ?? this.userFeedback,
      userFeedbackReason: userFeedbackReason ?? this.userFeedbackReason,
      userKeywords: userKeywords ?? this.userKeywords,
      progress: progress ?? this.progress,
      developmentLogs: developmentLogs ?? this.developmentLogs,
      requirements: requirements ?? this.requirements,
      errors: errors ?? this.errors,
      learnings: learnings ?? this.learnings,
      completedAt: completedAt ?? this.completedAt,
      finalAppPath: finalAppPath ?? this.finalAppPath,
      githubRepoUrl: githubRepoUrl ?? this.githubRepoUrl,
      downloadUrl: downloadUrl ?? this.downloadUrl,
    );
  }
}
