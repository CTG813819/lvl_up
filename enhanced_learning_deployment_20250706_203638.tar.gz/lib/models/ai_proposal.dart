enum ProposalStatus {
  pending,
  approved,
  testing,
  rejected,
  applied,
  testPassed,
  testFailed,
}

class AIProposal {
  final String id;
  final String aiType;
  final String filePath;
  final String oldCode;
  final String newCode;
  final DateTime timestamp;
  ProposalStatus status;
  final String? testStatus;
  final String? testOutput;
  final String? description;
  final List<String>? tags;
  final String improvementType;
  final double? confidence;

  AIProposal({
    required this.id,
    required this.aiType,
    required this.filePath,
    required this.oldCode,
    required this.newCode,
    required this.timestamp,
    this.status = ProposalStatus.pending,
    this.testStatus,
    this.testOutput,
    this.description,
    this.tags,
    this.improvementType = 'general',
    this.confidence,
  });

  factory AIProposal.fromBackend(Map<String, dynamic> json) {
    // Handle both 'id' and '_id' fields from backend
    final id = json['id']?.toString() ?? json['_id']?.toString() ?? 'unknown';

    return AIProposal(
      id: id,
      aiType:
          json['ai_type']?.toString() ??
          json['aiType']?.toString() ??
          'Unknown',
      filePath:
          json['file_path']?.toString() ?? json['filePath']?.toString() ?? '',
      oldCode:
          json['code_before']?.toString() ??
          json['codeBefore']?.toString() ??
          '',
      newCode:
          json['code_after']?.toString() ?? json['codeAfter']?.toString() ?? '',
      timestamp:
          json['created_at'] != null
              ? DateTime.tryParse(json['created_at'].toString()) ??
                  DateTime.now()
              : json['createdAt'] != null
              ? DateTime.tryParse(json['createdAt'].toString()) ??
                  DateTime.now()
              : DateTime.now(),
      status: _statusFromString(json['status']?.toString()),
      testStatus:
          json['test_status']?.toString() ?? json['testStatus']?.toString(),
      testOutput:
          json['test_output']?.toString() ?? json['testOutput']?.toString(),
      description: json['description']?.toString(),
      tags: json['tags'] != null ? List<String>.from(json['tags']) : null,
      improvementType:
          json['improvement_type']?.toString() ??
          json['improvementType']?.toString() ??
          'general',
      confidence: json['confidence']?.toDouble(),
    );
  }

  factory AIProposal.fromJson(Map<String, dynamic> json) {
    return AIProposal(
      id: json['id'] ?? '',
      aiType: json['aiType'] ?? '',
      filePath: json['filePath'] ?? '',
      oldCode: json['oldCode'] ?? '',
      newCode: json['newCode'] ?? '',
      timestamp: DateTime.parse(json['timestamp']),
      status: _statusFromString(json['status']),
      testStatus: json['testStatus'],
      testOutput: json['testOutput'],
      description: json['description'],
      tags: json['tags'] != null ? List<String>.from(json['tags']) : null,
      improvementType: json['improvementType'] ?? 'general',
      confidence: json['confidence']?.toDouble(),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'aiType': aiType,
      'filePath': filePath,
      'oldCode': oldCode,
      'newCode': newCode,
      'timestamp': timestamp.toIso8601String(),
      'status': _statusToString(status),
      'testStatus': testStatus,
      'testOutput': testOutput,
      'description': description,
      'tags': tags,
      'improvementType': improvementType,
      'confidence': confidence,
    };
  }

  static ProposalStatus _statusFromString(String? s) {
    switch (s) {
      case 'approved':
        return ProposalStatus.approved;
      case 'accepted':
        // Backend sets accepted after successful testing
        return ProposalStatus.testPassed;
      case 'testing':
        return ProposalStatus.testing;
      case 'rejected':
        return ProposalStatus.rejected;
      case 'applied':
        return ProposalStatus.applied;
      case 'test-passed':
        return ProposalStatus.testPassed;
      case 'test-failed':
        return ProposalStatus.testFailed;
      default:
        return ProposalStatus.pending;
    }
  }

  static String _statusToString(ProposalStatus status) {
    switch (status) {
      case ProposalStatus.approved:
        return 'approved';
      case ProposalStatus.testing:
        return 'testing';
      case ProposalStatus.rejected:
        return 'rejected';
      case ProposalStatus.applied:
        return 'applied';
      case ProposalStatus.testPassed:
        return 'test-passed';
      case ProposalStatus.testFailed:
        return 'test-failed';
      default:
        return 'pending';
    }
  }
}
