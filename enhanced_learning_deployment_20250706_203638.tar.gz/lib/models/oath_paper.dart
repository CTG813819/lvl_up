enum OathPaperStatus { pending, processing, completed, failed }

class OathPaper {
  final String id;
  final String subject;
  final List<String> tags;
  final String? description;
  final String? code;
  final DateTime timestamp;
  OathPaperStatus status;
  final String? targetAI; // Specific AI to learn from this (optional)
  final Map<String, double>? aiWeights; // Weight distribution for AIs (5:3:3)
  final String? processingResult;
  final DateTime? processedAt;

  OathPaper({
    required this.id,
    required this.subject,
    required this.tags,
    this.description,
    this.code,
    required this.timestamp,
    this.status = OathPaperStatus.pending,
    this.targetAI,
    this.aiWeights,
    this.processingResult,
    this.processedAt,
  });

  factory OathPaper.fromJson(Map<String, dynamic> json) {
    return OathPaper(
      id: json['id'],
      subject: json['subject'],
      tags: List<String>.from(json['tags']),
      description: json['description'],
      code: json['code'],
      timestamp: DateTime.parse(json['timestamp']),
      status: _statusFromString(json['status']),
      targetAI: json['targetAI'],
      aiWeights: json['aiWeights'] != null 
          ? Map<String, double>.from(json['aiWeights'])
          : null,
      processingResult: json['processingResult'],
      processedAt: json['processedAt'] != null 
          ? DateTime.parse(json['processedAt'])
          : null,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'subject': subject,
      'tags': tags,
      'description': description,
      'code': code,
      'timestamp': timestamp.toIso8601String(),
      'status': status.toString().split('.').last,
      'targetAI': targetAI,
      'aiWeights': aiWeights,
      'processingResult': processingResult,
      'processedAt': processedAt?.toIso8601String(),
    };
  }

  static OathPaperStatus _statusFromString(String? s) {
    switch (s) {
      case 'processing':
        return OathPaperStatus.processing;
      case 'completed':
        return OathPaperStatus.completed;
      case 'failed':
        return OathPaperStatus.failed;
      default:
        return OathPaperStatus.pending;
    }
  }

  // Get default AI weights (5:3:3 distribution)
  static Map<String, double> getDefaultWeights() {
    return {
      'Imperium': 5.0,
      'Sandbox': 3.0,
      'Guardian': 3.0,
    };
  }

  // Check if this oath paper is ready to be processed (within operational hours)
  bool get isReadyForProcessing {
    final now = DateTime.now();
    return now.hour >= 5 && now.hour < 21;
  }
} 