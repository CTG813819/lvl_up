import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/ai_learning_provider.dart';
import '../providers/oath_papers_provider.dart';

class OathPapersScreen extends StatefulWidget {
  static const String routeName = '/oath_papers';

  const OathPapersScreen({Key? key}) : super(key: key);

  @override
  _OathPapersScreenState createState() => _OathPapersScreenState();
}

class _OathPapersScreenState extends State<OathPapersScreen>
    with TickerProviderStateMixin {
  final _formKey = GlobalKey<FormState>();
  final _subjectController = TextEditingController();
  final _tagsController = TextEditingController();
  final _descriptionController = TextEditingController();
  final _codeController = TextEditingController();
  String? _selectedAI;
  bool _isUploading = false;
  bool _showAIInsights = false;
  Map<String, dynamic> _aiInsights = {};
  bool _isLoadingInsights = false;
  bool _isExpanded = false;
  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;
  late Animation<Offset> _slideAnimation;

  final List<String> _aiOptions = [
    'All AIs',
    'Imperium',
    'Sandbox',
    'Guardian',
    'Conquest',
  ];

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 300),
      vsync: this,
    );
    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _animationController, curve: Curves.easeInOut),
    );
    _slideAnimation = Tween<Offset>(
      begin: const Offset(0, 0.1),
      end: Offset.zero,
    ).animate(
      CurvedAnimation(parent: _animationController, curve: Curves.easeOutCubic),
    );
    _animationController.forward();
  }

  @override
  void dispose() {
    _subjectController.dispose();
    _tagsController.dispose();
    _descriptionController.dispose();
    _codeController.dispose();
    _animationController.dispose();
    super.dispose();
  }

  Future<void> _loadAIInsights() async {
    setState(() {
      _isLoadingInsights = true;
    });

    try {
      final oathPapersProvider = Provider.of<OathPapersProvider>(
        context,
        listen: false,
      );
      final insights = await oathPapersProvider.getAIInsights();
      setState(() {
        _aiInsights = insights;
        _isLoadingInsights = false;
      });
    } catch (e) {
      setState(() {
        _isLoadingInsights = false;
      });
      _showErrorSnackBar('Failed to load AI insights: $e');
    }
  }

  Future<void> _triggerLearning() async {
    try {
      final oathPapersProvider = Provider.of<OathPapersProvider>(
        context,
        listen: false,
      );
      final success = await oathPapersProvider.triggerLearning();

      if (success) {
        _showSuccessSnackBar('AI learning triggered successfully!');
        await _loadAIInsights();
      } else {
        _showErrorSnackBar('Failed to trigger AI learning');
      }
    } catch (e) {
      _showErrorSnackBar('Error triggering learning: $e');
    }
  }

  Future<void> _uploadOathPaper() async {
    if (!_formKey.currentState!.validate()) return;

    final oathPapersProvider = Provider.of<OathPapersProvider>(
      context,
      listen: false,
    );

    if (!oathPapersProvider.canAddPending) {
      _showErrorSnackBar(
        'Maximum of 5 pending uploads reached. Please wait for some to process.',
      );
      return;
    }

    setState(() {
      _isUploading = true;
    });

    try {
      final targetAI = _selectedAI == 'All AIs' ? null : _selectedAI;

      final success = await oathPapersProvider.addOathPaper(
        subject: _subjectController.text.trim(),
        tags:
            _tagsController.text
                .trim()
                .split(',')
                .map((e) => e.trim())
                .toList(),
        description:
            _descriptionController.text.trim().isEmpty
                ? null
                : _descriptionController.text.trim(),
        code:
            _codeController.text.trim().isEmpty
                ? null
                : _codeController.text.trim(),
        targetAI: targetAI,
      );

      if (success) {
        final isPending = oathPapersProvider.pendingOathPapers.isNotEmpty;
        _showSuccessSnackBar(
          isPending
              ? 'Oath Paper added to pending queue! Will be processed at 5:00 AM.'
              : 'Oath Paper uploaded successfully! AIs will learn from this content.',
        );

        _clearForm();
      } else {
        _showErrorSnackBar('Failed to upload Oath Paper. Please try again.');
      }
    } catch (e) {
      _showErrorSnackBar('Error: $e');
    } finally {
      setState(() {
        _isUploading = false;
      });
    }
  }

  void _clearForm() {
    _formKey.currentState!.reset();
    _subjectController.clear();
    _tagsController.clear();
    _descriptionController.clear();
    _codeController.clear();
    setState(() {
      _selectedAI = null;
      _isExpanded = false;
    });
  }

  void _showSuccessSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            const Icon(Icons.check_circle, color: Colors.white),
            const SizedBox(width: 12),
            Expanded(child: Text(message)),
          ],
        ),
        backgroundColor: Colors.green[600],
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
      ),
    );
  }

  void _showErrorSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            const Icon(Icons.error, color: Colors.white),
            const SizedBox(width: 12),
            Expanded(child: Text(message)),
          ],
        ),
        backgroundColor: Colors.red[600],
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Consumer2<AILearningProvider, OathPapersProvider>(
      builder: (context, aiLearningProvider, oathPapersProvider, child) {
        final pendingCount = oathPapersProvider.pendingCount;

        return Scaffold(
          backgroundColor: const Color(0xFF0A0A0A),
          appBar: _buildAppBar(pendingCount, oathPapersProvider),
          body: FadeTransition(
            opacity: _fadeAnimation,
            child: SlideTransition(
              position: _slideAnimation,
              child: _buildBody(aiLearningProvider, oathPapersProvider),
            ),
          ),
        );
      },
    );
  }

  PreferredSizeWidget _buildAppBar(
    int pendingCount,
    OathPapersProvider provider,
  ) {
    return AppBar(
      backgroundColor: const Color(0xFF0A0A0A),
      elevation: 0,
      leading: IconButton(
        icon: Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.1),
            borderRadius: BorderRadius.circular(8),
          ),
          child: const Icon(Icons.arrow_back, color: Colors.white, size: 20),
        ),
        onPressed: () => Navigator.of(context).pop(),
      ),
      title: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Oath Papers',
            style: TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.bold,
              fontSize: 24,
            ),
          ),
          Text(
            'Teach AI systems new knowledge',
            style: TextStyle(
              color: Colors.white.withOpacity(0.7),
              fontSize: 12,
              fontWeight: FontWeight.w400,
            ),
          ),
        ],
      ),
      actions: [
        _buildActionButton(
          icon: Icons.psychology,
          isActive: _showAIInsights,
          onPressed: () {
            setState(() {
              _showAIInsights = !_showAIInsights;
            });
            if (_showAIInsights) {
              _loadAIInsights();
            }
          },
          color: Colors.blue[400]!,
        ),
        const SizedBox(width: 8),
        _buildPendingButton(pendingCount, provider),
        const SizedBox(width: 16),
      ],
    );
  }

  Widget _buildActionButton({
    required IconData icon,
    required bool isActive,
    required VoidCallback onPressed,
    required Color color,
  }) {
    return Container(
      decoration: BoxDecoration(
        color:
            isActive ? color.withOpacity(0.2) : Colors.white.withOpacity(0.1),
        borderRadius: BorderRadius.circular(8),
        border: isActive ? Border.all(color: color, width: 1) : null,
      ),
      child: IconButton(
        icon: Icon(icon, color: isActive ? color : Colors.white, size: 20),
        onPressed: onPressed,
      ),
    );
  }

  Widget _buildPendingButton(int pendingCount, OathPapersProvider provider) {
    return Stack(
      children: [
        Container(
          decoration: BoxDecoration(
            color:
                pendingCount > 0
                    ? Colors.orange.withOpacity(0.2)
                    : Colors.white.withOpacity(0.1),
            borderRadius: BorderRadius.circular(8),
            border:
                pendingCount > 0
                    ? Border.all(color: Colors.orange, width: 1)
                    : null,
          ),
          child: IconButton(
            icon: Icon(
              Icons.book,
              color: pendingCount > 0 ? Colors.orange : Colors.white,
              size: 20,
            ),
            onPressed:
                pendingCount > 0
                    ? () => _showPendingUploads(context, provider)
                    : null,
          ),
        ),
        if (pendingCount > 0)
          Positioned(
            right: 8,
            top: 8,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
              decoration: BoxDecoration(
                color: Colors.orange,
                borderRadius: BorderRadius.circular(10),
                boxShadow: [
                  BoxShadow(
                    color: Colors.orange.withOpacity(0.4),
                    blurRadius: 4,
                    spreadRadius: 1,
                  ),
                ],
              ),
              constraints: const BoxConstraints(minWidth: 18, minHeight: 18),
              child: Text(
                '$pendingCount',
                style: const TextStyle(
                  color: Colors.black,
                  fontSize: 10,
                  fontWeight: FontWeight.bold,
                ),
                textAlign: TextAlign.center,
              ),
            ),
          ),
      ],
    );
  }

  Widget _buildBody(
    AILearningProvider aiLearningProvider,
    OathPapersProvider oathPapersProvider,
  ) {
    return CustomScrollView(
      slivers: [
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildFormSection(),
                const SizedBox(height: 32),
                _buildAILearningSection(aiLearningProvider),
                if (_showAIInsights) ...[
                  const SizedBox(height: 24),
                  _buildAIInsightsSection(),
                ],
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildFormSection() {
    return Container(
      decoration: BoxDecoration(
        color: const Color(0xFF1A1A1A),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.white.withOpacity(0.1)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: Colors.red.withOpacity(0.1),
              borderRadius: const BorderRadius.only(
                topLeft: Radius.circular(16),
                topRight: Radius.circular(16),
              ),
            ),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: Colors.red.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: const Icon(
                    Icons.edit_document,
                    color: Colors.red,
                    size: 20,
                  ),
                ),
                const SizedBox(width: 12),
                const Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Create New Oath Paper',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      SizedBox(height: 4),
                      Text(
                        'Teach AI systems new knowledge and capabilities',
                        style: TextStyle(color: Colors.white70, fontSize: 14),
                      ),
                    ],
                  ),
                ),
                IconButton(
                  icon: Icon(
                    _isExpanded ? Icons.expand_less : Icons.expand_more,
                    color: Colors.white,
                  ),
                  onPressed: () {
                    setState(() {
                      _isExpanded = !_isExpanded;
                    });
                  },
                ),
              ],
            ),
          ),
          if (_isExpanded) ...[
            Padding(
              padding: const EdgeInsets.all(20),
              child: Form(
                key: _formKey,
                child: Column(
                  children: [
                    _buildFormField(
                      controller: _subjectController,
                      label: 'Subject',
                      hint: 'Enter the main topic or concept',
                      icon: Icons.title,
                      isRequired: true,
                      validator: (value) {
                        if (value == null || value.trim().isEmpty) {
                          return 'Subject is required';
                        }
                        return null;
                      },
                    ),
                    const SizedBox(height: 16),
                    _buildFormField(
                      controller: _tagsController,
                      label: 'Tags',
                      hint: 'machine learning, API, database (comma-separated)',
                      icon: Icons.tag,
                      isRequired: true,
                      validator: (value) {
                        if (value == null || value.trim().isEmpty) {
                          return 'Tags are required';
                        }
                        return null;
                      },
                    ),
                    const SizedBox(height: 16),
                    _buildAISelector(),
                    const SizedBox(height: 16),
                    _buildFormField(
                      controller: _descriptionController,
                      label: 'Description',
                      hint: 'Describe what you want the AI to learn...',
                      icon: Icons.description,
                      maxLines: 3,
                    ),
                    const SizedBox(height: 16),
                    _buildFormField(
                      controller: _codeController,
                      label: 'Code',
                      hint: 'Paste code for the AI to learn from...',
                      icon: Icons.code,
                      maxLines: 6,
                    ),
                    const SizedBox(height: 24),
                    _buildUploadButton(),
                  ],
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildFormField({
    required TextEditingController controller,
    required String label,
    required String hint,
    required IconData icon,
    bool isRequired = false,
    int maxLines = 1,
    String? Function(String?)? validator,
  }) {
    return Container(
      decoration: BoxDecoration(
        color: const Color(0xFF2A2A2A),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.white.withOpacity(0.1)),
      ),
      child: TextFormField(
        controller: controller,
        maxLines: maxLines,
        style: const TextStyle(color: Colors.white, fontSize: 16),
        decoration: InputDecoration(
          labelText: isRequired ? '$label *' : label,
          labelStyle: TextStyle(
            color: Colors.white.withOpacity(0.7),
            fontSize: 14,
          ),
          hintText: hint,
          hintStyle: TextStyle(
            color: Colors.white.withOpacity(0.5),
            fontSize: 14,
          ),
          prefixIcon: Icon(
            icon,
            color: Colors.white.withOpacity(0.7),
            size: 20,
          ),
          border: InputBorder.none,
          contentPadding: const EdgeInsets.all(16),
        ),
        validator: validator,
      ),
    );
  }

  Widget _buildAISelector() {
    return Container(
      decoration: BoxDecoration(
        color: const Color(0xFF2A2A2A),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.white.withOpacity(0.1)),
      ),
      child: DropdownButtonFormField<String>(
        value: _selectedAI,
        style: const TextStyle(color: Colors.white, fontSize: 16),
        decoration: const InputDecoration(
          labelText: 'Target AI (Optional)',
          labelStyle: TextStyle(color: Colors.white70, fontSize: 14),
          prefixIcon: Icon(Icons.psychology, color: Colors.white70, size: 20),
          border: InputBorder.none,
          contentPadding: EdgeInsets.all(16),
        ),
        dropdownColor: const Color(0xFF2A2A2A),
        items:
            _aiOptions.map((ai) {
              Color color;
              IconData icon;
              switch (ai) {
                case 'Imperium':
                  color = Colors.purple;
                  icon = Icons.psychology;
                  break;
                case 'Sandbox':
                  color = Colors.orange;
                  icon = Icons.science;
                  break;
                case 'Guardian':
                  color = Colors.blue;
                  icon = Icons.security;
                  break;
                case 'Conquest':
                  color = Colors.amber;
                  icon = Icons.auto_awesome;
                  break;
                default:
                  color = Colors.white;
                  icon = Icons.all_inclusive;
              }

              return DropdownMenuItem(
                value: ai,
                child: Row(
                  children: [
                    Icon(icon, color: color, size: 18),
                    const SizedBox(width: 12),
                    Text(ai, style: const TextStyle(color: Colors.white)),
                  ],
                ),
              );
            }).toList(),
        onChanged: (value) {
          setState(() {
            _selectedAI = value;
          });
        },
      ),
    );
  }

  Widget _buildUploadButton() {
    return SizedBox(
      width: double.infinity,
      height: 56,
      child: ElevatedButton(
        onPressed: !_isUploading ? _uploadOathPaper : null,
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.red[600],
          foregroundColor: Colors.white,
          elevation: 0,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
        ),
        child:
            _isUploading
                ? const Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(
                        strokeWidth: 2,
                        valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                      ),
                    ),
                    SizedBox(width: 12),
                    Text('Uploading...', style: TextStyle(fontSize: 16)),
                  ],
                )
                : const Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.upload, size: 20),
                    SizedBox(width: 8),
                    Text(
                      'Upload Oath Paper',
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
      ),
    );
  }

  Widget _buildAILearningSection(AILearningProvider aiLearningProvider) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'AI Learning Status',
          style: TextStyle(
            color: Colors.white,
            fontSize: 20,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 16),
        _buildAIStatusCard(
          'Imperium',
          Icons.psychology,
          Colors.purple,
          aiLearningProvider.isAILearning('Imperium'),
          aiLearningProvider.getLearningDataForAI('Imperium'),
        ),
        const SizedBox(height: 12),
        _buildAIStatusCard(
          'Sandbox',
          Icons.science,
          Colors.orange,
          aiLearningProvider.isAILearning('Sandbox'),
          aiLearningProvider.getLearningDataForAI('Sandbox'),
        ),
        const SizedBox(height: 12),
        _buildAIStatusCard(
          'Guardian',
          Icons.security,
          Colors.blue,
          aiLearningProvider.isAILearning('Guardian'),
          aiLearningProvider.getLearningDataForAI('Guardian'),
        ),
      ],
    );
  }

  Widget _buildAIStatusCard(
    String aiName,
    IconData icon,
    Color color,
    bool isLearning,
    Map<String, dynamic> learningData,
  ) {
    final capabilities = learningData['capabilities'] ?? <String>[];
    final recentLearning = learningData['recentLearning'] ?? <String>[];

    return Container(
      decoration: BoxDecoration(
        color: const Color(0xFF1A1A1A),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: color.withOpacity(0.3)),
      ),
      child: Theme(
        data: Theme.of(context).copyWith(dividerColor: Colors.transparent),
        child: ExpansionTile(
          leading: Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: color.withOpacity(0.2),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Icon(icon, color: color, size: 24),
          ),
          title: Text(
            aiName,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
          subtitle: Container(
            margin: const EdgeInsets.only(top: 4),
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            decoration: BoxDecoration(
              color:
                  isLearning
                      ? Colors.orange.withOpacity(0.2)
                      : Colors.green.withOpacity(0.2),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Text(
              isLearning ? '🔄 Learning...' : '✅ Ready',
              style: TextStyle(
                color: isLearning ? Colors.orange : Colors.green,
                fontSize: 12,
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
          children: [
            Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  if (capabilities.isNotEmpty) ...[
                    _buildSectionTitle('Learned Capabilities'),
                    const SizedBox(height: 12),
                    Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children:
                          capabilities
                              .map(
                                (capability) =>
                                    _buildCapabilityChip(capability, color),
                              )
                              .toList(),
                    ),
                  ],
                  if (recentLearning.isNotEmpty) ...[
                    const SizedBox(height: 20),
                    _buildSectionTitle('Recent Learning'),
                    const SizedBox(height: 12),
                    ...recentLearning
                        .take(3)
                        .map((learning) => _buildLearningItem(learning)),
                  ],
                  if (capabilities.isEmpty && recentLearning.isEmpty)
                    Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.05),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Row(
                        children: [
                          Icon(
                            Icons.info_outline,
                            color: Colors.white.withOpacity(0.5),
                            size: 20,
                          ),
                          const SizedBox(width: 12),
                          Text(
                            'No learning data available yet.',
                            style: TextStyle(
                              color: Colors.white.withOpacity(0.5),
                              fontSize: 14,
                              fontStyle: FontStyle.italic,
                            ),
                          ),
                        ],
                      ),
                    ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSectionTitle(String title) {
    return Text(
      title,
      style: const TextStyle(
        color: Colors.white,
        fontSize: 16,
        fontWeight: FontWeight.bold,
      ),
    );
  }

  Widget _buildCapabilityChip(String capability, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: color.withOpacity(0.2),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: color.withOpacity(0.5)),
      ),
      child: Text(
        capability,
        style: TextStyle(
          color: color,
          fontSize: 12,
          fontWeight: FontWeight.w500,
        ),
      ),
    );
  }

  Widget _buildLearningItem(String learning) {
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.05),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(Icons.lightbulb_outline, color: Colors.amber, size: 16),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              learning,
              style: const TextStyle(color: Colors.white70, fontSize: 14),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAIInsightsSection() {
    return Container(
      decoration: BoxDecoration(
        color: const Color(0xFF1A1A1A),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.blue.withOpacity(0.3)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: Colors.blue.withOpacity(0.1),
              borderRadius: const BorderRadius.only(
                topLeft: Radius.circular(16),
                topRight: Radius.circular(16),
              ),
            ),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: Colors.blue.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: const Icon(
                    Icons.psychology,
                    color: Colors.blue,
                    size: 20,
                  ),
                ),
                const SizedBox(width: 12),
                const Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'AI Insights & Learning',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      SizedBox(height: 4),
                      Text(
                        'Analytics and recommendations',
                        style: TextStyle(color: Colors.white70, fontSize: 14),
                      ),
                    ],
                  ),
                ),
                if (_isLoadingInsights)
                  const SizedBox(
                    width: 20,
                    height: 20,
                    child: CircularProgressIndicator(
                      strokeWidth: 2,
                      valueColor: AlwaysStoppedAnimation<Color>(Colors.blue),
                    ),
                  ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(20),
            child:
                _aiInsights.isNotEmpty
                    ? Column(
                      children: [
                        Row(
                          children: [
                            Expanded(
                              child: _buildInsightCard(
                                'Total Papers',
                                '${_aiInsights['total_papers'] ?? 0}',
                                Icons.description,
                                Colors.green,
                              ),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: _buildInsightCard(
                                'Avg Learning Value',
                                '${(_aiInsights['average_learning_value'] ?? 0.0).toStringAsFixed(1)}',
                                Icons.trending_up,
                                Colors.orange,
                              ),
                            ),
                          ],
                        ),
                        if (_aiInsights['recommendations'] != null) ...[
                          const SizedBox(height: 20),
                          _buildSectionTitle('AI Recommendations'),
                          const SizedBox(height: 12),
                          ...(_aiInsights['recommendations'] as List<dynamic>)
                              .map(
                                (rec) =>
                                    _buildRecommendationItem(rec.toString()),
                              ),
                        ],
                        const SizedBox(height: 20),
                        SizedBox(
                          width: double.infinity,
                          height: 48,
                          child: ElevatedButton.icon(
                            onPressed: _triggerLearning,
                            icon: const Icon(Icons.play_arrow, size: 20),
                            label: const Text(
                              'Trigger AI Learning',
                              style: TextStyle(fontSize: 16),
                            ),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.green[600],
                              foregroundColor: Colors.white,
                              elevation: 0,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12),
                              ),
                            ),
                          ),
                        ),
                      ],
                    )
                    : Container(
                      padding: const EdgeInsets.all(20),
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.05),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Row(
                        children: [
                          Icon(
                            Icons.info_outline,
                            color: Colors.white.withOpacity(0.5),
                            size: 20,
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Text(
                              'No AI insights available. Upload some Oath Papers to see learning analytics.',
                              style: TextStyle(
                                color: Colors.white.withOpacity(0.5),
                                fontSize: 14,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
          ),
        ],
      ),
    );
  }

  Widget _buildRecommendationItem(String recommendation) {
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.blue.withOpacity(0.1),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: Colors.blue.withOpacity(0.3)),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(Icons.lightbulb, color: Colors.amber, size: 16),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              recommendation,
              style: const TextStyle(color: Colors.white70, fontSize: 14),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInsightCard(
    String title,
    String value,
    IconData icon,
    Color color,
  ) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFF2A2A2A),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color.withOpacity(0.3)),
      ),
      child: Column(
        children: [
          Icon(icon, color: color, size: 24),
          const SizedBox(height: 8),
          Text(
            title,
            style: TextStyle(
              color: Colors.white.withOpacity(0.7),
              fontSize: 12,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            value,
            style: TextStyle(
              color: color,
              fontWeight: FontWeight.bold,
              fontSize: 18,
            ),
          ),
        ],
      ),
    );
  }

  void _showPendingUploads(BuildContext context, OathPapersProvider provider) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder:
          (context) => Container(
            height: MediaQuery.of(context).size.height * 0.7,
            decoration: const BoxDecoration(
              color: Color(0xFF1A1A1A),
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(20),
                topRight: Radius.circular(20),
              ),
            ),
            child: Column(
              children: [
                Container(
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    color: Colors.orange.withOpacity(0.1),
                    borderRadius: const BorderRadius.only(
                      topLeft: Radius.circular(20),
                      topRight: Radius.circular(20),
                    ),
                  ),
                  child: Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: Colors.orange.withOpacity(0.2),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: const Icon(
                          Icons.schedule,
                          color: Colors.orange,
                          size: 20,
                        ),
                      ),
                      const SizedBox(width: 12),
                      const Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Pending Uploads',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            SizedBox(height: 4),
                            Text(
                              'Will be processed at 5:00 AM',
                              style: TextStyle(
                                color: Colors.white70,
                                fontSize: 14,
                              ),
                            ),
                          ],
                        ),
                      ),
                      IconButton(
                        icon: const Icon(Icons.close, color: Colors.white),
                        onPressed: () => Navigator.pop(context),
                      ),
                    ],
                  ),
                ),
                Expanded(
                  child: ListView.builder(
                    padding: const EdgeInsets.all(20),
                    itemCount: provider.pendingOathPapers.length,
                    itemBuilder: (context, index) {
                      final paper = provider.pendingOathPapers[index];
                      return Container(
                        margin: const EdgeInsets.only(bottom: 12),
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: const Color(0xFF2A2A2A),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(
                            color: Colors.orange.withOpacity(0.3),
                          ),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                Expanded(
                                  child: Text(
                                    paper.subject,
                                    style: const TextStyle(
                                      color: Colors.white,
                                      fontWeight: FontWeight.bold,
                                      fontSize: 16,
                                    ),
                                  ),
                                ),
                                IconButton(
                                  icon: const Icon(
                                    Icons.delete,
                                    color: Colors.red,
                                    size: 20,
                                  ),
                                  onPressed: () {
                                    provider.removePendingOathPaper(paper.id);
                                    Navigator.pop(context);
                                  },
                                ),
                              ],
                            ),
                            const SizedBox(height: 8),
                            Wrap(
                              spacing: 8,
                              runSpacing: 4,
                              children:
                                  paper.tags
                                      .map((tag) => _buildTagChip(tag))
                                      .toList(),
                            ),
                            if (paper.targetAI != null) ...[
                              const SizedBox(height: 8),
                              Container(
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 8,
                                  vertical: 4,
                                ),
                                decoration: BoxDecoration(
                                  color: Colors.orange.withOpacity(0.2),
                                  borderRadius: BorderRadius.circular(8),
                                ),
                                child: Text(
                                  'Target: ${paper.targetAI}',
                                  style: const TextStyle(
                                    color: Colors.orange,
                                    fontSize: 12,
                                  ),
                                ),
                              ),
                            ],
                            const SizedBox(height: 8),
                            Text(
                              'Added: ${paper.timestamp.toString().substring(0, 16)}',
                              style: TextStyle(
                                color: Colors.white.withOpacity(0.5),
                                fontSize: 12,
                              ),
                            ),
                          ],
                        ),
                      );
                    },
                  ),
                ),
              ],
            ),
          ),
    );
  }

  Widget _buildTagChip(String tag) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.1),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Text(
        tag,
        style: TextStyle(color: Colors.white.withOpacity(0.8), fontSize: 12),
      ),
    );
  }
}
