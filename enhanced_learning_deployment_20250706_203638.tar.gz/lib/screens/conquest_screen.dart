import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:pinput/pinput.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../providers/conquest_ai_provider.dart';
import '../models/conquest_app.dart';
import 'dart:async';
import 'package:http/http.dart' as http;

enum NotificationType { success, error, warning, info }

final List<Color> iconColors = [
  Colors.yellow[700]!,
  Colors.blueAccent,
  Colors.green,
  Colors.redAccent,
  Colors.purple,
  Colors.orange,
];
Color getIconColor(String name) {
  final hash = name.codeUnits.fold(0, (a, b) => a + b);
  return iconColors[hash % iconColors.length];
}

class ConquestScreen extends StatefulWidget {
  static const String routeName = '/conquest';
  const ConquestScreen({Key? key}) : super(key: key);

  @override
  State<ConquestScreen> createState() => _ConquestScreenState();
}

class _ConquestScreenState extends State<ConquestScreen>
    with TickerProviderStateMixin {
  late AnimationController _lockAnimationController;
  late AnimationController _fadeAnimationController;
  bool _isUnlocked = false;
  bool _showPinEntry = false;
  bool _showSetPin = false;
  String? _storedPin;

  // Operational hours
  String _opStart = '05:00';
  String _opEnd = '23:30';
  Timer? _timer;

  // App suggestion form controllers
  final TextEditingController _appNameController = TextEditingController();
  final TextEditingController _appDescriptionController =
      TextEditingController();
  final TextEditingController _appKeywordsController = TextEditingController();
  final TextEditingController _existingRepoController = TextEditingController();
  final TextEditingController _improvementFocusController =
      TextEditingController();
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  bool _showProgress = false;
  bool _showNotifications = false;
  bool _showGuardrails = false;
  bool _showOperationDialog = false;
  String _selectedOperation =
      'create_new'; // 'create_new' or 'improve_existing'

  String _selectedFramework = 'Flutter';
  final List<String> frameworks = [
    'Flutter',
    'React',
    'Vue',
    'Angular',
    'Express',
    'Django',
  ];

  final RegExp _forbiddenChars = RegExp(r'[^a-zA-Z0-9 .,\-_/]');

  String? _validateAppName(String? value) {
    if (value == null || value.trim().isEmpty) {
      return 'App name is required.';
    }
    if (value.trim().length < 3) {
      return 'App name must be at least 3 characters.';
    }
    if (_forbiddenChars.hasMatch(value)) {
      return 'App name contains forbidden characters.';
    }
    return null;
  }

  String? _validateAppDescription(String? value) {
    if (value == null || value.trim().isEmpty) {
      return 'Description is required.';
    }
    if (value.trim().length < 10) {
      return 'Description must be at least 10 characters.';
    }
    if (_forbiddenChars.hasMatch(value)) {
      return 'Description contains forbidden characters.';
    }
    return null;
  }

  String? _validateKeywords(String? value) {
    if (value == null || value.trim().isEmpty) {
      return 'At least one keyword/tag is required.';
    }
    final keywords =
        value
            .split(',')
            .map((e) => e.trim())
            .where((e) => e.isNotEmpty)
            .toList();
    if (keywords.isEmpty) {
      return 'At least one keyword/tag is required.';
    }
    if (keywords.length < 2) {
      return 'Add more keywords for better results.';
    }
    for (final k in keywords) {
      if (_forbiddenChars.hasMatch(k)) {
        return 'Keywords contain forbidden characters.';
      }
    }
    return null;
  }

  @override
  void initState() {
    super.initState();
    _lockAnimationController = AnimationController(
      duration: const Duration(milliseconds: 1500),
      vsync: this,
    );
    _fadeAnimationController = AnimationController(
      duration: const Duration(milliseconds: 800),
      vsync: this,
    );
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      await _loadPin();
      final provider = Provider.of<ConquestAIProvider>(context, listen: false);
      await provider.initialize();
      _fetchOperationalHoursFromBackend(provider);
      provider.resumeInterruptedBuilds();
    });
  }

  Future<void> _loadPin() async {
    final prefs = await SharedPreferences.getInstance();
    final pin = prefs.getString('conquest_pin');
    setState(() {
      _storedPin = pin;
      _showSetPin = pin == null;
      _showPinEntry = pin != null;
    });
  }

  Future<void> _fetchOperationalHoursFromBackend(
    ConquestAIProvider provider,
  ) async {
    // Wait for provider to load status
    await Future.delayed(Duration(milliseconds: 200));
    final status = provider.conquestStatus;
    if (status['operationalHours'] != null) {
      final start = status['operationalHours']['start'] ?? '05:00';
      final end = status['operationalHours']['end'] ?? '23:30';

      // Check if we're still getting old operational hours
      if (start == '09:00' && end == '18:00') {
        print(
          '[CONQUEST_SCREEN] ⚠️ Detected old operational hours, forcing refresh...',
        );
        await provider.forceRefreshOperationalHours();
        // Wait a bit more for the refresh to complete
        await Future.delayed(Duration(milliseconds: 500));
        final refreshedStatus = provider.conquestStatus;
        if (refreshedStatus['operationalHours'] != null) {
          setState(() {
            _opStart = refreshedStatus['operationalHours']['start'] ?? '05:00';
            _opEnd = refreshedStatus['operationalHours']['end'] ?? '23:30';
          });
        }
      } else {
        setState(() {
          _opStart = start;
          _opEnd = end;
        });
      }

      _checkOperationalHours();
      _timer?.cancel();
      _timer = Timer.periodic(
        Duration(minutes: 1),
        (_) => _checkOperationalHours(),
      );
    }
  }

  void _setPin(String pin) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('conquest_pin', pin);
    setState(() {
      _storedPin = pin;
      _showSetPin = false;
      _showPinEntry = true;
    });
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            Icon(Icons.lock, color: Colors.white),
            SizedBox(width: 8),
            Text('PIN set successfully!'),
          ],
        ),
        backgroundColor: Colors.purple,
        duration: Duration(seconds: 2),
      ),
    );
  }

  void _onPinEntered(String pin, BuildContext context) {
    if (pin == _storedPin) {
      setState(() {
        _isUnlocked = true;
        _showPinEntry = false;
      });
      _lockAnimationController.forward();
      _fadeAnimationController.forward();
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Row(
            children: [
              Icon(Icons.lock_open, color: Colors.white),
              SizedBox(width: 8),
              Text('Conquest AI unlocked! 🐉'),
            ],
          ),
          backgroundColor: Colors.purple,
          duration: Duration(seconds: 2),
        ),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Row(
            children: [
              Icon(Icons.error, color: Colors.white),
              SizedBox(width: 8),
              Text('Incorrect PIN. Try again.'),
            ],
          ),
          backgroundColor: Colors.red,
          duration: Duration(seconds: 2),
        ),
      );
    }
  }

  void _checkOperationalHours() {
    final now = TimeOfDay.now();
    final startParts = _opStart.split(':');
    final endParts = _opEnd.split(':');
    final start = TimeOfDay(
      hour: int.parse(startParts[0]),
      minute: int.parse(startParts[1]),
    );
    final end = TimeOfDay(
      hour: int.parse(endParts[0]),
      minute: int.parse(endParts[1]),
    );
    bool within = _isTimeWithin(now, start, end);

    // Debug logging
    print(
      '[CONQUEST_SCREEN] ⏰ Current time: ${now.hour}:${now.minute.toString().padLeft(2, '0')}',
    );
    print('[CONQUEST_SCREEN] ⏰ Start time: $_opStart');
    print('[CONQUEST_SCREEN] ⏰ End time: $_opEnd');
    print('[CONQUEST_SCREEN] ⏰ Within operational hours: $within');

    setState(() {});
  }

  bool _isTimeWithin(TimeOfDay now, TimeOfDay start, TimeOfDay end) {
    final nowMinutes = now.hour * 60 + now.minute;
    final startMinutes = start.hour * 60 + start.minute;
    final endMinutes = end.hour * 60 + end.minute;
    if (startMinutes <= endMinutes) {
      return nowMinutes >= startMinutes && nowMinutes <= endMinutes;
    } else {
      // Overnight range
      return nowMinutes >= startMinutes || nowMinutes <= endMinutes;
    }
  }

  @override
  void dispose() {
    _lockAnimationController.dispose();
    _fadeAnimationController.dispose();
    _appNameController.dispose();
    _appDescriptionController.dispose();
    _appKeywordsController.dispose();
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_showSetPin) {
      return _buildSetPinScreen();
    }
    if (_showPinEntry && !_isUnlocked) {
      return _buildPinEntry();
    }
    return _buildMainConquestScreen();
  }

  Widget _buildSetPinScreen() {
    final pinController = TextEditingController();
    final confirmController = TextEditingController();
    final formKey = GlobalKey<FormState>();
    return Scaffold(
      backgroundColor: Colors.black,
      body: Center(
        child: Container(
          padding: EdgeInsets.all(32),
          decoration: BoxDecoration(
            color: Colors.purple.withOpacity(0.1),
            borderRadius: BorderRadius.circular(16),
          ),
          child: Form(
            key: formKey,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.lock, color: Colors.purple, size: 60),
                SizedBox(height: 16),
                Text(
                  'Set a PIN for Conquest AI',
                  style: TextStyle(
                    fontSize: 22,
                    color: Colors.purple,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                SizedBox(height: 24),
                TextFormField(
                  controller: pinController,
                  obscureText: true,
                  keyboardType: TextInputType.number,
                  maxLength: 6,
                  style: TextStyle(color: Colors.white),
                  decoration: InputDecoration(
                    labelText: 'Enter PIN',
                    labelStyle: TextStyle(color: Colors.purple),
                    hintText: 'Enter 4-6 digit PIN',
                    hintStyle: TextStyle(color: Colors.grey[400]),
                    filled: true,
                    fillColor: Colors.grey[900],
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                      borderSide: BorderSide(color: Colors.purple),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                      borderSide: BorderSide(
                        color: Colors.purple.withOpacity(0.5),
                      ),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                      borderSide: BorderSide(color: Colors.purple, width: 2),
                    ),
                  ),
                  validator:
                      (v) =>
                          v == null || v.length < 4
                              ? 'PIN must be at least 4 digits'
                              : null,
                ),
                SizedBox(height: 12),
                TextFormField(
                  controller: confirmController,
                  obscureText: true,
                  keyboardType: TextInputType.number,
                  maxLength: 6,
                  style: TextStyle(color: Colors.white),
                  decoration: InputDecoration(
                    labelText: 'Confirm PIN',
                    labelStyle: TextStyle(color: Colors.purple),
                    hintText: 'Confirm your PIN',
                    hintStyle: TextStyle(color: Colors.grey[400]),
                    filled: true,
                    fillColor: Colors.grey[900],
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                      borderSide: BorderSide(color: Colors.purple),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                      borderSide: BorderSide(
                        color: Colors.purple.withOpacity(0.5),
                      ),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                      borderSide: BorderSide(color: Colors.purple, width: 2),
                    ),
                  ),
                  validator:
                      (v) =>
                          v != pinController.text ? 'PINs do not match' : null,
                ),
                SizedBox(height: 24),
                ElevatedButton(
                  onPressed: () {
                    if (formKey.currentState!.validate()) {
                      _setPin(pinController.text);
                    }
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.purple,
                  ),
                  child: Text('Set PIN', style: TextStyle(color: Colors.white)),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildPinEntry() {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Center(
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              AnimatedBuilder(
                animation: _lockAnimationController,
                builder: (context, child) {
                  return Transform.scale(
                    scale: 1.0 + (_lockAnimationController.value * 0.2),
                    child: Container(
                      padding: EdgeInsets.all(20),
                      decoration: BoxDecoration(
                        color: Colors.purple.withOpacity(0.2),
                        shape: BoxShape.circle,
                        border: Border.all(
                          color: Colors.purple.withOpacity(0.5),
                          width: 2,
                        ),
                      ),
                      child: Icon(Icons.lock, size: 80, color: Colors.purple),
                    ),
                  );
                },
              ),
              SizedBox(height: 40),
              Text(
                'Conquest AI',
                style: TextStyle(
                  fontSize: 32,
                  fontWeight: FontWeight.bold,
                  color: Colors.purple,
                ),
              ),
              SizedBox(height: 8),
              Text(
                'Enter PIN to access the Monster AI',
                style: TextStyle(fontSize: 16, color: Colors.grey[400]),
              ),
              SizedBox(height: 40),
              _buildConquestPinEntry(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildConquestPinEntry() {
    final pinController = TextEditingController();
    String enteredPin = '';
    String errorMessage = '';

    final defaultPinTheme = PinTheme(
      width: 56,
      height: 56,
      textStyle: const TextStyle(fontSize: 20, color: Colors.black),
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border.all(color: Colors.white),
        borderRadius: BorderRadius.circular(8),
      ),
    );

    final focusedPinTheme = defaultPinTheme.copyWith(
      decoration: BoxDecoration(
        color: Colors.purple,
        border: Border.all(color: Colors.purple),
        borderRadius: BorderRadius.circular(8),
      ),
    );

    final submittedPinTheme = defaultPinTheme.copyWith(
      decoration: BoxDecoration(
        color: Colors.purple,
        border: Border.all(color: Colors.purple),
        borderRadius: BorderRadius.circular(8),
      ),
    );

    final errorPinTheme = defaultPinTheme.copyWith(
      decoration: BoxDecoration(
        color: Colors.red,
        border: Border.all(color: Colors.red),
        borderRadius: BorderRadius.circular(8),
      ),
    );

    return StatefulBuilder(
      builder: (context, setState) {
        return Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                'Conquest AI Access',
                style: const TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  color: Colors.purple,
                ),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 32),
              SizedBox(
                height: 80,
                child: Pinput(
                  controller: pinController,
                  length: 6,
                  defaultPinTheme: defaultPinTheme,
                  focusedPinTheme: focusedPinTheme,
                  submittedPinTheme: submittedPinTheme,
                  errorPinTheme: errorMessage.isNotEmpty ? errorPinTheme : null,
                  obscureText: true,
                  keyboardType: TextInputType.number,
                  onChanged: (value) {
                    setState(() {
                      enteredPin = value;
                      errorMessage = '';
                    });
                  },
                  onCompleted: (value) async {
                    if (value.length == 6) {
                      if (value == _storedPin) {
                        _onPinEntered(value, context);
                      } else {
                        setState(() {
                          errorMessage = 'Invalid PIN';
                        });
                        pinController.clear();
                      }
                    }
                  },
                ),
              ),
              if (errorMessage.isNotEmpty) ...[
                const SizedBox(height: 16),
                Text(
                  errorMessage,
                  style: const TextStyle(color: Colors.red, fontSize: 16),
                  textAlign: TextAlign.center,
                ),
              ],
            ],
          ),
        );
      },
    );
  }

  Widget _buildMainConquestScreen() {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.yellow[700],
        iconTheme: IconThemeData(color: Colors.black),
        title: Text(
          'Conquest AI',
          style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold),
        ),
        actions: [
          IconButton(
            icon: Icon(Icons.notifications, color: Colors.black),
            onPressed:
                () => setState(() => _showNotifications = !_showNotifications),
          ),
          IconButton(
            icon: Icon(Icons.security, color: Colors.black),
            onPressed: () => setState(() => _showGuardrails = !_showGuardrails),
          ),
        ],
      ),
      body: Consumer<ConquestAIProvider>(
        builder: (context, provider, child) {
          return SingleChildScrollView(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // 3. Status Card
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.yellow[700],
                    borderRadius: BorderRadius.circular(12),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.yellow[700]!.withOpacity(0.2),
                        blurRadius: 8,
                        offset: const Offset(0, 2),
                      ),
                    ],
                  ),
                  child: Row(
                    children: [
                      Icon(
                        provider.isConquestActive
                            ? Icons.play_circle_filled
                            : Icons.pause_circle_filled,
                        color: Colors.black,
                        size: 32,
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Conquest AI Status',
                              style: TextStyle(
                                color: Colors.black,
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            Text(
                              provider.isConquestActive
                                  ? 'Active & Learning'
                                  : 'Inactive',
                              style: TextStyle(
                                color: Colors.black87,
                                fontSize: 14,
                              ),
                            ),
                          ],
                        ),
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 8,
                          vertical: 4,
                        ),
                        decoration: BoxDecoration(
                          color: Colors.black,
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Text(
                          provider.isConquestActive ? 'ONLINE' : 'OFFLINE',
                          style: TextStyle(
                            color: Colors.yellow[700],
                            fontSize: 12,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 20),

                // Action Buttons Section
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.black,
                    borderRadius: BorderRadius.circular(12),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.yellow[700]!.withOpacity(0.2),
                        blurRadius: 8,
                        offset: const Offset(0, 2),
                      ),
                    ],
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Conquest AI Actions',
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          color: Colors.yellow[700],
                        ),
                      ),
                      const SizedBox(height: 16),
                      Row(
                        children: [
                          Expanded(
                            child: ElevatedButton.icon(
                              onPressed: () => _showCreateNewAppDialog(context),
                              icon: Icon(Icons.add_circle, color: Colors.black),
                              label: Text(
                                'Create New APK',
                                style: TextStyle(
                                  color: Colors.black,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.green[400],
                                padding: const EdgeInsets.symmetric(
                                  vertical: 16,
                                ),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(8),
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: ElevatedButton.icon(
                              onPressed: () => _showImproveAppDialog(context),
                              icon: Icon(Icons.upgrade, color: Colors.black),
                              label: Text(
                                'Improve App',
                                style: TextStyle(
                                  color: Colors.black,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.blue[400],
                                padding: const EdgeInsets.symmetric(
                                  vertical: 16,
                                ),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(8),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 12),
                      SizedBox(
                        width: double.infinity,
                        child: ElevatedButton.icon(
                          onPressed:
                              () => Navigator.pushNamed(
                                context,
                                '/conquest-apps',
                              ),
                          icon: Icon(Icons.apps, color: Colors.black),
                          label: Text(
                            'View Created Apps',
                            style: TextStyle(
                              color: Colors.black,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.yellow[700],
                            padding: const EdgeInsets.symmetric(vertical: 16),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(8),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 20),

                // 4. Section Title
                Text(
                  'Submit App Request',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
                const SizedBox(height: 12),
                // 5. Form Card
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.black,
                    borderRadius: BorderRadius.circular(12),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.yellow[700]!.withOpacity(0.2),
                        blurRadius: 8,
                        offset: const Offset(0, 2),
                      ),
                    ],
                  ),
                  child: Form(
                    key: _formKey,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        TextFormField(
                          controller: _appNameController,
                          style: TextStyle(color: Colors.white),
                          decoration: InputDecoration(
                            labelText: 'App Name',
                            labelStyle: TextStyle(color: Colors.white),
                            prefixIcon: Icon(
                              Icons.apps,
                              color: Colors.yellow[700],
                            ),
                            enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(8),
                              borderSide: BorderSide(
                                color: Colors.yellow[700]!,
                              ),
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(8),
                              borderSide: BorderSide(
                                color: Colors.yellow[700]!,
                                width: 2,
                              ),
                            ),
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(8),
                            ),
                            fillColor: Colors.grey[900],
                            filled: true,
                          ),
                          validator: _validateAppName,
                        ),
                        const SizedBox(height: 16),
                        TextFormField(
                          controller: _appDescriptionController,
                          style: TextStyle(color: Colors.white),
                          maxLines: 3,
                          decoration: InputDecoration(
                            labelText: 'Description',
                            labelStyle: TextStyle(color: Colors.white),
                            prefixIcon: Icon(
                              Icons.description,
                              color: Colors.yellow[700],
                            ),
                            enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(8),
                              borderSide: BorderSide(
                                color: Colors.yellow[700]!,
                              ),
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(8),
                              borderSide: BorderSide(
                                color: Colors.yellow[700]!,
                                width: 2,
                              ),
                            ),
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(8),
                            ),
                            fillColor: Colors.grey[900],
                            filled: true,
                          ),
                          validator: _validateAppDescription,
                        ),
                        const SizedBox(height: 16),
                        TextFormField(
                          controller: _appKeywordsController,
                          style: TextStyle(color: Colors.white),
                          decoration: InputDecoration(
                            labelText: 'Keywords (comma-separated)',
                            labelStyle: TextStyle(color: Colors.white),
                            prefixIcon: Icon(
                              Icons.tag,
                              color: Colors.yellow[700],
                            ),
                            enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(8),
                              borderSide: BorderSide(
                                color: Colors.yellow[700]!,
                              ),
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(8),
                              borderSide: BorderSide(
                                color: Colors.yellow[700]!,
                                width: 2,
                              ),
                            ),
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(8),
                            ),
                            fillColor: Colors.grey[900],
                            filled: true,
                          ),
                          validator: _validateKeywords,
                        ),
                        const SizedBox(height: 16),
                        DropdownButtonFormField<String>(
                          value: _selectedFramework,
                          dropdownColor: Colors.black,
                          style: TextStyle(color: Colors.white),
                          iconEnabledColor: Colors.yellow[700],
                          items:
                              frameworks
                                  .map(
                                    (f) => DropdownMenuItem(
                                      value: f,
                                      child: Text(
                                        f,
                                        style: TextStyle(color: Colors.white),
                                      ),
                                    ),
                                  )
                                  .toList(),
                          onChanged:
                              (val) =>
                                  setState(() => _selectedFramework = val!),
                          decoration: InputDecoration(
                            labelText: 'Framework',
                            labelStyle: TextStyle(color: Colors.white),
                            prefixIcon: Icon(
                              Icons.code,
                              color: Colors.yellow[700],
                            ),
                            enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(8),
                              borderSide: BorderSide(
                                color: Colors.yellow[700]!,
                              ),
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(8),
                              borderSide: BorderSide(
                                color: Colors.yellow[700]!,
                                width: 2,
                              ),
                            ),
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(8),
                            ),
                            fillColor: Colors.grey[900],
                            filled: true,
                          ),
                        ),
                        const SizedBox(height: 16),

                        // Operation Selection
                        Container(
                          padding: const EdgeInsets.all(16),
                          decoration: BoxDecoration(
                            color: Colors.grey[900],
                            borderRadius: BorderRadius.circular(8),
                            border: Border.all(color: Colors.yellow[700]!),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Operation Type',
                                style: TextStyle(
                                  color: Colors.yellow[700],
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              const SizedBox(height: 12),
                              Container(
                                decoration: BoxDecoration(
                                  color: Colors.grey[900],
                                  borderRadius: BorderRadius.circular(8),
                                  border: Border.all(
                                    color: Colors.yellow[700]!,
                                  ),
                                ),
                                child: DropdownButtonFormField<String>(
                                  value: _selectedOperation,
                                  style: TextStyle(color: Colors.white),
                                  dropdownColor: Colors.grey[900],
                                  decoration: InputDecoration(
                                    labelText: 'Operation Type',
                                    labelStyle: TextStyle(
                                      color: Colors.yellow[700],
                                    ),
                                    border: InputBorder.none,
                                    contentPadding: EdgeInsets.symmetric(
                                      horizontal: 16,
                                      vertical: 12,
                                    ),
                                  ),
                                  items: [
                                    DropdownMenuItem(
                                      value: 'create_new',
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        mainAxisSize: MainAxisSize.min,
                                        children: [
                                          Text(
                                            'Create New App',
                                            style: TextStyle(
                                              color: Colors.white,
                                              fontWeight: FontWeight.bold,
                                            ),
                                          ),
                                          Text(
                                            'Generate new repository and APK',
                                            style: TextStyle(
                                              color: Colors.grey[400],
                                              fontSize: 12,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    DropdownMenuItem(
                                      value: 'improve_existing',
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        mainAxisSize: MainAxisSize.min,
                                        children: [
                                          Text(
                                            'Improve Existing App',
                                            style: TextStyle(
                                              color: Colors.white,
                                              fontWeight: FontWeight.bold,
                                            ),
                                          ),
                                          Text(
                                            'Enhance existing app with new features',
                                            style: TextStyle(
                                              color: Colors.grey[400],
                                              fontSize: 12,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                  onChanged: (value) {
                                    setState(() {
                                      _selectedOperation = value!;
                                    });
                                  },
                                ),
                              ),
                            ],
                          ),
                        ),

                        // Conditional fields based on operation type
                        if (_selectedOperation == 'improve_existing') ...[
                          const SizedBox(height: 16),
                          TextFormField(
                            controller: _existingRepoController,
                            style: TextStyle(color: Colors.white),
                            decoration: InputDecoration(
                              labelText: 'Existing Repository URL',
                              labelStyle: TextStyle(color: Colors.white),
                              prefixIcon: Icon(
                                Icons.link,
                                color: Colors.blue[400],
                              ),
                              enabledBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(8),
                                borderSide: BorderSide(
                                  color: Colors.blue[400]!,
                                ),
                              ),
                              focusedBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(8),
                                borderSide: BorderSide(
                                  color: Colors.blue[400]!,
                                  width: 2,
                                ),
                              ),
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(8),
                              ),
                              fillColor: Colors.grey[900],
                              filled: true,
                            ),
                            validator: (value) {
                              if (value == null || value.isEmpty) {
                                return 'Please enter repository URL';
                              }
                              return null;
                            },
                          ),
                          const SizedBox(height: 16),
                          TextFormField(
                            controller: _improvementFocusController,
                            style: TextStyle(color: Colors.white),
                            decoration: InputDecoration(
                              labelText: 'Improvement Focus',
                              labelStyle: TextStyle(color: Colors.white),
                              prefixIcon: Icon(
                                Icons.auto_fix_high,
                                color: Colors.green[400],
                              ),
                              enabledBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(8),
                                borderSide: BorderSide(
                                  color: Colors.green[400]!,
                                ),
                              ),
                              focusedBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(8),
                                borderSide: BorderSide(
                                  color: Colors.green[400]!,
                                  width: 2,
                                ),
                              ),
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(8),
                              ),
                              fillColor: Colors.grey[900],
                              filled: true,
                            ),
                            validator: (value) {
                              if (value == null || value.isEmpty) {
                                return 'Please specify improvement focus';
                              }
                              return null;
                            },
                          ),
                        ],

                        const SizedBox(height: 16),
                        SizedBox(
                          width: double.infinity,
                          child: ElevatedButton.icon(
                            onPressed: (provider.isLoading) ? null : _submitApp,
                            icon:
                                provider.isLoading
                                    ? const SizedBox(
                                      width: 16,
                                      height: 16,
                                      child: CircularProgressIndicator(
                                        strokeWidth: 2,
                                        color: Colors.black,
                                      ),
                                    )
                                    : Icon(
                                      _selectedOperation == 'create_new'
                                          ? Icons.add_circle
                                          : Icons.auto_fix_high,
                                      color: Colors.black,
                                    ),
                            label: Text(
                              provider.isLoading
                                  ? 'Submitting...'
                                  : _selectedOperation == 'create_new'
                                  ? 'Create New App'
                                  : 'Improve Existing App',
                              style: TextStyle(color: Colors.black),
                            ),
                            style: ElevatedButton.styleFrom(
                              backgroundColor:
                                  _selectedOperation == 'create_new'
                                      ? Colors.yellow[700]
                                      : Colors.green[600],
                              foregroundColor: Colors.black,
                              padding: const EdgeInsets.symmetric(vertical: 12),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 20),

                // Recent Apps
                _buildRecentApps(provider),
              ],
            ),
          );
        },
      ),
    );
  }

  Widget _buildStatusHeader(ConquestAIProvider provider) {
    return Consumer<ConquestAIProvider>(
      builder: (context, provider, child) {
        final isOperating = provider.isConquestActive;
        final warpActive = false; // Removed chaos warp status
        final chaosActive = false; // Removed chaos warp status

        return Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors:
                  warpActive
                      ? [Colors.red[800]!, Colors.red[600]!]
                      : chaosActive
                      ? [Colors.purple[800]!, Colors.purple[600]!]
                      : [Colors.purple[800]!, Colors.purple[600]!],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Column(
            children: [
              Row(
                children: [
                  Icon(
                    provider.isConquestActive && isOperating
                        ? Icons.play_circle_filled
                        : Icons.pause_circle_filled,
                    color: Colors.white,
                    size: 32,
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Conquest AI Status',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        Text(
                          provider.isConquestActive
                              ? 'Active & Learning'
                              : 'Inactive',
                          style: TextStyle(color: Colors.white70, fontSize: 14),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 8,
                      vertical: 4,
                    ),
                    decoration: BoxDecoration(
                      color:
                          provider.isConquestActive && isOperating
                              ? Colors.green
                              : Colors.orange,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Text(
                      warpActive
                          ? 'WARP'
                          : provider.isConquestActive && isOperating
                          ? 'ONLINE'
                          : 'OFFLINE',
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 12,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildNotificationsPanel(ConquestAIProvider provider) {
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.1),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.notifications, color: Colors.orange),
              const SizedBox(width: 8),
              const Text(
                'Notifications',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),
              const Spacer(),
              TextButton(
                onPressed: provider.clearNotifications,
                child: const Text('Clear'),
              ),
            ],
          ),
          const SizedBox(height: 8),
          if (provider.notifications.isEmpty)
            const Text('No notifications', style: TextStyle(color: Colors.grey))
          else
            ...provider.notifications.map(
              (notification) => Padding(
                padding: const EdgeInsets.only(bottom: 4),
                child: Text(
                  '• $notification',
                  style: const TextStyle(fontSize: 14),
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildGuardrailsPanel(ConquestAIProvider provider) {
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.1),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.security, color: Colors.blue),
              const SizedBox(width: 8),
              const Text(
                'Guardrails & Health',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),
            ],
          ),
          const SizedBox(height: 12),
          _buildHealthCheck(
            'Backend Connected',
            provider.guardrails['healthChecks']['backend_connected'],
          ),
          _buildHealthCheck(
            'Learning Active',
            provider.guardrails['healthChecks']['learning_active'],
          ),
          _buildHealthCheck(
            'Git Available',
            provider.guardrails['healthChecks']['git_available'],
          ),
          _buildHealthCheck(
            'Tests Running',
            provider.guardrails['healthChecks']['tests_running'],
          ),
          const SizedBox(height: 8),
          Text(
            'Max Build Time: ${provider.guardrails['maxBuildTime']}s',
            style: const TextStyle(fontSize: 12, color: Colors.grey),
          ),
          Text(
            'Max Retries: ${provider.guardrails['maxRetries']}',
            style: const TextStyle(fontSize: 12, color: Colors.grey),
          ),
        ],
      ),
    );
  }

  Widget _buildHealthCheck(String label, bool status) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 4),
      child: Row(
        children: [
          Icon(
            status ? Icons.check_circle : Icons.error,
            color: status ? Colors.green : Colors.red,
            size: 16,
          ),
          const SizedBox(width: 8),
          Text(
            label,
            style: TextStyle(
              fontSize: 14,
              color: status ? Colors.black : Colors.red,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSubmissionForm(ConquestAIProvider provider) {
    return Consumer<ConquestAIProvider>(
      builder: (context, chaosWarpProvider, child) {
        final isOperating = provider.isConquestActive;
        final warpActive = false; // Removed chaos warp status
        final chaosActive = false; // Removed chaos warp status

        return Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: Colors.black,
            borderRadius: BorderRadius.circular(12),
            boxShadow: [
              BoxShadow(
                color: Colors.yellow[700]!.withOpacity(0.2),
                blurRadius: 8,
                offset: const Offset(0, 2),
              ),
            ],
          ),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Submit App Request',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Colors.yellow[700],
                  ),
                ),
                const SizedBox(height: 16),
                TextFormField(
                  controller: _appNameController,
                  decoration: InputDecoration(
                    labelText: 'App Name',
                    border: OutlineInputBorder(),
                    prefixIcon: Icon(Icons.apps),
                  ),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Please enter an app name';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 16),
                TextFormField(
                  controller: _appDescriptionController,
                  decoration: InputDecoration(
                    labelText: 'Description',
                    icon: Icon(
                      Icons.lightbulb_outline,
                      color: Colors.yellow[700],
                    ),
                    border: OutlineInputBorder(),
                    prefixIcon: Icon(Icons.description),
                  ),
                  maxLines: 3,
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Please enter a description';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 16),
                TextFormField(
                  controller: _appKeywordsController,
                  decoration: InputDecoration(
                    labelText: 'Keywords (comma-separated)',
                    border: OutlineInputBorder(),
                    prefixIcon: Icon(Icons.tag),
                  ),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Please enter keywords';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 16),

                // Chaos/Warp Status Warning
                if (!isOperating) ...[
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: warpActive ? Colors.red[50] : Colors.orange[50],
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(
                        color:
                            warpActive ? Colors.red[200]! : Colors.orange[200]!,
                      ),
                    ),
                    child: Row(
                      children: [
                        Icon(
                          warpActive ? Icons.block : Icons.schedule,
                          color: warpActive ? Colors.red : Colors.orange,
                          size: 20,
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Conquest AI is outside operational hours',
                                style: TextStyle(
                                  color: Colors.orange[700],
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                              SizedBox(height: 4),
                              Text(
                                'Current: $_opStart - $_opEnd',
                                style: TextStyle(
                                  color: Colors.orange[400],
                                  fontSize: 12,
                                ),
                              ),
                            ],
                          ),
                        ),
                        IconButton(
                          icon: Icon(Icons.refresh, color: Colors.orange[700]),
                          onPressed: () async {
                            await provider.clearCacheAndRefresh();
                            ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(
                                content: Text('Operational hours refreshed'),
                                backgroundColor: Colors.orange,
                              ),
                            );
                          },
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 16),
                ],

                DropdownButtonFormField<String>(
                  value: _selectedFramework,
                  items:
                      frameworks
                          .map(
                            (f) => DropdownMenuItem(value: f, child: Text(f)),
                          )
                          .toList(),
                  onChanged: (val) => setState(() => _selectedFramework = val!),
                  decoration: InputDecoration(
                    labelText: 'Framework',
                    icon: Icon(Icons.code, color: Colors.yellow[700]),
                  ),
                ),

                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton.icon(
                    onPressed:
                        (provider.isLoading || !isOperating)
                            ? null
                            : _submitApp,
                    icon:
                        provider.isLoading
                            ? const SizedBox(
                              width: 16,
                              height: 16,
                              child: CircularProgressIndicator(strokeWidth: 2),
                            )
                            : const Icon(Icons.send),
                    label: Text(
                      provider.isLoading
                          ? 'Submitting...'
                          : !isOperating
                          ? 'Operations Blocked'
                          : 'Submit to Conquest AI',
                    ),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.yellow[700],
                      foregroundColor: Colors.black,
                      padding: const EdgeInsets.symmetric(vertical: 12),
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildRecentApps(ConquestAIProvider provider) {
    final recentTemplates = provider.getRecentTemplates(limit: 5);

    if (recentTemplates.isEmpty) {
      return const SizedBox.shrink();
    }

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.black,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.1),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Recent Templates',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 12),
          ...recentTemplates.map(
            (template) => _buildTemplateCard(template, provider),
          ),
        ],
      ),
    );
  }

  Widget _buildTemplateCard(ConquestApp template, ConquestAIProvider provider) {
    return Card(
      color: Colors.black,
      child: ListTile(
        leading: CircleAvatar(
          backgroundColor: getIconColor(template.name),
          child: Icon(Icons.apps, color: Colors.white),
        ),
        title: Text(template.name, style: TextStyle(color: Colors.white)),
        subtitle: Row(
          children: [
            Text('Template ready', style: TextStyle(color: Colors.yellow[700])),
            SizedBox(width: 8),
            Icon(
              Icons.info_outline,
              color: Colors.yellow[700],
              size: 18,
            ), // Example icon
          ],
        ),
        trailing: IconButton(
          icon: Icon(Icons.code, color: Colors.yellow[700]),
          onPressed: () async {
            // Fetch code from backend and show in dialog
            final code = await provider.fetchMainCode(template.id);
            showDialog(
              context: context,
              builder:
                  (_) => AlertDialog(
                    backgroundColor: Colors.black,
                    title: Text(
                      'Main Code',
                      style: TextStyle(color: Colors.yellow[700]),
                    ),
                    content: SingleChildScrollView(
                      child: Text(
                        code,
                        style: TextStyle(
                          color: Colors.white,
                          fontFamily: 'monospace',
                        ),
                      ),
                    ),
                  ),
            );
          },
        ),
        onTap: () => provider.openTemplate(template),
      ),
    );
  }

  IconData _getTemplateIcon(String name) {
    // Simple logic: use different icons for some keywords, else default
    final lower = name.toLowerCase();
    if (lower.contains('chat')) return Icons.chat;
    if (lower.contains('shop')) return Icons.shopping_cart;
    if (lower.contains('game')) return Icons.videogame_asset;
    if (lower.contains('note')) return Icons.note;
    if (lower.contains('task')) return Icons.check_circle;
    return Icons.apps;
  }

  String _formatDate(DateTime date) {
    return '${date.day}/${date.month}/${date.year}';
  }

  void _submitApp() async {
    if (!_formKey.currentState!.validate()) {
      _showNotification(
        'Form Error',
        'Please fix the errors in the form before submitting.',
        NotificationType.error,
      );
      return;
    }

    final provider = Provider.of<ConquestAIProvider>(context, listen: false);

    // Check if operations are allowed
    if (!provider.isConquestActive) {
      String message =
          'Conquest AI is outside operational hours. Please try again during operational hours.';

      _showNotification(
        '⏰ Outside Operational Hours',
        message,
        NotificationType.warning,
      );
      return;
    }

    final keywords =
        _appKeywordsController.text
            .split(',')
            .map((e) => e.trim())
            .where((e) => e.isNotEmpty)
            .toList();

    // Show loading state
    setState(() => _showProgress = true);

    try {
      // Show initial notification
      _showNotification(
        '🚀 Starting App Creation',
        'Conquest AI is beginning to create your app...',
        NotificationType.info,
      );

      bool success;

      if (_selectedOperation == 'create_new') {
        success = await provider.submitAppRequest(
          name: _appNameController.text,
          description: _appDescriptionController.text,
          keywords: keywords,
          operationType: 'create_new',
        );
      } else {
        // Improve existing app
        success = await provider.submitAppRequest(
          name: _appNameController.text,
          description: _appDescriptionController.text,
          keywords: keywords,
          operationType: 'improve_existing',
          existingRepo: _existingRepoController.text.trim(),
          improvementFocus: _improvementFocusController.text.trim(),
        );
      }

      if (success) {
        // Clear form
        _formKey.currentState!.reset();
        _appNameController.clear();
        _appDescriptionController.clear();
        _appKeywordsController.clear();
        _existingRepoController.clear();
        _improvementFocusController.clear();
        setState(() {
          _selectedOperation = 'create_new';
        });

        // Show success notification
        _showNotification(
          '✅ App Creation Started',
          _selectedOperation == 'create_new'
              ? 'New app creation started successfully! Check "View Created Apps" for progress.'
              : 'App improvement started successfully! Check "View Created Apps" for progress.',
          NotificationType.success,
        );

        // Show success snackbar with action
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              _selectedOperation == 'create_new'
                  ? 'New app creation started successfully!'
                  : 'App improvement started successfully!',
            ),
            backgroundColor: Colors.green,
            duration: const Duration(seconds: 3),
            action: SnackBarAction(
              label: 'View Apps',
              textColor: Colors.white,
              onPressed: () {
                Navigator.pushNamed(context, '/conquest-apps');
              },
            ),
          ),
        );
      } else {
        setState(() => _showProgress = false);
        _showNotification(
          '❌ App Creation Failed',
          'Failed to submit app request. Please try again.',
          NotificationType.error,
        );
      }
    } catch (e) {
      setState(() => _showProgress = false);
      if (e.toString().contains('repeat a known error')) {
        _showRepeatedErrorDialog(context);
      } else {
        _showNotification(
          '❌ App Creation Error',
          'An error occurred while creating your app: ${e.toString()}',
          NotificationType.error,
        );
      }
    }
  }

  void _showNotification(String title, String message, NotificationType type) {
    final color =
        type == NotificationType.success
            ? Colors.green
            : type == NotificationType.error
            ? Colors.red
            : type == NotificationType.warning
            ? Colors.orange
            : Colors.blue;

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              title,
              style: const TextStyle(
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
            ),
            const SizedBox(height: 4),
            Text(message, style: const TextStyle(color: Colors.white)),
          ],
        ),
        backgroundColor: color,
        duration: const Duration(seconds: 4),
        behavior: SnackBarBehavior.floating,
        margin: const EdgeInsets.all(16),
      ),
    );
  }

  void _showAppDetails(ConquestApp app, ConquestAIProvider provider) {
    showDialog(
      context: context,
      builder:
          (context) => AlertDialog(
            title: Text(app.name),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Status: ${app.status}'),
                if (app.errorMessage != null)
                  Text('Error: ${app.errorMessage}'),
                Text('Created: ${_formatDate(app.createdAt)}'),
              ],
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.of(context).pop(),
                child: const Text('Close'),
              ),
              if (app.status == 'failed')
                ElevatedButton(
                  onPressed: () {
                    provider.forceConquestWork(app.id);
                    Navigator.of(context).pop();
                  },
                  child: const Text('Retry'),
                ),
            ],
          ),
    );
  }

  void _showRepeatedErrorDialog(BuildContext context) {
    showDialog(
      context: context,
      builder:
          (context) => AlertDialog(
            title: Text('Repeated Error Detected'),
            content: Text(
              'This app build was blocked because it would repeat a known error. Please modify your request or fix the underlying issue.',
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.of(context).pop(),
                child: Text('OK'),
              ),
            ],
          ),
    );
  }

  void _showCreateNewAppDialog(BuildContext context) {
    showDialog(
      context: context,
      builder:
          (context) => AlertDialog(
            backgroundColor: Colors.black,
            title: Text(
              'Create New APK',
              style: TextStyle(
                color: Colors.green[400],
                fontWeight: FontWeight.bold,
              ),
            ),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Conquest AI will:',
                  style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 8),
                _buildFeatureItem(
                  '🎯 Generate new app concept',
                  Colors.green[400]!,
                ),
                _buildFeatureItem(
                  '📱 Create Flutter project structure',
                  Colors.green[400]!,
                ),
                _buildFeatureItem(
                  '🔧 Generate complete source code',
                  Colors.green[400]!,
                ),
                _buildFeatureItem('📦 Build APK file', Colors.green[400]!),
                _buildFeatureItem(
                  '📤 Push to GitHub repository',
                  Colors.green[400]!,
                ),
                _buildFeatureItem(
                  '📲 Provide download link',
                  Colors.green[400]!,
                ),
                const SizedBox(height: 16),
                Text(
                  'This will create a completely new app from scratch!',
                  style: TextStyle(color: Colors.yellow[700], fontSize: 12),
                ),
              ],
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.of(context).pop(),
                child: Text('Cancel', style: TextStyle(color: Colors.grey)),
              ),
              ElevatedButton(
                onPressed: () {
                  Navigator.of(context).pop();
                  _showCreateNewAppForm(context);
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.green[400],
                ),
                child: Text(
                  'Start Creating',
                  style: TextStyle(
                    color: Colors.black,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ],
          ),
    );
  }

  void _showImproveAppDialog(BuildContext context) {
    showDialog(
      context: context,
      builder:
          (context) => AlertDialog(
            backgroundColor: Colors.black,
            title: Text(
              'Improve Existing App',
              style: TextStyle(
                color: Colors.blue[400],
                fontWeight: FontWeight.bold,
              ),
            ),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Conquest AI will:',
                  style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 8),
                _buildFeatureItem(
                  '🔍 Analyze existing code',
                  Colors.blue[400]!,
                ),
                _buildFeatureItem('💡 Suggest improvements', Colors.blue[400]!),
                _buildFeatureItem('🚀 Add new features', Colors.blue[400]!),
                _buildFeatureItem('🐛 Fix bugs and issues', Colors.blue[400]!),
                _buildFeatureItem('📈 Optimize performance', Colors.blue[400]!),
                _buildFeatureItem('📦 Update APK', Colors.blue[400]!),
                const SizedBox(height: 16),
                Text(
                  'This will enhance an existing app with new features and improvements!',
                  style: TextStyle(color: Colors.yellow[700], fontSize: 12),
                ),
              ],
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.of(context).pop(),
                child: Text('Cancel', style: TextStyle(color: Colors.grey)),
              ),
              ElevatedButton(
                onPressed: () {
                  Navigator.of(context).pop();
                  _showImproveAppForm(context);
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.blue[400],
                ),
                child: Text(
                  'Start Improving',
                  style: TextStyle(
                    color: Colors.black,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ],
          ),
    );
  }

  Widget _buildFeatureItem(String text, Color color) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 2),
      child: Row(
        children: [
          Icon(Icons.check_circle, color: color, size: 16),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              text,
              style: TextStyle(color: Colors.white, fontSize: 14),
            ),
          ),
        ],
      ),
    );
  }

  void _showCreateNewAppForm(BuildContext context) {
    // Navigate to the existing form but with "Create New" mode
    setState(() {
      _appNameController.clear();
      _appDescriptionController.clear();
      _appKeywordsController.clear();
    });

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Fill out the form below to create a new APK!'),
        backgroundColor: Colors.green[400],
        duration: Duration(seconds: 3),
      ),
    );
  }

  void _showImproveAppForm(BuildContext context) {
    // Show a dialog to select existing app to improve
    showDialog(
      context: context,
      builder:
          (context) => AlertDialog(
            backgroundColor: Colors.black,
            title: Text(
              'Select App to Improve',
              style: TextStyle(
                color: Colors.blue[400],
                fontWeight: FontWeight.bold,
              ),
            ),
            content: Container(
              width: double.maxFinite,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    'Choose an existing app to improve:',
                    style: TextStyle(color: Colors.white),
                  ),
                  const SizedBox(height: 16),
                  // This would show a list of existing apps
                  Text(
                    'No existing apps found. Create a new app first!',
                    style: TextStyle(color: Colors.grey),
                  ),
                ],
              ),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.of(context).pop(),
                child: Text('Cancel', style: TextStyle(color: Colors.grey)),
              ),
              ElevatedButton(
                onPressed: () {
                  Navigator.of(context).pop();
                  _showCreateNewAppForm(context);
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.blue[400],
                ),
                child: Text(
                  'Create New Instead',
                  style: TextStyle(
                    color: Colors.black,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ],
          ),
    );
  }
}
