import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/proposal_provider.dart';
import '../models/ai_proposal.dart';
import 'dart:async';

class ProposalApprovalScreen extends StatefulWidget {
  static const String routeName = '/proposal_approval';
  const ProposalApprovalScreen({Key? key}) : super(key: key);

  @override
  State<ProposalApprovalScreen> createState() => _ProposalApprovalScreenState();
}

class _ProposalApprovalScreenState extends State<ProposalApprovalScreen>
    with TickerProviderStateMixin {
  late AnimationController _fadeController;
  late AnimationController _slideController;
  String _selectedCategory = 'All';
  String _selectedStatus = 'All';
  Timer? _refreshTimer;

  final List<String> _categories = ['All', 'Sandbox', 'Guardian', 'Imperium'];
  final List<String> _statuses = [
    'All',
    'Pending',
    'Approved',
    'Testing',
    'Rejected',
  ];

  @override
  void initState() {
    super.initState();
    _fadeController = AnimationController(
      duration: const Duration(milliseconds: 800),
      vsync: this,
    );
    _slideController = AnimationController(
      duration: const Duration(milliseconds: 600),
      vsync: this,
    );

    WidgetsBinding.instance.addPostFrameCallback((_) {
      _fadeController.forward();
      _slideController.forward();
      _startAutoRefresh();
    });
  }

  void _startAutoRefresh() {
    _refreshTimer = Timer.periodic(const Duration(seconds: 30), (_) {
      if (mounted) {
        Provider.of<ProposalProvider>(context, listen: false).fetchProposals();
      }
    });
  }

  @override
  void dispose() {
    _fadeController.dispose();
    _slideController.dispose();
    _refreshTimer?.cancel();
    super.dispose();
  }

  List<AIProposal> _getFilteredProposals(ProposalProvider provider) {
    var proposals = provider.proposals.toList();

    if (_selectedCategory != 'All') {
      proposals =
          proposals.where((p) => p.aiType == _selectedCategory).toList();
    }

    if (_selectedStatus != 'All') {
      final status = _getStatusFromString(_selectedStatus);
      proposals = proposals.where((p) => p.status == status).toList();
    }

    return proposals;
  }

  ProposalStatus _getStatusFromString(String status) {
    switch (status) {
      case 'Pending':
        return ProposalStatus.pending;
      case 'Approved':
        return ProposalStatus.approved;
      case 'Testing':
        return ProposalStatus.testing;
      case 'Rejected':
        return ProposalStatus.rejected;
      default:
        return ProposalStatus.pending;
    }
  }

  Color _getStatusColor(ProposalStatus status) {
    switch (status) {
      case ProposalStatus.pending:
        return Colors.orange;
      case ProposalStatus.approved:
        return Colors.green;
      case ProposalStatus.testing:
        return Colors.blue;
      case ProposalStatus.rejected:
        return Colors.red;
      case ProposalStatus.applied:
        return Colors.blue;
      case ProposalStatus.testPassed:
        return Colors.green;
      case ProposalStatus.testFailed:
        return Colors.red;
      default:
        return Colors.grey;
    }
  }

  Color _getAITypeColor(String aiType) {
    switch (aiType.toLowerCase()) {
      case 'sandbox':
        return Colors.purple;
      case 'guardian':
        return Colors.blue;
      case 'imperium':
        return Colors.orange;
      default:
        return Colors.grey;
    }
  }

  IconData _getAITypeIcon(String aiType) {
    switch (aiType.toLowerCase()) {
      case 'sandbox':
        return Icons.science;
      case 'guardian':
        return Icons.security;
      case 'imperium':
        return Icons.psychology;
      default:
        return Icons.smart_toy;
    }
  }

  Color _getConfidenceColor(double confidence) {
    if (confidence >= 0.8) {
      return Colors.green;
    } else if (confidence >= 0.5) {
      return Colors.orange;
    } else {
      return Colors.red;
    }
  }

  String _generateDescription(AIProposal proposal) {
    if (proposal.description != null && proposal.description!.isNotEmpty) {
      return proposal.description!;
    }

    // Generate description from code changes
    final oldLines = proposal.oldCode.split('\n').length;
    final newLines = proposal.newCode.split('\n').length;
    final addedLines = newLines - oldLines;

    String changeType = '';
    if (addedLines > 0) {
      changeType = 'adds $addedLines line${addedLines > 1 ? 's' : ''}';
    } else if (addedLines < 0) {
      changeType =
          'removes ${addedLines.abs()} line${addedLines.abs() > 1 ? 's' : ''}';
    } else {
      changeType = 'refactors';
    }

    String fileType = '';
    if (proposal.filePath.contains('widget')) {
      fileType = 'UI widget';
    } else if (proposal.filePath.contains('provider')) {
      fileType = 'state management';
    } else if (proposal.filePath.contains('service')) {
      fileType = 'service';
    } else if (proposal.filePath.contains('model')) {
      fileType = 'data model';
    } else if (proposal.filePath.contains('util')) {
      fileType = 'utility';
    } else {
      fileType = 'code';
    }

    return 'This proposal $changeType to the $fileType in ${proposal.filePath}. The ${proposal.aiType} AI suggests this improvement to enhance functionality or fix issues.';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).colorScheme.background,
      appBar: AppBar(
        title: const Text(
          'AI Proposals',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        backgroundColor: Theme.of(context).colorScheme.primary,
        foregroundColor: Colors.white,
        elevation: 0,
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: () {
              Provider.of<ProposalProvider>(
                context,
                listen: false,
              ).fetchProposals();
            },
          ),
        ],
      ),
      body: Consumer<ProposalProvider>(
        builder: (context, provider, child) {
          final proposals = _getFilteredProposals(provider);

          return Column(
            children: [
              // Filter Section
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Theme.of(context).colorScheme.surface,
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.1),
                      blurRadius: 4,
                      offset: const Offset(0, 2),
                    ),
                  ],
                ),
                child: Column(
                  children: [
                    // Category Filter
                    Row(
                      children: [
                        const Icon(Icons.category, size: 20),
                        const SizedBox(width: 8),
                        const Text(
                          'AI Type:',
                          style: TextStyle(fontWeight: FontWeight.w600),
                        ),
                        const SizedBox(width: 16),
                        Expanded(
                          child: SingleChildScrollView(
                            scrollDirection: Axis.horizontal,
                            child: Row(
                              children:
                                  _categories.map((category) {
                                    final isSelected =
                                        _selectedCategory == category;
                                    return Padding(
                                      padding: const EdgeInsets.only(right: 8),
                                      child: FilterChip(
                                        label: Text(category),
                                        selected: isSelected,
                                        onSelected: (selected) {
                                          setState(() {
                                            _selectedCategory = category;
                                          });
                                        },
                                        backgroundColor: Colors.grey[200],
                                        selectedColor: _getAITypeColor(
                                          category,
                                        ).withOpacity(0.2),
                                        checkmarkColor: _getAITypeColor(
                                          category,
                                        ),
                                      ),
                                    );
                                  }).toList(),
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    // Status Filter
                    Row(
                      children: [
                        const Icon(Icons.filter_list, size: 20),
                        const SizedBox(width: 8),
                        const Text(
                          'Status:',
                          style: TextStyle(fontWeight: FontWeight.w600),
                        ),
                        const SizedBox(width: 16),
                        Expanded(
                          child: SingleChildScrollView(
                            scrollDirection: Axis.horizontal,
                            child: Row(
                              children:
                                  _statuses.map((status) {
                                    final isSelected =
                                        _selectedStatus == status;
                                    return Padding(
                                      padding: const EdgeInsets.only(right: 8),
                                      child: FilterChip(
                                        label: Text(status),
                                        selected: isSelected,
                                        onSelected: (selected) {
                                          setState(() {
                                            _selectedStatus = status;
                                          });
                                        },
                                        backgroundColor: Colors.grey[200],
                                        selectedColor: _getStatusColor(
                                          _getStatusFromString(status),
                                        ).withOpacity(0.2),
                                        checkmarkColor: _getStatusColor(
                                          _getStatusFromString(status),
                                        ),
                                      ),
                                    );
                                  }).toList(),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),

              // Proposals List
              Expanded(
                child:
                    proposals.isEmpty
                        ? _buildEmptyState()
                        : FadeTransition(
                          opacity: _fadeController,
                          child: SlideTransition(
                            position: Tween<Offset>(
                              begin: const Offset(0, 0.1),
                              end: Offset.zero,
                            ).animate(_slideController),
                            child: ListView.builder(
                              padding: const EdgeInsets.all(16),
                              itemCount: proposals.length,
                              itemBuilder: (context, index) {
                                final proposal = proposals[index];
                                return _buildProposalCard(proposal, provider);
                              },
                            ),
                          ),
                        ),
              ),
            ],
          );
        },
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.inbox_outlined, size: 64, color: Colors.grey[400]),
          const SizedBox(height: 16),
          Text(
            'No proposals found',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w600,
              color: Colors.grey[600],
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'Proposals will appear here when AI systems generate suggestions',
            style: TextStyle(color: Colors.grey[500]),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  Widget _buildProposalCard(AIProposal proposal, ProposalProvider provider) {
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surface,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.1),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        children: [
          // Header
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: _getAITypeColor(proposal.aiType).withOpacity(0.1),
              borderRadius: const BorderRadius.only(
                topLeft: Radius.circular(12),
                topRight: Radius.circular(12),
              ),
            ),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: _getAITypeColor(proposal.aiType),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Icon(
                    _getAITypeIcon(proposal.aiType),
                    color: Colors.white,
                    size: 20,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        proposal.aiType,
                        style: const TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 16,
                        ),
                      ),
                      Text(
                        proposal.filePath,
                        style: TextStyle(color: Colors.grey[600], fontSize: 12),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 8,
                    vertical: 4,
                  ),
                  decoration: BoxDecoration(
                    color: _getStatusColor(proposal.status),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(
                    proposal.status.toString().split('.').last.toUpperCase(),
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 10,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ],
            ),
          ),

          // Content
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Improvement Type
                if (proposal.improvementType != 'general')
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 8,
                      vertical: 4,
                    ),
                    decoration: BoxDecoration(
                      color: Colors.blue.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Text(
                      proposal.improvementType.toUpperCase(),
                      style: const TextStyle(
                        color: Colors.blue,
                        fontSize: 10,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),

                const SizedBox(height: 8),

                // Confidence Indicator
                Row(
                  children: [
                    Icon(Icons.psychology, size: 16, color: Colors.grey[600]),
                    const SizedBox(width: 4),
                    Text(
                      'AI Confidence:',
                      style: TextStyle(
                        fontSize: 12,
                        color: Colors.grey[600],
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: LinearProgressIndicator(
                        value: proposal.confidence ?? 0.5,
                        backgroundColor: Colors.grey[300],
                        valueColor: AlwaysStoppedAnimation<Color>(
                          _getConfidenceColor(proposal.confidence ?? 0.5),
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Text(
                      '${((proposal.confidence ?? 0.5) * 100).toInt()}%',
                      style: TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.bold,
                        color: _getConfidenceColor(proposal.confidence ?? 0.5),
                      ),
                    ),
                  ],
                ),

                const SizedBox(height: 12),

                // Description Section - Hide during testing
                if (proposal.status != ProposalStatus.testing)
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'Proposal Description',
                        style: TextStyle(
                          fontWeight: FontWeight.w600,
                          fontSize: 14,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Container(
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: Colors.blue[50],
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(color: Colors.blue[200]!),
                        ),
                        child: Text(
                          _generateDescription(proposal),
                          style: TextStyle(
                            fontSize: 13,
                            color: Colors.blue[800],
                            height: 1.4,
                          ),
                        ),
                      ),
                      const SizedBox(height: 12),
                    ],
                  ),

                // Testing Status Indicator
                if (proposal.status == ProposalStatus.testing)
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: Colors.blue[50],
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: Colors.blue[200]!),
                    ),
                    child: Row(
                      children: [
                        SizedBox(
                          width: 20,
                          height: 20,
                          child: CircularProgressIndicator(
                            strokeWidth: 2,
                            valueColor: AlwaysStoppedAnimation<Color>(
                              Colors.blue[700]!,
                            ),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text(
                                'Testing in Progress',
                                style: TextStyle(
                                  fontWeight: FontWeight.w600,
                                  fontSize: 14,
                                  color: Colors.blue,
                                ),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                'The proposal is being tested to ensure it works correctly...',
                                style: TextStyle(
                                  fontSize: 12,
                                  color: Colors.blue[600],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),

                // Code Preview
                if (proposal.oldCode.isNotEmpty || proposal.newCode.isNotEmpty)
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'Code Changes',
                        style: TextStyle(
                          fontWeight: FontWeight.w600,
                          fontSize: 14,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Container(
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: Colors.grey[100],
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            if (proposal.oldCode.isNotEmpty) ...[
                              const Text(
                                'Before:',
                                style: TextStyle(
                                  fontWeight: FontWeight.w600,
                                  fontSize: 12,
                                  color: Colors.red,
                                ),
                              ),
                              Text(
                                proposal.oldCode,
                                style: const TextStyle(fontSize: 12),
                                maxLines: 3,
                                overflow: TextOverflow.ellipsis,
                              ),
                              const SizedBox(height: 8),
                            ],
                            if (proposal.newCode.isNotEmpty) ...[
                              const Text(
                                'After:',
                                style: TextStyle(
                                  fontWeight: FontWeight.w600,
                                  fontSize: 12,
                                  color: Colors.green,
                                ),
                              ),
                              Text(
                                proposal.newCode,
                                style: const TextStyle(fontSize: 12),
                                maxLines: 3,
                                overflow: TextOverflow.ellipsis,
                              ),
                            ],
                          ],
                        ),
                      ),
                    ],
                  ),

                const SizedBox(height: 16),

                // Action Buttons - Only for pending proposals
                if (proposal.status == ProposalStatus.pending)
                  Row(
                    children: [
                      Expanded(
                        child: ElevatedButton.icon(
                          onPressed:
                              () => provider.approveProposal(proposal.id),
                          icon: const Icon(Icons.check, size: 18),
                          label: const Text('Approve'),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.green,
                            foregroundColor: Colors.white,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(8),
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: ElevatedButton.icon(
                          onPressed: () => provider.rejectProposal(proposal.id),
                          icon: const Icon(Icons.close, size: 18),
                          label: const Text('Reject'),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.red,
                            foregroundColor: Colors.white,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(8),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),

                // Testing Status Message
                if (proposal.status == ProposalStatus.testing)
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    decoration: BoxDecoration(
                      color: Colors.blue[50],
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: Colors.blue[200]!),
                    ),
                    child: const Text(
                      'This proposal is currently being tested',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: Colors.blue,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
