import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/ai_growth_analytics_provider.dart';
import '../widgets/ai_growth_analytics_dashboard.dart';

/// AI Growth Analytics Screen
/// Main screen for viewing AI growth analytics, failures, successes, and learning insights
class AIGrowthAnalyticsScreen extends StatefulWidget {
  const AIGrowthAnalyticsScreen({Key? key}) : super(key: key);

  @override
  State<AIGrowthAnalyticsScreen> createState() =>
      _AIGrowthAnalyticsScreenState();
}

class _AIGrowthAnalyticsScreenState extends State<AIGrowthAnalyticsScreen> {
  @override
  void initState() {
    super.initState();
    // Initialize the provider when the screen loads
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final provider = Provider.of<AIGrowthAnalyticsProvider>(
        context,
        listen: false,
      );
      provider.initialize();
    });
  }

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (context) => AIGrowthAnalyticsProvider(),
      child: Consumer<AIGrowthAnalyticsProvider>(
        builder: (context, provider, child) {
          return Scaffold(
            backgroundColor: Colors.grey[900],
            body: Stack(
              children: [
                // Main dashboard
                AIGrowthAnalyticsDashboard(
                  connectionIndicator: _buildConnectionIndicator(provider),
                ),

                // Loading overlay
                if (provider.isLoading)
                  Container(
                    color: Colors.black54,
                    child: const Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          CircularProgressIndicator(
                            valueColor: AlwaysStoppedAnimation<Color>(
                              Colors.blue,
                            ),
                          ),
                          SizedBox(height: 16),
                          Text(
                            'Loading AI Growth Analytics...',
                            style: TextStyle(color: Colors.white, fontSize: 16),
                          ),
                        ],
                      ),
                    ),
                  ),

                // Error overlay
                if (provider.error != null)
                  Container(
                    color: Colors.black54,
                    child: Center(
                      child: Card(
                        color: Colors.red[900],
                        child: Padding(
                          padding: const EdgeInsets.all(20),
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              const Icon(
                                Icons.error,
                                color: Colors.white,
                                size: 48,
                              ),
                              const SizedBox(height: 16),
                              const Text(
                                'Error Loading Analytics',
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              const SizedBox(height: 8),
                              Text(
                                provider.error!,
                                style: const TextStyle(
                                  color: Colors.white70,
                                  fontSize: 14,
                                ),
                                textAlign: TextAlign.center,
                              ),
                              const SizedBox(height: 16),
                              ElevatedButton(
                                onPressed: () => provider.refresh(),
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: Colors.white,
                                  foregroundColor: Colors.red[900],
                                ),
                                child: const Text('Retry'),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
              ],
            ),
            floatingActionButton: FloatingActionButton(
              onPressed: () => provider.refresh(),
              backgroundColor: Colors.blue,
              child: const Icon(Icons.refresh, color: Colors.white),
            ),
          );
        },
      ),
    );
  }

  Widget _buildConnectionIndicator(AIGrowthAnalyticsProvider provider) {
    return Container(
      width: 12,
      height: 12,
      margin: const EdgeInsets.only(right: 16),
      decoration: BoxDecoration(
        color: provider.error != null ? Colors.red : Colors.green,
        shape: BoxShape.circle,
      ),
    );
  }
}
