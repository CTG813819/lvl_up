import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';
import '../providers/conquest_ai_provider.dart';
import '../models/conquest_app.dart';
import 'dart:async';

class ConquestAppsScreen extends StatefulWidget {
  static const String routeName = '/conquest-apps';

  const ConquestAppsScreen({Key? key}) : super(key: key);

  @override
  State<ConquestAppsScreen> createState() => _ConquestAppsScreenState();
}

class _ConquestAppsScreenState extends State<ConquestAppsScreen>
    with TickerProviderStateMixin {
  late AnimationController _fadeAnimationController;
  late AnimationController _slideAnimationController;
  String _selectedCategory = 'All';
  String _selectedSortBy = 'Date Created';
  String _selectedStatus = 'All';
  List<String> _categories = ['All'];
  List<String> _sortOptions = [
    'Date Created',
    'Name',
    'Status',
    'Category',
    'Confidence',
  ];
  List<String> _statusOptions = [
    'All',
    'Completed',
    'Pending',
    'Failed',
    'In Progress',
  ];
  Timer? _refreshTimer;
  bool _isLoading = false;
  bool _showAdvancedFilters = false;
  String _searchQuery = '';
  bool _showOnlyDownloadable = false;
  bool _showOnlyTested = false;

  // Enhanced categories with descriptions
  final Map<String, Map<String, dynamic>> _categoryInfo = {
    'All': {
      'icon': Icons.apps,
      'color': Colors.grey,
      'description': 'All applications',
    },
    'Games': {
      'icon': Icons.videogame_asset,
      'color': Colors.purple,
      'description': 'Gaming and entertainment apps',
    },
    'Social': {
      'icon': Icons.people,
      'color': Colors.blue,
      'description': 'Social networking and communication',
    },
    'Health & Fitness': {
      'icon': Icons.fitness_center,
      'color': Colors.green,
      'description': 'Health tracking and fitness',
    },
    'Productivity': {
      'icon': Icons.work,
      'color': Colors.orange,
      'description': 'Work and productivity tools',
    },
    'Education': {
      'icon': Icons.school,
      'color': Colors.indigo,
      'description': 'Learning and educational apps',
    },
    'Finance': {
      'icon': Icons.account_balance_wallet,
      'color': Colors.teal,
      'description': 'Financial and banking apps',
    },
    'Entertainment': {
      'icon': Icons.music_note,
      'color': Colors.pink,
      'description': 'Media and entertainment',
    },
    'Travel': {
      'icon': Icons.flight,
      'color': Colors.cyan,
      'description': 'Travel and navigation apps',
    },
    'Shopping': {
      'icon': Icons.shopping_cart,
      'color': Colors.amber,
      'description': 'E-commerce and shopping',
    },
    'News': {
      'icon': Icons.article,
      'color': Colors.red,
      'description': 'News and information apps',
    },
    'Utilities': {
      'icon': Icons.build,
      'color': Colors.brown,
      'description': 'Utility and system tools',
    },
    'Photography': {
      'icon': Icons.camera_alt,
      'color': Colors.deepPurple,
      'description': 'Photo and video editing',
    },
    'Sports': {
      'icon': Icons.sports_soccer,
      'color': Colors.lime,
      'description': 'Sports and recreation',
    },
    'Food & Dining': {
      'icon': Icons.restaurant,
      'color': Colors.deepOrange,
      'description': 'Food delivery and dining',
    },
    'Music': {
      'icon': Icons.music_note,
      'color': Colors.purple,
      'description': 'Music streaming and creation',
    },
    'Weather': {
      'icon': Icons.wb_sunny,
      'color': Colors.yellow,
      'description': 'Weather and climate apps',
    },
    'General': {
      'icon': Icons.apps,
      'color': Colors.grey,
      'description': 'General purpose applications',
    },
  };

  @override
  void initState() {
    super.initState();
    _fadeAnimationController = AnimationController(
      duration: const Duration(milliseconds: 800),
      vsync: this,
    );
    _slideAnimationController = AnimationController(
      duration: const Duration(milliseconds: 600),
      vsync: this,
    );

    WidgetsBinding.instance.addPostFrameCallback((_) async {
      final provider = Provider.of<ConquestAIProvider>(context, listen: false);
      await provider.initialize();
      await _loadApps();
      await provider.fetchEnhancedStatistics(); // Fetch enhanced statistics
      _fadeAnimationController.forward();
      _slideAnimationController.forward();

      // Refresh every 30 seconds
      _refreshTimer = Timer.periodic(Duration(seconds: 30), (_) async {
        await _loadApps();
        await provider.fetchEnhancedStatistics(); // Refresh enhanced statistics
      });
    });
  }

  @override
  void dispose() {
    _fadeAnimationController.dispose();
    _slideAnimationController.dispose();
    _refreshTimer?.cancel();
    super.dispose();
  }

  Future<void> _loadApps() async {
    if (_isLoading) return;

    setState(() => _isLoading = true);

    try {
      final provider = Provider.of<ConquestAIProvider>(context, listen: false);
      await provider.fetchDeployments();

      // Update categories
      final apps = provider.deployments;
      final categories = <String>{'All'};
      for (final app in apps) {
        if (app.category != null) {
          categories.add(app.category!);
        }
      }

      setState(() {
        _categories = categories.toList()..sort();
        _isLoading = false;
      });

      // Show notification if no apps found
      if (apps.isEmpty) {
        _showNotification(
          'No apps have been created yet. Try creating a new app in the Conquest AI section.',
          NotificationType.info,
        );
      } else {
        _showNotification(
          'Successfully loaded ${apps.length} apps',
          NotificationType.success,
        );
      }
    } catch (e) {
      setState(() => _isLoading = false);
      _showNotification('Failed to load apps: $e', NotificationType.error);
    }
  }

  List<ConquestApp> _getFilteredAndSortedApps() {
    final provider = Provider.of<ConquestAIProvider>(context, listen: false);
    List<ConquestApp> apps = provider.deployments;

    // Apply category filter
    if (_selectedCategory != 'All') {
      apps = apps.where((app) => app.category == _selectedCategory).toList();
    }

    // Apply status filter
    if (_selectedStatus != 'All') {
      apps =
          apps
              .where(
                (app) =>
                    app.status.toLowerCase() == _selectedStatus.toLowerCase(),
              )
              .toList();
    }

    // Apply search filter
    if (_searchQuery.isNotEmpty) {
      apps =
          apps
              .where(
                (app) =>
                    app.name.toLowerCase().contains(
                      _searchQuery.toLowerCase(),
                    ) ||
                    app.description.toLowerCase().contains(
                      _searchQuery.toLowerCase(),
                    ) ||
                    app.keywords.any(
                      (keyword) => keyword.toLowerCase().contains(
                        _searchQuery.toLowerCase(),
                      ),
                    ),
              )
              .toList();
    }

    // Apply downloadable filter
    if (_showOnlyDownloadable) {
      apps = apps.where((app) => app.apkUrl != null).toList();
    }

    // Apply tested filter
    if (_showOnlyTested) {
      apps =
          apps
              .where(
                (app) => app.testStatus != null && app.testStatus!.isNotEmpty,
              )
              .toList();
    }

    // Apply sorting
    switch (_selectedSortBy) {
      case 'Date Created':
        apps.sort((a, b) => b.createdAt.compareTo(a.createdAt));
        break;
      case 'Name':
        apps.sort((a, b) => a.name.compareTo(b.name));
        break;
      case 'Status':
        apps.sort((a, b) => a.status.compareTo(b.status));
        break;
      case 'Category':
        apps.sort((a, b) => (a.category ?? '').compareTo(b.category ?? ''));
        break;
      case 'Confidence':
        apps.sort(
          (a, b) => (b.confidence ?? 0.0).compareTo(a.confidence ?? 0.0),
        );
        break;
    }

    return apps;
  }

  void _showNotification(String message, NotificationType type) {
    final color =
        type == NotificationType.success
            ? Colors.green
            : type == NotificationType.error
            ? Colors.red
            : type == NotificationType.warning
            ? Colors.orange
            : Colors.blue;

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            Icon(
              type == NotificationType.success
                  ? Icons.check_circle
                  : type == NotificationType.error
                  ? Icons.error
                  : type == NotificationType.warning
                  ? Icons.warning
                  : Icons.info,
              color: Colors.white,
            ),
            SizedBox(width: 8),
            Expanded(child: Text(message)),
          ],
        ),
        backgroundColor: color,
        duration: Duration(seconds: type == NotificationType.error ? 5 : 3),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        title: Text(
          'Conquest AI Apps',
          style: TextStyle(
            color: Colors.yellow[700],
            fontWeight: FontWeight.bold,
          ),
        ),
        backgroundColor: Colors.black,
        iconTheme: IconThemeData(color: Colors.yellow[700]),
        actions: [
          IconButton(
            icon: Icon(Icons.search, color: Colors.yellow[700]),
            onPressed: () => _showSearchDialog(),
          ),
          IconButton(
            icon: Icon(Icons.filter_list, color: Colors.yellow[700]),
            onPressed:
                () => setState(
                  () => _showAdvancedFilters = !_showAdvancedFilters,
                ),
          ),
          IconButton(
            icon: Icon(Icons.refresh, color: Colors.yellow[700]),
            onPressed: _loadApps,
          ),
        ],
      ),
      body: Consumer<ConquestAIProvider>(
        builder: (context, provider, child) {
          final apps = _getFilteredAndSortedApps();

          return FadeTransition(
            opacity: _fadeAnimationController,
            child: Column(
              children: [
                // Enhanced Stats Header
                _buildEnhancedStatsHeader(provider, apps),

                // Advanced Filters
                if (_showAdvancedFilters) _buildAdvancedFilters(),

                // Category Filter with enhanced design
                _buildEnhancedCategoryFilter(),

                // Apps List
                Expanded(
                  child:
                      _isLoading
                          ? Center(
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                CircularProgressIndicator(
                                  color: Colors.yellow[700],
                                ),
                                SizedBox(height: 16),
                                Text(
                                  'Loading AI-created apps...',
                                  style: TextStyle(color: Colors.grey[400]),
                                ),
                              ],
                            ),
                          )
                          : apps.isEmpty
                          ? _buildEnhancedEmptyState()
                          : _buildEnhancedAppsList(apps),
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  Widget _buildEnhancedStatsHeader(
    ConquestAIProvider provider,
    List<ConquestApp> apps,
  ) {
    final stats = provider.comprehensiveStats;

    final totalApps = stats['totalApps'] as int;
    final completedApps = stats['completedApps'] as int;
    final pendingApps = stats['pendingApps'] as int;
    final failedApps = stats['failedApps'] as int;
    final testedApps = stats['testedApps'] as int;
    final testedPassedApps = stats['testedPassedApps'] as int;
    final testedFailedApps = stats['testedFailedApps'] as int;
    final downloadableApps =
        provider.deployments.where((app) => app.apkUrl != null).length;
    final testingApps = stats['testingApps'] as int;

    return Container(
      margin: EdgeInsets.all(16),
      padding: EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [Colors.grey[900]!, Colors.grey[800]!],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.yellow[700]!, width: 2),
        boxShadow: [
          BoxShadow(
            color: Colors.yellow[700]!.withOpacity(0.3),
            blurRadius: 10,
            spreadRadius: 2,
          ),
        ],
      ),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Conquest AI Statistics',
                style: TextStyle(
                  color: Colors.yellow[700],
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Container(
                padding: EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                  color: Colors.yellow[700],
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Text(
                  '${apps.length} filtered',
                  style: TextStyle(
                    color: Colors.black,
                    fontWeight: FontWeight.bold,
                    fontSize: 12,
                  ),
                ),
              ),
            ],
          ),
          SizedBox(height: 16),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              _buildEnhancedStatItem(
                'Total',
                totalApps.toString(),
                Colors.blue,
                Icons.apps,
              ),
              _buildEnhancedStatItem(
                'Completed',
                completedApps.toString(),
                Colors.green,
                Icons.check_circle,
              ),
              _buildEnhancedStatItem(
                'Pending',
                pendingApps.toString(),
                Colors.orange,
                Icons.schedule,
              ),
              _buildEnhancedStatItem(
                'Failed',
                failedApps.toString(),
                Colors.red,
                Icons.error,
              ),
            ],
          ),
          SizedBox(height: 12),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              _buildEnhancedStatItem(
                'Downloadable',
                downloadableApps.toString(),
                Colors.cyan,
                Icons.download,
              ),
              _buildEnhancedStatItem(
                'Tested',
                testedApps.toString(),
                Colors.purple,
                Icons.science,
              ),
              _buildEnhancedStatItem(
                'Testing',
                testingApps.toString(),
                Colors.amber,
                Icons.hourglass_top,
              ),
            ],
          ),
          SizedBox(height: 12),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              _buildEnhancedStatItem(
                'Tests Passed',
                testedPassedApps.toString(),
                Colors.green,
                Icons.check_circle_outline,
              ),
              _buildEnhancedStatItem(
                'Tests Failed',
                testedFailedApps.toString(),
                Colors.red,
                Icons.cancel_outlined,
              ),
            ],
          ),
          // Enhanced Statistics Section
          if (provider.enhancedStats != null) ...[
            SizedBox(height: 16),
            _buildEnhancedStatisticsSection(provider.enhancedStats!),
          ],
          // Filter text removed as requested
        ],
      ),
    );
  }

  Widget _buildEnhancedStatisticsSection(Map<String, dynamic> enhancedStats) {
    final overview = enhancedStats['overview'] as Map<String, dynamic>? ?? {};
    final validation = enhancedStats['validation'] as Map<String, dynamic>? ?? {};
    final learning = enhancedStats['learning'] as Map<String, dynamic>? ?? {};
    final activity = enhancedStats['activity'] as Map<String, dynamic>? ?? {};
    final performance = enhancedStats['performance'] as Map<String, dynamic>? ?? {};

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'AI Learning & Validation Progress',
          style: TextStyle(
            color: Colors.yellow[600],
            fontSize: 16,
            fontWeight: FontWeight.bold,
          ),
        ),
        SizedBox(height: 12),
        
        // Validation Statistics
        Row(
          children: [
            Expanded(
              child: _buildLearningStatCard(
                'Validation Success',
                '${validation['success_rate']?.toStringAsFixed(1) ?? '0'}%',
                Colors.green,
                Icons.verified,
              ),
            ),
            SizedBox(width: 8),
            Expanded(
              child: _buildLearningStatCard(
                'Auto-Fix Success',
                '${validation['auto_fix_success_rate']?.toStringAsFixed(1) ?? '0'}%',
                Colors.blue,
                Icons.auto_fix_high,
              ),
            ),
          ],
        ),
        SizedBox(height: 8),
        
        // Learning Activity
        Row(
          children: [
            Expanded(
              child: _buildLearningStatCard(
                'Learning Active',
                learning['learning_active'] == true ? 'Yes' : 'No',
                learning['learning_active'] == true ? Colors.green : Colors.grey,
                Icons.psychology,
              ),
            ),
            SizedBox(width: 8),
            Expanded(
              child: _buildLearningStatCard(
                'Recent Patterns',
                '${learning['recent_successful_patterns'] ?? 0}',
                Colors.purple,
                Icons.pattern,
              ),
            ),
          ],
        ),
        SizedBox(height: 8),
        
        // Performance Indicators
        if (performance['improvement_areas'] != null) ...[
          Text(
            'Improvement Areas:',
            style: TextStyle(
              color: Colors.yellow[600],
              fontSize: 12,
              fontWeight: FontWeight.bold,
            ),
          ),
          SizedBox(height: 4),
          ...(performance['improvement_areas'] as List<dynamic>? ?? [])
              .take(3)
              .map((area) => Padding(
                    padding: EdgeInsets.only(left: 8, bottom: 2),
                    child: Text(
                      '• $area',
                      style: TextStyle(
                        color: Colors.grey[400],
                        fontSize: 11,
                      ),
                    ),
                  )),
        ],
      ],
    );
  }

  Widget _buildLearningStatCard(
    String label,
    String value,
    Color color,
    IconData icon,
  ) {
    return Container(
      padding: EdgeInsets.all(8),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: color.withOpacity(0.3), width: 1),
      ),
      child: Column(
        children: [
          Icon(icon, color: color, size: 16),
          SizedBox(height: 4),
          Text(
            value,
            style: TextStyle(
              color: color,
              fontSize: 14,
              fontWeight: FontWeight.bold,
            ),
          ),
          Text(
            label,
            style: TextStyle(
              color: Colors.grey[400],
              fontSize: 10,
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  String _getActiveFiltersText() {
    final filters = <String>[];
    if (_selectedCategory != 'All') filters.add('Category: $_selectedCategory');
    if (_selectedStatus != 'All') filters.add('Status: $_selectedStatus');
    if (_searchQuery.isNotEmpty) filters.add('Search: "$_searchQuery"');
    if (_showOnlyDownloadable) filters.add('Downloadable only');
    if (_showOnlyTested) filters.add('Tested only');
    return filters.join(', ');
  }

  Widget _buildEnhancedStatItem(
    String label,
    String value,
    Color color,
    IconData icon,
  ) {
    return Column(
      children: [
        Container(
          padding: EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: color.withOpacity(0.2),
            borderRadius: BorderRadius.circular(8),
          ),
          child: Icon(icon, color: color, size: 20),
        ),
        SizedBox(height: 4),
        Text(
          value,
          style: TextStyle(
            color: color,
            fontSize: 18,
            fontWeight: FontWeight.bold,
          ),
        ),
        Text(label, style: TextStyle(color: Colors.grey[400], fontSize: 10)),
      ],
    );
  }

  Widget _buildAdvancedFilters() {
    return SlideTransition(
      position: Tween<Offset>(
        begin: Offset(0, -1),
        end: Offset.zero,
      ).animate(_slideAnimationController),
      child: Container(
        margin: EdgeInsets.symmetric(horizontal: 16),
        padding: EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.grey[900],
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: Colors.yellow[700]!, width: 1),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Advanced Filters',
              style: TextStyle(
                color: Colors.yellow[700],
                fontWeight: FontWeight.bold,
                fontSize: 16,
              ),
            ),
            SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: DropdownButtonFormField<String>(
                    value: _selectedStatus,
                    decoration: InputDecoration(
                      labelText: 'Status',
                      labelStyle: TextStyle(color: Colors.grey[400]),
                      border: OutlineInputBorder(),
                      enabledBorder: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.grey[600]!),
                      ),
                    ),
                    dropdownColor: Colors.grey[800],
                    style: TextStyle(color: Colors.white),
                    items:
                        _statusOptions.map((status) {
                          return DropdownMenuItem(
                            value: status,
                            child: Text(status),
                          );
                        }).toList(),
                    onChanged: (value) {
                      setState(() => _selectedStatus = value!);
                    },
                  ),
                ),
                SizedBox(width: 12),
                Expanded(
                  child: DropdownButtonFormField<String>(
                    value: _selectedSortBy,
                    decoration: InputDecoration(
                      labelText: 'Sort By',
                      labelStyle: TextStyle(color: Colors.grey[400]),
                      border: OutlineInputBorder(),
                      enabledBorder: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.grey[600]!),
                      ),
                    ),
                    dropdownColor: Colors.grey[800],
                    style: TextStyle(color: Colors.white),
                    items:
                        _sortOptions.map((option) {
                          return DropdownMenuItem(
                            value: option,
                            child: Text(option),
                          );
                        }).toList(),
                    onChanged: (value) {
                      setState(() => _selectedSortBy = value!);
                    },
                  ),
                ),
              ],
            ),
            SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: CheckboxListTile(
                    title: Text(
                      'Downloadable Only',
                      style: TextStyle(color: Colors.white, fontSize: 14),
                    ),
                    value: _showOnlyDownloadable,
                    onChanged: (value) {
                      setState(() => _showOnlyDownloadable = value!);
                    },
                    activeColor: Colors.yellow[700],
                    checkColor: Colors.black,
                  ),
                ),
                Expanded(
                  child: CheckboxListTile(
                    title: Text(
                      'Tested Only',
                      style: TextStyle(color: Colors.white, fontSize: 14),
                    ),
                    value: _showOnlyTested,
                    onChanged: (value) {
                      setState(() => _showOnlyTested = value!);
                    },
                    activeColor: Colors.yellow[700],
                    checkColor: Colors.black,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildEnhancedCategoryFilter() {
    return Container(
      height: 80,
      padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        itemCount: _categories.length,
        itemBuilder: (context, index) {
          final category = _categories[index];
          final isSelected = category == _selectedCategory;
          final categoryData =
              _categoryInfo[category] ?? _categoryInfo['General']!;

          return Container(
            margin: EdgeInsets.only(right: 12),
            child: InkWell(
              onTap: () {
                setState(() => _selectedCategory = category);
                _showNotification(
                  'Filtered by: $category',
                  NotificationType.info,
                );
              },
              child: Container(
                padding: EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                decoration: BoxDecoration(
                  color: isSelected ? categoryData['color'] : Colors.grey[800],
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(
                    color:
                        isSelected ? categoryData['color'] : Colors.grey[600]!,
                    width: 2,
                  ),
                  boxShadow:
                      isSelected
                          ? [
                            BoxShadow(
                              color: categoryData['color'].withOpacity(0.3),
                              blurRadius: 8,
                              spreadRadius: 2,
                            ),
                          ]
                          : null,
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(
                      categoryData['icon'],
                      color: isSelected ? Colors.white : Colors.grey[400],
                      size: 20,
                    ),
                    SizedBox(width: 8),
                    Text(
                      category,
                      style: TextStyle(
                        color: isSelected ? Colors.white : Colors.grey[400],
                        fontWeight:
                            isSelected ? FontWeight.bold : FontWeight.normal,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  void _showSearchDialog() {
    showDialog(
      context: context,
      builder:
          (context) => AlertDialog(
            backgroundColor: Colors.grey[900],
            title: Text(
              'Search Apps',
              style: TextStyle(color: Colors.yellow[700]),
            ),
            content: TextField(
              style: TextStyle(color: Colors.white),
              decoration: InputDecoration(
                hintText: 'Search by name, description, or keywords...',
                hintStyle: TextStyle(color: Colors.grey[400]),
                border: OutlineInputBorder(),
                enabledBorder: OutlineInputBorder(
                  borderSide: BorderSide(color: Colors.grey[600]!),
                ),
                focusedBorder: OutlineInputBorder(
                  borderSide: BorderSide(color: Colors.yellow[700]!),
                ),
              ),
              onChanged: (value) => _searchQuery = value,
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: Text(
                  'Cancel',
                  style: TextStyle(color: Colors.grey[400]),
                ),
              ),
              ElevatedButton(
                onPressed: () {
                  Navigator.pop(context);
                  setState(() {});
                  if (_searchQuery.isNotEmpty) {
                    _showNotification(
                      'Searching for: "$_searchQuery"',
                      NotificationType.info,
                    );
                  }
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.yellow[700],
                ),
                child: Text('Search', style: TextStyle(color: Colors.black)),
              ),
            ],
          ),
    );
  }

  Widget _buildEnhancedEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            padding: EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: Colors.grey[900],
              borderRadius: BorderRadius.circular(50),
            ),
            child: Icon(Icons.apps, size: 80, color: Colors.grey[600]),
          ),
          SizedBox(height: 24),
          Text(
            'No apps found',
            style: TextStyle(
              color: Colors.grey[400],
              fontSize: 24,
              fontWeight: FontWeight.bold,
            ),
          ),
          SizedBox(height: 8),
          Text(
            _getEmptyStateMessage(),
            style: TextStyle(color: Colors.grey[600], fontSize: 16),
            textAlign: TextAlign.center,
          ),
          SizedBox(height: 24),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              ElevatedButton.icon(
                onPressed: () => Navigator.pushNamed(context, '/conquest'),
                icon: Icon(Icons.add),
                label: Text('Create New App'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.yellow[700],
                  foregroundColor: Colors.black,
                  padding: EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                ),
              ),
              SizedBox(width: 16),
              ElevatedButton.icon(
                onPressed: () {
                  setState(() {
                    _selectedCategory = 'All';
                    _selectedStatus = 'All';
                    _searchQuery = '';
                    _showOnlyDownloadable = false;
                    _showOnlyTested = false;
                  });
                  _showNotification('Filters cleared', NotificationType.info);
                },
                icon: Icon(Icons.clear),
                label: Text('Clear Filters'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.grey[700],
                  foregroundColor: Colors.white,
                  padding: EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  String _getEmptyStateMessage() {
    if (_selectedCategory != 'All') {
      return 'No apps found in the $_selectedCategory category';
    } else if (_selectedStatus != 'All') {
      return 'No apps with $_selectedStatus status';
    } else if (_searchQuery.isNotEmpty) {
      return 'No apps match your search: "$_searchQuery"';
    } else if (_showOnlyDownloadable) {
      return 'No downloadable apps found';
    } else if (_showOnlyTested) {
      return 'No tested apps found';
    } else {
      return 'No apps have been created yet. Start by creating your first AI-powered app!';
    }
  }

  Widget _buildEnhancedAppsList(List<ConquestApp> apps) {
    return ListView.builder(
      padding: EdgeInsets.all(16),
      itemCount: apps.length,
      itemBuilder: (context, index) {
        final app = apps[index];
        return _buildEnhancedAppCard(app);
      },
    );
  }

  Widget _buildEnhancedAppCard(ConquestApp app) {
    final statusColor = _getStatusColor(app.status);
    final statusIcon = _getStatusIcon(app.status);
    final categoryData =
        _categoryInfo[app.category] ?? _categoryInfo['General']!;

    return Card(
      margin: EdgeInsets.only(bottom: 16),
      color: Colors.grey[900],
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: BorderSide(color: Colors.grey[800]!, width: 1),
      ),
      child: ExpansionTile(
        leading: Container(
          padding: EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: categoryData['color'].withOpacity(0.2),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Icon(
            categoryData['icon'],
            color: categoryData['color'],
            size: 24,
          ),
        ),
        title: Text(
          app.name,
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
            fontSize: 16,
          ),
        ),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(height: 4),
            Text(
              app.description,
              style: TextStyle(color: Colors.grey[400], fontSize: 12),
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
            ),
            SizedBox(height: 8),
            Row(
              children: [
                Container(
                  padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: statusColor.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(statusIcon, color: statusColor, size: 14),
                      SizedBox(width: 4),
                      Text(
                        app.status.toUpperCase(),
                        style: TextStyle(
                          color: statusColor,
                          fontSize: 10,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                ),
                Spacer(),
                if (app.confidence != null)
                  Container(
                    padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(
                      color: Colors.blue.withOpacity(0.2),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Text(
                      '${(app.confidence! * 100).toInt()}%',
                      style: TextStyle(
                        color: Colors.blue,
                        fontSize: 10,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                SizedBox(width: 8),
                Text(
                  _formatDate(app.createdAt),
                  style: TextStyle(color: Colors.grey[500], fontSize: 12),
                ),
              ],
            ),
          ],
        ),
        children: [
          Padding(
            padding: EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Enhanced App Details
                _buildEnhancedDetailSection('App Information', [
                  _buildDetailRow(
                    'Category',
                    app.category ?? 'General',
                    categoryData['color'],
                  ),
                  _buildDetailRow('Type', app.appType, Colors.blue),
                  _buildDetailRow(
                    'Operation',
                    app.operationType ?? 'Unknown',
                    Colors.orange,
                  ),
                  if (app.improvementFocus != null)
                    _buildDetailRow(
                      'Improvement Focus',
                      app.improvementFocus!,
                      Colors.purple,
                    ),
                ]),

                if (app.keywords.isNotEmpty)
                  _buildEnhancedDetailSection('Keywords', [
                    _buildKeywordsChips(app.keywords),
                  ]),

                if (app.features.isNotEmpty)
                  _buildEnhancedDetailSection('Features', [
                    _buildFeaturesList(app.features),
                  ]),

                // Enhanced Links Section
                if (app.repositoryUrl != null || app.apkUrl != null)
                  _buildEnhancedDetailSection('Downloads', [
                    _buildDownloadButtons(app),
                  ]),

                // Test Results
                if (app.testStatus != null && app.testStatus!.isNotEmpty)
                  _buildEnhancedDetailSection('Test Results', [
                    _buildTestResults(app),
                  ]),

                // AI Reasoning
                if (app.aiReasoning != null && app.aiReasoning!.isNotEmpty)
                  _buildEnhancedDetailSection('AI Reasoning', [
                    _buildAiReasoning(app.aiReasoning!),
                  ]),

                // Error Message (if failed)
                if (app.errorMessage != null)
                  _buildEnhancedDetailSection('Error Details', [
                    _buildErrorMessage(app.errorMessage!),
                  ]),

                // Build Logs (if available)
                if (app.buildLogs != null && app.buildLogs!.isNotEmpty)
                  _buildEnhancedDetailSection('Build Logs', [
                    _buildBuildLogs(app.buildLogs!),
                  ]),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildEnhancedDetailSection(String title, List<Widget> children) {
    return Container(
      margin: EdgeInsets.only(bottom: 20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: TextStyle(
              color: Colors.yellow[700],
              fontWeight: FontWeight.bold,
              fontSize: 16,
            ),
          ),
          SizedBox(height: 8),
          ...children,
        ],
      ),
    );
  }

  Widget _buildDetailRow(String label, String value, Color color) {
    return Padding(
      padding: EdgeInsets.symmetric(vertical: 4),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 120,
            child: Text(
              '$label:',
              style: TextStyle(
                color: color,
                fontSize: 12,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          Expanded(
            child: Text(
              value,
              style: TextStyle(color: Colors.white, fontSize: 12),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildKeywordsChips(List<String> keywords) {
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children:
          keywords.map((keyword) {
            return Container(
              padding: EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              decoration: BoxDecoration(
                color: Colors.blue.withOpacity(0.2),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: Colors.blue.withOpacity(0.5)),
              ),
              child: Text(
                keyword,
                style: TextStyle(
                  color: Colors.blue,
                  fontSize: 12,
                  fontWeight: FontWeight.w500,
                ),
              ),
            );
          }).toList(),
    );
  }

  Widget _buildFeaturesList(List<String> features) {
    return Column(
      children:
          features.map((feature) {
            return Padding(
              padding: EdgeInsets.symmetric(vertical: 2),
              child: Row(
                children: [
                  Icon(Icons.check_circle, color: Colors.green, size: 16),
                  SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      feature,
                      style: TextStyle(color: Colors.white, fontSize: 12),
                    ),
                  ),
                ],
              ),
            );
          }).toList(),
    );
  }

  Widget _buildDownloadButtons(ConquestApp app) {
    return Row(
      children: [
        if (app.repositoryUrl != null)
          Expanded(
            child: ElevatedButton.icon(
              onPressed: () => _launchUrl(app.repositoryUrl!),
              icon: Icon(Icons.code, size: 16),
              label: Text('Repository'),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.blue[600],
                foregroundColor: Colors.white,
                padding: EdgeInsets.symmetric(vertical: 12),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
            ),
          ),
        if (app.repositoryUrl != null && app.apkUrl != null)
          SizedBox(width: 12),
        if (app.apkUrl != null)
          Expanded(
            child: ElevatedButton.icon(
              onPressed: () => _launchUrl(app.apkUrl!),
              icon: Icon(Icons.download, size: 16),
              label: Text('Download APK'),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.green[600],
                foregroundColor: Colors.white,
                padding: EdgeInsets.symmetric(vertical: 12),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
            ),
          ),
      ],
    );
  }

  Widget _buildTestResults(ConquestApp app) {
    final testColor =
        app.testStatus == 'passed'
            ? Colors.green
            : app.testStatus == 'failed'
            ? Colors.red
            : Colors.orange;

    return Container(
      padding: EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: testColor.withOpacity(0.1),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: testColor.withOpacity(0.3)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(
                app.testStatus == 'passed'
                    ? Icons.check_circle
                    : app.testStatus == 'failed'
                    ? Icons.error
                    : Icons.warning,
                color: testColor,
                size: 16,
              ),
              SizedBox(width: 8),
              Text(
                'Test Status: ${app.testStatus!.toUpperCase()}',
                style: TextStyle(
                  color: testColor,
                  fontWeight: FontWeight.bold,
                  fontSize: 12,
                ),
              ),
            ],
          ),
          if (app.testOutput != null && app.testOutput!.isNotEmpty) ...[
            SizedBox(height: 8),
            Text(
              app.testOutput!,
              style: TextStyle(
                color: Colors.grey[300],
                fontSize: 11,
                fontFamily: 'monospace',
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildAiReasoning(String reasoning) {
    return Container(
      padding: EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.purple.withOpacity(0.1),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: Colors.purple.withOpacity(0.3)),
      ),
      child: Text(
        reasoning,
        style: TextStyle(
          color: Colors.grey[300],
          fontSize: 12,
          fontStyle: FontStyle.italic,
        ),
      ),
    );
  }

  Widget _buildErrorMessage(String error) {
    return Container(
      padding: EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.red.withOpacity(0.1),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: Colors.red.withOpacity(0.3)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.error, color: Colors.red, size: 16),
              SizedBox(width: 8),
              Text(
                'Error Details',
                style: TextStyle(
                  color: Colors.red,
                  fontWeight: FontWeight.bold,
                  fontSize: 12,
                ),
              ),
            ],
          ),
          SizedBox(height: 8),
          Text(
            error,
            style: TextStyle(
              color: Colors.red[100],
              fontSize: 11,
              fontFamily: 'monospace',
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBuildLogs(String logs) {
    return Container(
      padding: EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.grey[800],
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: Colors.grey[600]!),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.terminal, color: Colors.grey[400], size: 16),
              SizedBox(width: 8),
              Text(
                'Build Logs',
                style: TextStyle(
                  color: Colors.grey[400],
                  fontWeight: FontWeight.bold,
                  fontSize: 12,
                ),
              ),
            ],
          ),
          SizedBox(height: 8),
          Text(
            logs,
            style: TextStyle(
              color: Colors.grey[300],
              fontSize: 11,
              fontFamily: 'monospace',
            ),
          ),
        ],
      ),
    );
  }

  Color _getStatusColor(String status) {
    switch (status.toLowerCase()) {
      case 'completed':
        return Colors.green;
      case 'pending':
        return Colors.orange;
      case 'failed':
        return Colors.red;
      case 'in_progress':
        return Colors.blue;
      default:
        return Colors.grey;
    }
  }

  IconData _getStatusIcon(String status) {
    switch (status.toLowerCase()) {
      case 'completed':
        return Icons.check_circle;
      case 'pending':
        return Icons.schedule;
      case 'failed':
        return Icons.error;
      case 'in_progress':
        return Icons.play_circle;
      default:
        return Icons.help;
    }
  }

  String _formatDate(DateTime date) {
    return '${date.day}/${date.month}/${date.year}';
  }

  Future<void> _launchUrl(String url) async {
    try {
      if (await canLaunch(url)) {
        await launch(url);
        _showNotification('Opening: $url', NotificationType.success);
      } else {
        _showNotification('Could not launch $url', NotificationType.error);
      }
    } catch (e) {
      _showNotification('Error launching URL: $e', NotificationType.error);
    }
  }
}

enum NotificationType { success, error, warning, info }
