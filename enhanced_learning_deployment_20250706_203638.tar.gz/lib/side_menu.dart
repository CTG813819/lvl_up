import 'package:flutter/material.dart';
import 'package:the_codex/mission.dart';
import './screens/oath_papers_screen.dart';
import 'entries/entry_pin_screen.dart';
import 'package:provider/provider.dart';
import '../providers/notification_provider.dart';
import '../providers/proposal_provider.dart';
import '../widgets/code_visualization_terminal.dart';
import 'codex_screen.dart';
import './summary_page.dart';
import 'terra_screen.dart';

class SideMenu extends StatelessWidget {
  final BuildContext parentContext;
  const SideMenu({Key? key, required this.parentContext}) : super(key: key);

  get menuColor => null;

  void _navigateToEntries(BuildContext context) {
    Navigator.of(parentContext).push(
      MaterialPageRoute(
        builder:
            (context) => EntryPinScreen(
              title: 'View Entries',
              isViewing: true,
              onPinEntered: (pin, context) {
                Navigator.of(context).pushReplacementNamed('/entries');
              },
            ),
      ),
    );
  }

  void _showTheCodex(BuildContext context) {
    Navigator.pop(context); // Close the drawer
    Navigator.of(
      parentContext,
    ).push(MaterialPageRoute(builder: (context) => const CodexScreen()));
  }

  void _showCodeTerminal(BuildContext context) {
    try {
      // Show success notification
      ScaffoldMessenger.of(parentContext).showSnackBar(
        SnackBar(
          content: Row(
            children: [
              Icon(Icons.warning, color: Colors.white),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  'CHAOS MODE ACTIVATED! AI operations will run until 9 PM tomorrow.',
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),
              ),
            ],
          ),
          backgroundColor: Colors.purple,
          duration: Duration(seconds: 5),
          behavior: SnackBarBehavior.floating,
        ),
      );

      // Show notification provider
      final notificationProvider = Provider.of<NotificationProvider>(
        parentContext,
        listen: false,
      );
      notificationProvider.addNotification(
        'CHAOS MODE ACTIVATED',
        'AI operations are now running outside normal hours until 9 PM tomorrow.',
        'chaos',
        DateTime.now(),
      );
    } catch (e) {
      // Show error notification
      ScaffoldMessenger.of(parentContext).showSnackBar(
        SnackBar(
          content: Row(
            children: [
              Icon(Icons.error, color: Colors.white),
              const SizedBox(width: 8),
              Expanded(
                child: Text('Failed to activate Chaos mode: ${e.toString()}'),
              ),
            ],
          ),
          backgroundColor: Colors.red,
          duration: Duration(seconds: 3),
          behavior: SnackBarBehavior.floating,
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: Column(
        children: [
          Expanded(
            child: ListView(
              padding: EdgeInsets.zero,
              children: [_buildHeader(), _buildMenuItems(context)],
            ),
          ),
          // Add bottom spacing
          SizedBox(height: 20),
        ],
      ),
    );
  }

  Widget _buildHeader() {
    return DrawerHeader(
      decoration: const BoxDecoration(color: Colors.black),
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            'Level Up',
            style: TextStyle(
              color: Colors.white,
              fontSize: 20,
              fontWeight: FontWeight.bold,
            ),
          ),
          SizedBox(height: 4),
          Text(
            'Track your progress',
            style: TextStyle(
              color: Colors.white.withOpacity(0.8),
              fontSize: 14,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMenuItems(BuildContext context) {
    return Column(
      children: [
        const Divider(),
        _buildMenuItem(
          icon: Icons.flag,
          title: 'Missions',
          onTap: () => Navigator.pushNamed(parentContext, '/mission'),
          color: menuColor,
        ),
        _buildMenuItem(
          icon: Icons.analytics,
          title: 'Summary',
          onTap: () => Navigator.pushNamed(parentContext, '/summary'),
          color: menuColor,
        ),
        _buildMenuItem(
          icon: Icons.gavel,
          title: 'Judgement',
          onTap: () => Navigator.pushNamed(parentContext, '/tally'),
          color: menuColor,
        ),
        _buildMenuItem(
          icon: Icons.book,
          title: 'Entries',
          onTap: () => _navigateToEntries(context),
          color: menuColor,
        ),
        _buildMenuItem(
          icon: Icons.psychology,
          title: 'Masteries',
          onTap: () => Navigator.pushNamed(parentContext, '/mastery'),
          color: menuColor,
        ),
        _buildMenuItem(
          icon: Icons.book,
          title: 'The Codex',
          onTap: () => _showTheCodex(context),
          color: menuColor,
        ),
        _buildMenuItem(
          icon: Icons.public,
          title: 'Terra',
          onTap:
              () => Navigator.of(parentContext).push(
                MaterialPageRoute(builder: (context) => const TerraScreen()),
              ),
          color: menuColor,
        ),
        Consumer<ProposalProvider>(
          builder: (context, provider, _) {
            final pendingCount = provider.pendingProposals.length;
            return ListTile(
              leading: Stack(
                clipBehavior: Clip.none,
                children: [
                  Icon(Icons.rule, color: menuColor),
                  if (pendingCount > 0)
                    Positioned(
                      right: -8,
                      top: -4,
                      child: Container(
                        padding: const EdgeInsets.all(2),
                        decoration: BoxDecoration(
                          color: Colors.amber,
                          borderRadius: BorderRadius.circular(10),
                        ),
                        constraints: const BoxConstraints(
                          minWidth: 18,
                          minHeight: 18,
                        ),
                        child: Text(
                          '$pendingCount',
                          style: const TextStyle(
                            color: Colors.black,
                            fontSize: 12,
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ),
                    ),
                ],
              ),
              title: Text(
                'Imperium Proposals',
                style: TextStyle(color: menuColor),
              ),
              onTap: () {
                Navigator.pop(parentContext);
                Navigator.pushNamed(parentContext, '/proposal_approval');
              },
            );
          },
        ),
        Consumer<MissionProvider>(
          builder: (context, provider, _) {
            return ListTile(
              leading: Icon(Icons.shield, color: menuColor),
              title: Text('Oath Papers', style: TextStyle(color: menuColor)),
              onTap: () {
                Navigator.pop(parentContext);
                Navigator.pushNamed(parentContext, OathPapersScreen.routeName);
              },
            );
          },
        ),
        _buildMenuItem(
          icon: Icons.psychology,
          title: 'Mechanicum',
          onTap: () => Navigator.pushNamed(parentContext, '/conquest'),
          color: menuColor,
        ),
        _buildMenuItem(
          icon: Icons.trending_up,
          title: 'AI Growth Analytics',
          onTap:
              () => Navigator.pushNamed(parentContext, '/ai_growth_analytics'),
          color: menuColor,
        ),
        _buildMenuItem(
          icon: Icons.terminal,
          title: 'Code Terminal',
          onTap: () => _showCodeTerminal(context),
          color: menuColor,
        ),
      ],
    );
  }

  Widget _buildMenuItem({
    required IconData icon,
    required String title,
    required VoidCallback onTap,
    Color? color,
  }) {
    return ListTile(
      leading: Icon(icon, color: color),
      title: Text(title, style: TextStyle(color: color)),
      onTap: () {
        Navigator.pop(parentContext); // Close drawer
        onTap();
      },
    );
  }
}
