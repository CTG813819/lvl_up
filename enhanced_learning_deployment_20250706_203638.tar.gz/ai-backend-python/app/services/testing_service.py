"""
Testing service for AI proposals
Handles real test execution and validation for different proposal types
"""

import asyncio
import json
import subprocess
import tempfile
import os
from datetime import datetime
from typing import Dict, List, Optional, Tuple
from enum import Enum
import logging

logger = logging.getLogger(__name__)


class TestType(Enum):
    """Types of tests that can be performed"""
    SYNTAX_CHECK = "syntax_check"
    LINT_CHECK = "lint_check"
    UNIT_TEST = "unit_test"
    INTEGRATION_TEST = "integration_test"
    SECURITY_CHECK = "security_check"
    PERFORMANCE_CHECK = "performance_check"


class TestResult(Enum):
    """Test result status"""
    PASSED = "passed"
    FAILED = "failed"
    ERROR = "error"
    SKIPPED = "skipped"


class ProposalTestResult:
    """Result of testing a proposal"""
    
    def __init__(self, test_type: TestType, result: TestResult, output: str, duration: float):
        self.test_type = test_type
        self.result = result
        self.output = output
        self.duration = duration
        self.timestamp = datetime.utcnow()
    
    def to_dict(self) -> Dict:
        return {
            "test_type": self.test_type.value,
            "result": self.result.value,
            "output": self.output,
            "duration": self.duration,
            "timestamp": self.timestamp.isoformat()
        }


class TestingService:
    """Service for testing AI proposals"""
    
    def __init__(self):
        self.test_timeout = 30  # seconds
        self.max_output_length = 10000  # characters
    
    async def test_proposal(self, proposal_data: Dict) -> Tuple[TestResult, str, List[ProposalTestResult]]:
        """
        Test a proposal based on its type and content
        
        Args:
            proposal_data: Proposal data containing code changes and metadata
            
        Returns:
            Tuple of (overall_result, summary, detailed_results)
        """
        try:
            logger.info(f"Starting tests for proposal {proposal_data.get('id', 'unknown')}")
            
            # Determine what tests to run based on proposal type
            test_types = self._get_test_types_for_proposal(proposal_data)
            
            # Run tests
            results = []
            for test_type in test_types:
                result = await self._run_test(test_type, proposal_data)
                results.append(result)
            
            # Determine overall result
            overall_result = self._determine_overall_result(results)
            summary = self._generate_summary(results)
            
            logger.info(f"Tests completed for proposal {proposal_data.get('id', 'unknown')}: {overall_result.value}")
            
            return overall_result, summary, results
            
        except Exception as e:
            logger.error(f"Error testing proposal: {str(e)}")
            return TestResult.ERROR, f"Test execution failed: {str(e)}", []
    
    def _get_test_types_for_proposal(self, proposal_data: Dict) -> List[TestType]:
        """Determine which tests to run based on proposal type and content"""
        ai_type = proposal_data.get('ai_type', '').lower()
        improvement_type = proposal_data.get('improvement_type', '').lower()
        file_path = proposal_data.get('file_path', '').lower()
        
        # Base tests for all proposals
        test_types = [TestType.SYNTAX_CHECK]
        
        # Add tests based on AI type
        if ai_type == 'sandbox':
            test_types.extend([TestType.LINT_CHECK, TestType.UNIT_TEST])
        elif ai_type == 'guardian':
            test_types.extend([TestType.SECURITY_CHECK, TestType.LINT_CHECK])
        elif ai_type == 'imperium':
            test_types.extend([TestType.LINT_CHECK, TestType.UNIT_TEST, TestType.INTEGRATION_TEST])
        
        # Add tests based on improvement type
        if improvement_type == 'security':
            test_types.append(TestType.SECURITY_CHECK)
        elif improvement_type == 'performance':
            test_types.append(TestType.PERFORMANCE_CHECK)
        
        # Add tests based on file type
        if file_path.endswith('.py'):
            test_types.append(TestType.LINT_CHECK)
        elif file_path.endswith('.dart'):
            test_types.append(TestType.LINT_CHECK)
        
        # Remove duplicates while preserving order
        seen = set()
        unique_types = []
        for test_type in test_types:
            if test_type not in seen:
                seen.add(test_type)
                unique_types.append(test_type)
        
        return unique_types
    
    async def _run_test(self, test_type: TestType, proposal_data: Dict) -> ProposalTestResult:
        """Run a specific test type"""
        start_time = datetime.utcnow()
        
        try:
            if test_type == TestType.SYNTAX_CHECK:
                result = await self._run_syntax_check(proposal_data)
            elif test_type == TestType.LINT_CHECK:
                result = await self._run_lint_check(proposal_data)
            elif test_type == TestType.UNIT_TEST:
                result = await self._run_unit_test(proposal_data)
            elif test_type == TestType.INTEGRATION_TEST:
                result = await self._run_integration_test(proposal_data)
            elif test_type == TestType.SECURITY_CHECK:
                result = await self._run_security_check(proposal_data)
            elif test_type == TestType.PERFORMANCE_CHECK:
                result = await self._run_performance_check(proposal_data)
            else:
                result = TestResult.SKIPPED, f"Unknown test type: {test_type.value}"
        
        except Exception as e:
            result = TestResult.ERROR, f"Test execution error: {str(e)}"
        
        end_time = datetime.utcnow()
        duration = (end_time - start_time).total_seconds()
        
        return ProposalTestResult(test_type, result[0], result[1], duration)
    
    async def _run_syntax_check(self, proposal_data: Dict) -> Tuple[TestResult, str]:
        """Check syntax of the proposed code changes"""
        try:
            code_after = proposal_data.get('code_after', '')
            file_path = proposal_data.get('file_path', '')
            
            if not code_after.strip():
                return TestResult.SKIPPED, "No code to check"
            
            # Create temporary file for syntax check
            with tempfile.NamedTemporaryFile(mode='w', suffix=self._get_file_extension(file_path), delete=False) as f:
                f.write(code_after)
                temp_file = f.name
            
            try:
                # Run syntax check based on file type
                if file_path.endswith('.py'):
                    result = await self._check_python_syntax(temp_file)
                elif file_path.endswith('.dart'):
                    result = await self._check_dart_syntax(temp_file)
                elif file_path.endswith('.js'):
                    result = await self._check_javascript_syntax(temp_file)
                else:
                    result = TestResult.SKIPPED, f"Syntax check not implemented for {file_path}"
                
                return result
                
            finally:
                # Clean up temporary file
                if os.path.exists(temp_file):
                    os.unlink(temp_file)
                    
        except Exception as e:
            return TestResult.ERROR, f"Syntax check failed: {str(e)}"
    
    async def _run_lint_check(self, proposal_data: Dict) -> Tuple[TestResult, str]:
        """Run linting on the proposed code"""
        try:
            code_after = proposal_data.get('code_after', '')
            file_path = proposal_data.get('file_path', '')
            
            if not code_after.strip():
                return TestResult.SKIPPED, "No code to lint"
            
            # Create temporary file for linting
            with tempfile.NamedTemporaryFile(mode='w', suffix=self._get_file_extension(file_path), delete=False) as f:
                f.write(code_after)
                temp_file = f.name
            
            try:
                # Run linting based on file type
                if file_path.endswith('.py'):
                    result = await self._lint_python(temp_file)
                elif file_path.endswith('.dart'):
                    result = await self._lint_dart(temp_file)
                else:
                    result = TestResult.SKIPPED, f"Linting not implemented for {file_path}"
                
                return result
                
            finally:
                # Clean up temporary file
                if os.path.exists(temp_file):
                    os.unlink(temp_file)
                    
        except Exception as e:
            return TestResult.ERROR, f"Lint check failed: {str(e)}"
    
    async def _run_unit_test(self, proposal_data: Dict) -> Tuple[TestResult, str]:
        """Run unit tests (simulated for now)"""
        try:
            # For now, simulate unit test execution
            # In a real implementation, this would run actual unit tests
            await asyncio.sleep(0.5)  # Simulate test execution time
            
            # Simulate test results based on proposal confidence
            confidence = proposal_data.get('confidence', 0.5)
            if confidence > 0.7:
                return TestResult.PASSED, "Unit tests passed (simulated)"
            elif confidence > 0.4:
                return TestResult.FAILED, "Unit tests failed (simulated - low confidence)"
            else:
                return TestResult.ERROR, "Unit tests error (simulated - very low confidence)"
                
        except Exception as e:
            return TestResult.ERROR, f"Unit test failed: {str(e)}"
    
    async def _run_integration_test(self, proposal_data: Dict) -> Tuple[TestResult, str]:
        """Run integration tests (simulated for now)"""
        try:
            # Simulate integration test execution
            await asyncio.sleep(1.0)  # Simulate longer test execution time
            
            # Simulate test results
            ai_type = proposal_data.get('ai_type', '').lower()
            if ai_type == 'imperium':
                return TestResult.PASSED, "Integration tests passed (simulated)"
            else:
                return TestResult.SKIPPED, "Integration tests skipped (not Imperium proposal)"
                
        except Exception as e:
            return TestResult.ERROR, f"Integration test failed: {str(e)}"
    
    async def _run_security_check(self, proposal_data: Dict) -> Tuple[TestResult, str]:
        """Run security checks on the proposed code"""
        try:
            code_after = proposal_data.get('code_after', '')
            
            if not code_after.strip():
                return TestResult.SKIPPED, "No code to check for security issues"
            
            # Basic security checks
            security_issues = []
            
            # Check for common security vulnerabilities
            dangerous_patterns = [
                ('exec(', 'Potential code execution vulnerability'),
                ('eval(', 'Potential code execution vulnerability'),
                ('subprocess.call', 'Potential command injection'),
                ('os.system', 'Potential command injection'),
                ('pickle.loads', 'Potential deserialization vulnerability'),
                ('yaml.load', 'Potential deserialization vulnerability'),
            ]
            
            for pattern, issue in dangerous_patterns:
                if pattern in code_after:
                    security_issues.append(issue)
            
            if security_issues:
                return TestResult.FAILED, f"Security issues found: {'; '.join(security_issues)}"
            else:
                return TestResult.PASSED, "Security check passed - no obvious vulnerabilities found"
                
        except Exception as e:
            return TestResult.ERROR, f"Security check failed: {str(e)}"
    
    async def _run_performance_check(self, proposal_data: Dict) -> Tuple[TestResult, str]:
        """Run performance checks (simulated for now)"""
        try:
            # Simulate performance analysis
            await asyncio.sleep(0.3)
            
            # Simulate performance results based on improvement type
            improvement_type = proposal_data.get('improvement_type', '').lower()
            if improvement_type == 'performance':
                return TestResult.PASSED, "Performance check passed - improvements detected"
            else:
                return TestResult.SKIPPED, "Performance check skipped (not performance improvement)"
                
        except Exception as e:
            return TestResult.ERROR, f"Performance check failed: {str(e)}"
    
    async def _check_python_syntax(self, file_path: str) -> Tuple[TestResult, str]:
        """Check Python syntax using python -m py_compile"""
        try:
            process = await asyncio.create_subprocess_exec(
                'python', '-m', 'py_compile', file_path,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            
            stdout, stderr = await asyncio.wait_for(process.communicate(), timeout=self.test_timeout)
            
            if process.returncode == 0:
                return TestResult.PASSED, "Python syntax check passed"
            else:
                error_output = stderr.decode('utf-8', errors='ignore')
                return TestResult.FAILED, f"Python syntax error: {error_output[:500]}"
                
        except asyncio.TimeoutError:
            return TestResult.ERROR, "Python syntax check timed out"
        except Exception as e:
            return TestResult.ERROR, f"Python syntax check failed: {str(e)}"
    
    async def _check_dart_syntax(self, file_path: str) -> Tuple[TestResult, str]:
        """Check Dart syntax using dart analyze"""
        try:
            process = await asyncio.create_subprocess_exec(
                'dart', 'analyze', file_path,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            
            stdout, stderr = await asyncio.wait_for(process.communicate(), timeout=self.test_timeout)
            
            if process.returncode == 0:
                return TestResult.PASSED, "Dart syntax check passed"
            else:
                error_output = stderr.decode('utf-8', errors='ignore')
                return TestResult.FAILED, f"Dart syntax error: {error_output[:500]}"
                
        except asyncio.TimeoutError:
            return TestResult.ERROR, "Dart syntax check timed out"
        except Exception as e:
            return TestResult.ERROR, f"Dart syntax check failed: {str(e)}"
    
    async def _check_javascript_syntax(self, file_path: str) -> Tuple[TestResult, str]:
        """Check JavaScript syntax using node --check"""
        try:
            process = await asyncio.create_subprocess_exec(
                'node', '--check', file_path,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            
            stdout, stderr = await asyncio.wait_for(process.communicate(), timeout=self.test_timeout)
            
            if process.returncode == 0:
                return TestResult.PASSED, "JavaScript syntax check passed"
            else:
                error_output = stderr.decode('utf-8', errors='ignore')
                return TestResult.FAILED, f"JavaScript syntax error: {error_output[:500]}"
                
        except asyncio.TimeoutError:
            return TestResult.ERROR, "JavaScript syntax check timed out"
        except Exception as e:
            return TestResult.ERROR, f"JavaScript syntax check failed: {str(e)}"
    
    async def _lint_python(self, file_path: str) -> Tuple[TestResult, str]:
        """Run Python linting using flake8 if available"""
        try:
            process = await asyncio.create_subprocess_exec(
                'flake8', file_path,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            
            stdout, stderr = await asyncio.wait_for(process.communicate(), timeout=self.test_timeout)
            
            if process.returncode == 0:
                return TestResult.PASSED, "Python linting passed"
            else:
                lint_output = stdout.decode('utf-8', errors='ignore')
                return TestResult.FAILED, f"Python linting issues: {lint_output[:500]}"
                
        except FileNotFoundError:
            return TestResult.SKIPPED, "flake8 not available - skipping Python linting"
        except asyncio.TimeoutError:
            return TestResult.ERROR, "Python linting timed out"
        except Exception as e:
            return TestResult.ERROR, f"Python linting failed: {str(e)}"
    
    async def _lint_dart(self, file_path: str) -> Tuple[TestResult, str]:
        """Run Dart linting using dart analyze"""
        try:
            process = await asyncio.create_subprocess_exec(
                'dart', 'analyze', file_path,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            
            stdout, stderr = await asyncio.wait_for(process.communicate(), timeout=self.test_timeout)
            
            if process.returncode == 0:
                return TestResult.PASSED, "Dart linting passed"
            else:
                lint_output = stdout.decode('utf-8', errors='ignore')
                return TestResult.FAILED, f"Dart linting issues: {lint_output[:500]}"
                
        except asyncio.TimeoutError:
            return TestResult.ERROR, "Dart linting timed out"
        except Exception as e:
            return TestResult.ERROR, f"Dart linting failed: {str(e)}"
    
    def _get_file_extension(self, file_path: str) -> str:
        """Get file extension from file path"""
        return os.path.splitext(file_path)[1] if file_path else '.txt'
    
    def _determine_overall_result(self, results: List[ProposalTestResult]) -> TestResult:
        """Determine overall test result from individual test results"""
        if not results:
            return TestResult.SKIPPED
        
        # Check for errors first
        if any(r.result == TestResult.ERROR for r in results):
            return TestResult.ERROR
        
        # Check for failures
        if any(r.result == TestResult.FAILED for r in results):
            return TestResult.FAILED
        
        # Check if all tests passed
        if all(r.result == TestResult.PASSED for r in results):
            return TestResult.PASSED
        
        # If we have a mix of passed and skipped, consider it passed
        if any(r.result == TestResult.PASSED for r in results):
            return TestResult.PASSED
        
        # Default to skipped
        return TestResult.SKIPPED
    
    def _generate_summary(self, results: List[ProposalTestResult]) -> str:
        """Generate a summary of test results"""
        if not results:
            return "No tests were executed"
        
        passed = sum(1 for r in results if r.result == TestResult.PASSED)
        failed = sum(1 for r in results if r.result == TestResult.FAILED)
        errors = sum(1 for r in results if r.result == TestResult.ERROR)
        skipped = sum(1 for r in results if r.result == TestResult.SKIPPED)
        total = len(results)
        
        summary_parts = []
        if passed > 0:
            summary_parts.append(f"{passed} passed")
        if failed > 0:
            summary_parts.append(f"{failed} failed")
        if errors > 0:
            summary_parts.append(f"{errors} errors")
        if skipped > 0:
            summary_parts.append(f"{skipped} skipped")
        
        summary = f"Tests: {', '.join(summary_parts)} ({total} total)"
        
        # Add details for failed tests
        failed_tests = [r for r in results if r.result in [TestResult.FAILED, TestResult.ERROR]]
        if failed_tests:
            failed_details = []
            for test in failed_tests[:3]:  # Limit to first 3 failures
                failed_details.append(f"{test.test_type.value}: {test.output[:100]}...")
            summary += f"\nFailures: {'; '.join(failed_details)}"
        
        return summary


# Global instance
testing_service = TestingService() 